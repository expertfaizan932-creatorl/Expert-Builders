<?php
/**
 * EXPERT BUILDERS CRM - REST API router
 * ---------------------------------
 * GET  /api/index.php/contacts                 -> list (filters: search, tag, type, lead, sort)
 * GET  /api/index.php/contacts/{id}            -> single contact with tags
 * POST /api/index.php/contacts                 -> create contact
 * POST /api/index.php/contacts/bulk-delete     -> delete many ({ "ids": [1,2] })
 * DELETE /api/index.php/contacts/{id}          -> delete one
 *  GET  /api/index.php/leads                    -> LEADS ONLY (the "find leads" shortcut)
 *  GET  /api/index.php/tags                     -> list all tags
 *  GET  /api/index.php/campaigns?status=active  -> list campaigns (status: active|paused|canceled|finished)
 *  GET  /api/index.php/workflows?status=active  -> list workflows (status: active|finished)
 *  GET  /api/index.php/staff                    -> list staff users
 *  POST /api/index.php/staff                    -> create staff user
 *  PUT  /api/index.php/staff/{id}               -> update staff user
 *  DELETE /api/index.php/staff/{id}             -> delete staff user
 *  PUT  /api/index.php/contacts/{id}            -> update contact (e.g. assigned_to)
 *
 *  GET  /api/index.php/invoices                  -> list invoices (filters: search, created_by)
 *  GET  /api/index.php/invoices/next-number      -> suggested next sequential invoice number
 *  POST /api/index.php/invoices                  -> create sales tax invoice
 *  PUT  /api/index.php/invoices/{id}             -> update sales tax invoice
 *  DELETE /api/index.php/invoices/{id}           -> delete sales tax invoice
 *  GET  /api/index.php/receipts                  -> list receipt vouchers (filters: search, created_by)
 *  GET  /api/index.php/receipts/next-number      -> suggested next receipt number (RDC-xxxxx)
 *  POST /api/index.php/receipts                  -> create receipt voucher
 *  PUT  /api/index.php/receipts/{id}             -> update receipt voucher
 *  DELETE /api/index.php/receipts/{id}           -> delete receipt voucher
 *  GET  /api/index.php/account-statements        -> list account statements (filters: search)
 *  GET  /api/index.php/account-statements/{id}   -> single statement + ledger rows + summaries
 *  POST /api/index.php/account-statements        -> create account statement
 *  PUT  /api/index.php/account-statements/{id}   -> update statement info
 *  DELETE /api/index.php/account-statements/{id} -> delete statement
 *  POST /api/index.php/account-statements/{id}/rows               -> add ledger row
 *  PUT  /api/index.php/account-statements/{id}/rows/{rid}         -> update ledger row
 *  DELETE /api/index.php/account-statements/{id}/rows/{rid}       -> delete ledger row
 *  POST /api/index.php/account-statements/{id}/schedule           -> seed 31-row installment schedule
 *
 * POST /api/index.php/emails/send              -> send email via SMTP (crm@yadea.com.pk)
 *                                                 { to, cc?, bcc?, subject, html, from_name? }
 * POST /api/index.php/emails/test              -> deliverability check { to, subject?, html? }
 *
 *  GET  /api/index.php/submissions              -> portal submissions (type, assigned_to, restrict_to, search)
 * POST /api/index.php/submissions               -> create dealership application / inquiry ticket
 * POST /api/index.php/submissions/{id}/assign   -> { assigned_to } (0 = unassign)
 * DELETE /api/index.php/submissions/{id}        -> remove a submission
 *
 * Full URL example:  http://localhost/expert-builders/api/index.php/contacts?search=faiz
 */

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        @file_put_contents(__DIR__ . '/_crash.log', date('c') . ' ' . $error['message'] . ' @ ' . $error['file'] . ':' . $error['line'] . "\n", FILE_APPEND);
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'error' => 'Fatal PHP error',
            'message' => $error['message'],
            'file' => $error['file'],
            'line' => $error['line'],
        ]);
        exit;
    }
});

require __DIR__ . '/config.php';

cors();

/** Parse request path relative to this script, e.g. ["contacts", "5"]. */
function route_parts(): array
{
    $script = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '';
    $base = parse_url($_SERVER['SCRIPT_NAME'], PHP_URL_PATH) ?: '';
    $path = substr($script, strlen($base));
    $parts = array_values(array_filter(explode('/', $path), fn($p) => $p !== ''));
    return $parts;
}

function to_int(string $v): int
{
    return (int)$v;
}

function build_where(array $filters, array &$params): string
{
    $clauses = [];

    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        // PDO named placeholders must be unique, so repeat the term across 5 params.
        $searchCols = ['name', 'phone', 'email', 'business_name', 'tags'];
        $pats = [];
        foreach ($searchCols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $clauses[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['tag'])) {
        $params[':tag'] = $filters['tag'];
        $clauses[] = 'FIND_IN_SET(:tag, tags)';
    }
    if (!empty($filters['type'])) {
        $params[':type'] = $filters['type'];
        $clauses[] = 'contact_type = :type';
    }
    if (isset($filters['lead'])) {
        $params[':lead'] = to_int($filters['lead']);
        $clauses[] = 'is_lead = :lead';
    }
    if (!empty($filters['restrict_to'])) {
        // Restricted users only see data assigned to them or that they follow.
        // (Two distinct placeholders: MySQL native prepares reject reused names.)
        $rid = to_int((string)$filters['restrict_to']);
        $params[':rid_owner'] = $rid;
        $params[':rid_follower'] = $rid;
        $clauses[] = '(assigned_to = :rid_owner OR id IN (SELECT contact_id FROM contact_followers WHERE staff_id = :rid_follower))';
    }

    return $clauses ? (' WHERE ' . implode(' AND ', $clauses)) : '';
}

function order_clause(array $filters): string
{
    $allowed = ['name', 'phone', 'email', 'business_name', 'created_at', 'last_activity_at'];
    $sort = $filters['sort'] ?? 'created_at';
    $sort = in_array($sort, $allowed, true) ? $sort : 'created_at';
    $dir = strtolower($filters['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
    return sprintf(' ORDER BY %s %s', $sort, $dir);
}

/** List contacts (from the aggregated view). */
function list_contacts(array $filters): void
{
    $params = [];
    $where = build_where($filters, $params);
    $order = order_clause($filters);

    $stmt = db()->prepare('SELECT * FROM v_contacts_with_tags' . $where . $order);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $row['tags'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
        $row['tag_ids'] = $row['tag_ids'] !== '' ? array_map('to_int', explode(',', $row['tag_ids'])) : [];
        $row['custom_fields'] = decode_custom_fields($row['custom_fields'] ?? null);
        $row['followers'] = contact_followers((int)$row['id']);
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

/** Load the follower staff summaries for a contact. */
function contact_followers(int $contactId): array
{
    $rows = db()->prepare(
        'SELECT s.id, s.first_name, s.last_name, s.full_name, s.user_type, s.avatar_data
           FROM contact_followers cf
           JOIN staff_users s ON s.id = cf.staff_id
          WHERE cf.contact_id = :id
          ORDER BY s.full_name'
    );
    $rows->execute([':id' => $contactId]);
    return $rows->fetchAll();
}

/** Single contact with tags. */
function get_contact(int $id): void
{
    $stmt = db()->prepare('SELECT * FROM v_contacts_with_tags WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();

    if (!$row) fail('Contact not found', 404);

    $row['tags'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
    $row['tag_ids'] = $row['tag_ids'] !== '' ? array_map('to_int', explode(',', $row['tag_ids'])) : [];
    $row['custom_fields'] = decode_custom_fields($row['custom_fields'] ?? null);
    $row['followers'] = contact_followers((int)$id);
    respond(['data' => $row]);
}

/** Find-or-create a tag, return its id. */
function ensure_tag(PDO $pdo, string $tagName): int
{
    $name = trim($tagName);
    if ($name === '') return 0;

    $stmt = $pdo->prepare('SELECT id FROM tags WHERE name = :name');
    $stmt->execute([':name' => $name]);
    $id = $stmt->fetchColumn();

    if ($id !== false) return (int)$id;

    $stmt = $pdo->prepare('INSERT INTO tags (name) VALUES (:name)');
    $stmt->execute([':name' => $name]);
    return (int)$pdo->lastInsertId();
}

/** Normalize a custom_fields value (array or JSON string) into a JSON text column value. */
function normalize_custom_fields($value): ?string
{
    if (is_array($value)) {
        return encode_json_field($value);
    }
    if (is_string($value) && $value !== '') {
        $decoded = json_decode($value, true);
        if (is_array($decoded)) return json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $value;
    }
    return null;
}

/** Decode the custom_fields JSON column into a PHP array for the API response. */
function decode_custom_fields(?string $raw): array
{
    $decoded = decode_json_field($raw);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Merge an incoming custom_fields JSON value into the value already stored on
 * the contact. 'form_submissions' arrays are APPENDED so a repeat submission
 * never wipes the earlier history (what was filled before stays saved);
 * every other key simply overwrites its previous value.
 */
function merge_custom_fields(?string $existingRaw, ?string $incomingRaw): ?string
{
    $base = decode_custom_fields($existingRaw);
    $inc = decode_custom_fields($incomingRaw);
    if (!$inc) return $existingRaw;

    $result = $base;
    foreach ($inc as $key => $value) {
        if ($key === 'form_submissions' && is_array($value)) {
            $existingSubs = is_array($result['form_submissions'] ?? null) ? $result['form_submissions'] : [];
            $result['form_submissions'] = array_merge($existingSubs, $value);
        } else {
            $result[$key] = $value;
        }
    }
    return encode_json_field($result);
}

/**
 * Work out which staff member should OWN a freshly created contact.
 *
 * A contact is only visible to a non-admin through `restrict_to`, which matches
 * `assigned_to = me OR followed-by-me`. Without an owner a lead created by a
 * Dealer/Follower was therefore invisible to its own creator (it only sat in the
 * admin's "Unassigned" pool). Passing the acting staff id lets us stamp
 * `assigned_to` at creation time so the creator sees it everywhere while the
 * admin still sees the whole CRM.
 *
 * Admins deliberately get NULL so leads they add keep landing in the
 * "Unassigned Leads" pool that the admin then hands out to dealers.
 */
function resolve_contact_owner(array $body): ?int
{
    $actorId = isset($body['created_by']) ? to_int((string)$body['created_by']) : 0;
    if ($actorId <= 0) return null;

    $stmt = db()->prepare('SELECT id, user_type FROM staff_users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $actorId]);
    $actor = $stmt->fetch();
    if (!$actor) return null;
    if (($actor['user_type'] ?? '') === 'Admin') return null;

    return (int)$actor['id'];
}

/** Create a contact (accepts first_name/last_name or a combined name). */
function create_contact(array $body): void
{
    $firstName = normalize_optional($body['first_name'] ?? null);
    $lastName = normalize_optional($body['last_name'] ?? null);

    // Fallback: accept a combined "name" and split on first space.
    if ($firstName === null && !empty($body['name'])) {
        $name = trim((string)$body['name']);
        $space = strpos($name, ' ');
        if ($space === false) {
            $firstName = $name;
        } else {
            $firstName = substr($name, 0, $space);
            $lastName = substr($name, $space + 1);
        }
    }

    if ($firstName === null || $firstName === '') {
        fail('First name is required');
    }

    // last_name is NOT NULL in the schema; coerce null/empty to ''.
    $lastName = $lastName ?? '';

    $phone = normalize_optional($body['phone'] ?? null);
    $email = normalize_optional($body['email'] ?? null);
    $business = normalize_optional($body['business_name'] ?? null);
    $contactType = in_array($body['contact_type'] ?? '', ['Lead', 'Customer', 'Vendor', 'Partner'], true)
        ? $body['contact_type'] : '';
    $avatarColor = normalize_optional($body['avatar_color'] ?? null) ?? 'bg-emerald-200 text-emerald-800';
    $avatarData = normalize_optional($body['avatar_data'] ?? null);
    $customFields = normalize_custom_fields($body['custom_fields'] ?? null);

    $tagInput = array_values(array_filter(
        array_map(fn($t) => trim((string)$t), (array)($body['tags'] ?? [])),
        fn($t) => $t !== ''
    ));

    $isLead = $contactType === 'Lead'
        || in_array('warm lead', $tagInput, true)
        || in_array('hot lead', $tagInput, true)
        || in_array('cold lead', $tagInput, true);

    // Stamp the creator as owner so the person who added the lead can see it in
    // their own contacts/leads/dashboard. Null for admins & public form posts.
    $ownerId = resolve_contact_owner($body);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        // Dedupe on email OR phone: if an existing contact already carries
        // either value, update it instead of failing, so form re-submissions
        // never hard-block with a "duplicate" error.
        $existingId = 0;
        if ($email !== null || $phone !== null) {
            $dupSql = 'SELECT id FROM contacts WHERE 1=0';
            $dupParams = [];
            if ($email !== null) {
                $dupSql .= ' OR email = :dup_email';
                $dupParams[':dup_email'] = $email;
            }
            if ($phone !== null) {
                $dupSql .= ' OR phone = :dup_phone';
                $dupParams[':dup_phone'] = $phone;
            }
            $dupStmt = $pdo->prepare($dupSql);
            $dupStmt->execute($dupParams);
            $dupId = $dupStmt->fetchColumn();
            if ($dupId !== false) $existingId = (int)$dupId;
        }

        if ($existingId > 0) {
            // Guard: if the incoming email/phone is already owned by a DIFFERENT
            // contact, skip overwriting that field (keep the original value).
            if ($email !== null) {
                $owner = $pdo->prepare('SELECT id FROM contacts WHERE email = :email AND id <> :id LIMIT 1');
                $owner->execute([':email' => $email, ':id' => $existingId]);
                if ($owner->fetchColumn() !== false) $email = null;
            }
            if ($phone !== null) {
                $owner = $pdo->prepare('SELECT id FROM contacts WHERE phone = :phone AND id <> :id LIMIT 1');
                $owner->execute([':phone' => $phone, ':id' => $existingId]);
                if ($owner->fetchColumn() !== false) $phone = null;
            }

            $updates = [];
            $params = [':id' => $existingId];
            if ($firstName !== null) { $updates[] = 'first_name = :first_name'; $params[':first_name'] = $firstName; }
            if ($lastName !== null) { $updates[] = 'last_name = :last_name'; $params[':last_name'] = $lastName; }
            if ($phone !== null) { $updates[] = 'phone = :phone'; $params[':phone'] = $phone; }
            if ($email !== null) { $updates[] = 'email = :email'; $params[':email'] = $email; }
            if ($business !== null) { $updates[] = 'business_name = :business_name'; $params[':business_name'] = $business; }
            if ($contactType !== '') { $updates[] = 'contact_type = :contact_type'; $params[':contact_type'] = $contactType; }
            if ($isLead) { $updates[] = 'is_lead = :is_lead'; $params[':is_lead'] = 1; }
            if ($avatarData !== null) { $updates[] = 'avatar_data = :avatar_data'; $params[':avatar_data'] = $avatarData; }
            if ($customFields !== null) {
                // Append the new form submission to any existing history instead
                // of replacing custom_fields, so no filled data is ever lost.
                $existingCf = $pdo->prepare('SELECT custom_fields FROM contacts WHERE id = :id');
                $existingCf->execute([':id' => $existingId]);
                $existingRaw = $existingCf->fetchColumn();
                $updates[] = 'custom_fields = :custom_fields';
                $params[':custom_fields'] = merge_custom_fields(
                    $existingRaw !== false ? (string)$existingRaw : null,
                    $customFields
                );
            }
            $updates[] = 'last_activity_at = NOW()';
            $updates[] = 'deleted_at = NULL';
            // A non-admin re-submitting a form for a lead that nobody owns yet
            // should end up owning it, otherwise the update is invisible to them.
            // Never steal a lead that is already assigned to someone else.
            if ($ownerId !== null) {
                $updates[] = 'assigned_to = COALESCE(assigned_to, :claim_owner)';
                $params[':claim_owner'] = $ownerId;
            }
            if ($updates) {
                $pdo->prepare('UPDATE contacts SET ' . implode(', ', $updates) . ' WHERE id = :id')
                    ->execute($params);
            }

            foreach ($tagInput as $tagName) {
                $tagId = ensure_tag($pdo, $tagName);
                if ($tagId > 0) {
                    $pdo->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (:c, :t)')
                        ->execute([':c' => $existingId, ':t' => $tagId]);
                }
            }

            // This lead already existed (matched by email/phone) and re-submitted
            // the form — tag it so the repeat submission is visible at a glance.
            $repeatTagId = ensure_tag($pdo, 'Form Re-submitted');
            if ($repeatTagId > 0) {
                $pdo->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (:c, :t)')
                    ->execute([':c' => $existingId, ':t' => $repeatTagId]);
            }

            // Same mutual exclusion as update_contact(): once the claiming user
            // owns the lead they can no longer also be a follower of it.
            if ($ownerId !== null) {
                $pdo->prepare('DELETE FROM contact_followers WHERE contact_id = :c AND staff_id = :s')
                    ->execute([':c' => $existingId, ':s' => $ownerId]);
            }

            $pdo->commit();
            respond(['data' => ['id' => $existingId], 'message' => 'Contact already exists; updated'], 200);
        }

        $stmt = $pdo->prepare(
            'INSERT INTO contacts (first_name, last_name, phone, email, business_name,
                                   contact_type, is_lead, avatar_color, avatar_data, custom_fields, assigned_to)
             VALUES (:fn, :ln, :phone, :email, :biz, :type, :lead, :color, :avatar, :custom, :assigned_to)'
        );
        $stmt->execute([
            ':fn' => $firstName,
            ':ln' => $lastName,
            ':phone' => $phone,
            ':email' => $email,
            ':biz' => $business,
            ':type' => $contactType,
            ':lead' => $isLead ? 1 : 0,
            ':color' => $avatarColor,
            ':avatar' => $avatarData,
            ':custom' => $customFields,
            ':assigned_to' => $ownerId,
        ]);

        $contactId = (int)$pdo->lastInsertId();

        foreach ($tagInput as $tagName) {
            $tagId = ensure_tag($pdo, $tagName);
            if ($tagId > 0) {
                $pdo->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (:c, :t)')
                    ->execute([':c' => $contactId, ':t' => $tagId]);
            }
        }

        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    respond(['data' => ['id' => $contactId], 'message' => 'Contact created'], 201);
}

/** Soft-delete one contact: hides it from every live view but keeps the DB row. */
function delete_contact(int $id): void
{
    $stmt = db()->prepare('UPDATE contacts SET deleted_at = NOW(), last_activity_at = NOW() WHERE id = :id AND deleted_at IS NULL');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Contact not found', 404);
    prune_smart_lists_when_empty();
    respond(['message' => 'Contact deleted']);
}

/** Soft-delete many contacts (rows stay in the DB, only hidden from live views). */
function bulk_delete(array $body): void
{
    $ids = array_values(array_filter(array_map('to_int', (array)($body['ids'] ?? [])), fn($i) => $i > 0));
    if (!$ids) fail('No ids provided');

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("UPDATE contacts SET deleted_at = NOW(), last_activity_at = NOW() WHERE id IN ($placeholders) AND deleted_at IS NULL");
    $stmt->execute($ids);

    prune_smart_lists_when_empty();

    respond(['message' => 'Deleted ' . $stmt->rowCount() . ' contact(s)']);
}

/**
 * When the very last contact is deleted, every smart list becomes meaningless
 * (there is nothing left to group), so remove them all.
 */
function prune_smart_lists_when_empty(): void
{
    $count = (int)db()->query('SELECT COUNT(*) FROM contacts WHERE deleted_at IS NULL')->fetchColumn();
    if ($count === 0) {
        db()->exec('DELETE FROM smart_lists');
    }
}

/** List all tags. */
function list_tags(): void
{
    $rows = db()->query('SELECT id, name, color FROM tags ORDER BY name')->fetchAll();
    respond(['data' => $rows]);
}

/** List campaigns, optionally filtered by status (active|paused|canceled|finished). */
function list_campaigns(array $filters): void
{
    $allowed = ['active', 'paused', 'canceled', 'finished'];
    $status = strtolower((string)($filters['status'] ?? ''));

    $where = '';
    $params = [];
    if ($status !== '' && in_array($status, $allowed, true)) {
        $where = ' WHERE status = :status';
        $params[':status'] = $status;
    }

    try {
        $stmt = db()->prepare('SELECT id, name, status, description, created_at FROM campaigns' . $where . ' ORDER BY name');
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        // Table not created yet -> treat as no campaigns rather than a hard error.
        $rows = [];
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

/** List workflows, optionally filtered by status (active|finished). */
function list_workflows(array $filters): void
{
    $allowed = ['active', 'finished'];
    $status = strtolower((string)($filters['status'] ?? ''));

    $where = '';
    $params = [];
    if ($status !== '' && in_array($status, $allowed, true)) {
        $where = ' WHERE status = :status';
        $params[':status'] = $status;
    }

    try {
        $stmt = db()->prepare('SELECT id, name, status, description, created_at FROM workflows' . $where . ' ORDER BY name');
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        // Table not created yet -> treat as no workflows rather than a hard error.
        $rows = [];
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

/** LEADS ONLY — quick way to find leads. */
function list_leads(array $filters): void
{
    $params = [];
    $clauses = [];

    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $searchCols = ['name', 'phone', 'email', 'business_name', 'tags'];
        $pats = [];
        foreach ($searchCols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $clauses[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['restrict_to'])) {
        $rid = to_int((string)$filters['restrict_to']);
        $params[':rid_owner'] = $rid;
        $params[':rid_follower'] = $rid;
        $clauses[] = '(assigned_to = :rid_owner OR id IN (SELECT contact_id FROM contact_followers WHERE staff_id = :rid_follower))';
    }
    $where = $clauses ? (' WHERE ' . implode(' AND ', $clauses)) : '';
    $order = order_clause($filters);

    $stmt = db()->prepare('SELECT * FROM v_leads' . $where . $order);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $row['tags'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
        $row['tag_ids'] = $row['tag_ids'] !== '' ? array_map('to_int', explode(',', $row['tag_ids'])) : [];
        $row['custom_fields'] = decode_custom_fields($row['custom_fields'] ?? null);
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

/* ------------------ CONTACT SUB-RESOURCES ------------------ */

function ensure_contact_exists(int $contactId): void
{
    $stmt = db()->prepare('SELECT id FROM contacts WHERE id = :id');
    $stmt->execute([':id' => $contactId]);
    if (!$stmt->fetch()) fail('Contact not found', 404);
}

function list_opportunities(int $contactId): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare('SELECT * FROM opportunities WHERE contact_id = :id ORDER BY created_at DESC');
    $stmt->execute([':id' => $contactId]);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $row['tags'] = $row['tags'] !== '' && $row['tags'] !== null
            ? array_values(array_filter(array_map('trim', explode(',', $row['tags']))))
            : [];
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

function create_opportunity(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);

    $tagsInput = array_map('trim', (array)($body['tags'] ?? []));
    $tagsInput = array_values(array_filter($tagsInput, fn($t) => $t !== ''));

    $stmt = db()->prepare(
        'INSERT INTO opportunities (contact_id, name, pipeline, stage, status, value, business_name,
                                    source, expected_close_date, tags)
         VALUES (:c, :name, :pipeline, :stage, :status, :value, :biz, :source, :close, :tags)'
    );
    $stmt->execute([
        ':c' => $contactId,
        ':name' => normalize_optional($body['name'] ?? null) ?? 'New Opportunity',
        ':pipeline' => normalize_optional($body['pipeline'] ?? null) ?? 'Marketing Pipeline',
        ':stage' => normalize_optional($body['stage'] ?? null) ?? 'New Lead',
        ':status' => normalize_optional($body['status'] ?? null) ?? 'Open',
        ':value' => normalize_optional($body['value'] ?? null) ?? 'Rs 0',
        ':biz' => normalize_optional($body['business_name'] ?? null) ?? '',
        ':source' => normalize_optional($body['source'] ?? null) ?? '',
        ':close' => normalize_optional($body['expected_close_date'] ?? null) ?? '',
        ':tags' => $tagsInput ? implode(',', $tagsInput) : '',
    ]);
    respond(['data' => ['id' => (int)db()->lastInsertId()], 'message' => 'Opportunity created'], 201);
}

function delete_opportunity(int $id): void
{
    $stmt = db()->prepare('DELETE FROM opportunities WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Opportunity not found', 404);
    respond(['message' => 'Opportunity deleted']);
}

function list_tasks(int $contactId): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare('SELECT * FROM tasks WHERE contact_id = :id ORDER BY created_at DESC');
    $stmt->execute([':id' => $contactId]);
    $rows = $stmt->fetchAll();
    respond(['data' => $rows, 'count' => count($rows)]);
}

function create_task(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare(
        'INSERT INTO tasks (contact_id, title, status, due_date) VALUES (:c, :title, :status, :due)'
    );
    $stmt->execute([
        ':c' => $contactId,
        ':title' => normalize_optional($body['title'] ?? null) ?? 'New task',
        ':status' => in_array($body['status'] ?? '', ['Pending', 'Done'], true) ? $body['status'] : 'Pending',
        ':due' => normalize_optional($body['due_date'] ?? null) ?? '',
    ]);
    respond(['data' => ['id' => (int)db()->lastInsertId()], 'message' => 'Task created'], 201);
}

function delete_task(int $id): void
{
    $stmt = db()->prepare('DELETE FROM tasks WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Task not found', 404);
    respond(['message' => 'Task deleted']);
}

function list_notes(int $contactId): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare('SELECT * FROM notes WHERE contact_id = :id ORDER BY created_at DESC');
    $stmt->execute([':id' => $contactId]);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $row['attachments'] = $row['attachments'] !== '' && $row['attachments'] !== null
            ? array_values(array_filter(array_map('trim', explode(',', $row['attachments']))))
            : [];
    }

    respond(['data' => $rows, 'count' => count($rows)]);
}

function create_note(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);

    $attachments = array_values(array_filter(
        array_map(fn($a) => trim((string)$a), (array)($body['attachments'] ?? [])),
        fn($a) => $a !== ''
    ));

    $stmt = db()->prepare(
        'INSERT INTO notes (contact_id, title, content, author, note_color, attachments, associated_to)
         VALUES (:c, :title, :content, :author, :color, :attachments, :assoc)'
    );
    $stmt->execute([
        ':c' => $contactId,
        ':title' => normalize_optional($body['title'] ?? null) ?? 'Note',
        ':content' => normalize_optional($body['content'] ?? null) ?? '',
        ':author' => normalize_optional($body['author'] ?? null) ?? 'Asad B Zaman',
        ':color' => normalize_optional($body['note_color'] ?? null) ?? '',
        ':attachments' => $attachments ? implode(',', $attachments) : '',
        ':assoc' => normalize_optional($body['associated_to'] ?? null) ?? '',
    ]);
    respond(['data' => ['id' => (int)db()->lastInsertId()], 'message' => 'Note created'], 201);
}

function delete_note(int $id): void
{
    $stmt = db()->prepare('DELETE FROM notes WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Note not found', 404);
    respond(['message' => 'Note deleted']);
}

function list_appointments(int $contactId): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare('SELECT * FROM appointments WHERE contact_id = :id ORDER BY created_at DESC');
    $stmt->execute([':id' => $contactId]);
    $rows = $stmt->fetchAll();
    respond(['data' => $rows, 'count' => count($rows)]);
}

function create_appointment(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare(
        'INSERT INTO appointments (contact_id, title, calendar, host, date, start_time, end_time,
                                   location, status, notes, category)
         VALUES (:c, :title, :cal, :host, :date, :st, :et, :loc, :status, :notes, :cat)'
    );
    $stmt->execute([
        ':c' => $contactId,
        ':title' => normalize_optional($body['title'] ?? null) ?? 'Appointment',
        ':cal' => normalize_optional($body['calendar'] ?? null) ?? '',
        ':host' => normalize_optional($body['host'] ?? null) ?? '',
        ':date' => normalize_optional($body['date'] ?? null) ?? '',
        ':st' => normalize_optional($body['start_time'] ?? null) ?? '',
        ':et' => normalize_optional($body['end_time'] ?? null) ?? '',
        ':loc' => normalize_optional($body['location'] ?? null) ?? '',
        ':status' => normalize_optional($body['status'] ?? null) ?? 'Completed',
        ':notes' => normalize_optional($body['notes'] ?? null),
        ':cat' => ($body['category'] ?? 'past') === 'upcoming' ? 'upcoming' : 'past',
    ]);
    respond(['data' => ['id' => (int)db()->lastInsertId()], 'message' => 'Appointment created'], 201);
}

function delete_appointment(int $id): void
{
    $stmt = db()->prepare('DELETE FROM appointments WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Appointment not found', 404);
    respond(['message' => 'Appointment deleted']);
}

/** List every appointment (used by the Sites analytics tab to count test-ride bookings). */
function list_all_appointments(): void
{
    $rows = db()->query(
        'SELECT id, contact_id, title, calendar, host, date, start_time, end_time,
                location, status, notes, category, created_at
           FROM appointments ORDER BY created_at DESC'
    )->fetchAll();
    respond(['data' => $rows, 'count' => count($rows)]);
}

/** Max size (bytes) accepted for a single uploaded document. */
const DOCUMENT_MAX_BYTES = 10485760; // 10 MB

/** Create the contact_documents table on first use so no manual SQL step is required. */
function ensure_documents_table(): void
{
    db()->exec(
        "CREATE TABLE IF NOT EXISTS contact_documents (
            id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
            contact_id INT UNSIGNED NOT NULL,
            name       VARCHAR(255) NOT NULL DEFAULT '',
            size       INT UNSIGNED NOT NULL DEFAULT 0,
            mime       VARCHAR(150) NOT NULL DEFAULT '',
            tab        VARCHAR(20)  NOT NULL DEFAULT 'internal',
            data       LONGTEXT     NOT NULL,
            created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_document_contact (contact_id),
            CONSTRAINT fk_document_contact FOREIGN KEY (contact_id)
              REFERENCES contacts(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

/** List document metadata (never the file bytes) for a contact. */
function list_documents(int $contactId): void
{
    ensure_documents_table();
    ensure_contact_exists($contactId);
    $stmt = db()->prepare(
        'SELECT id, name, size, mime, tab, created_at
           FROM contact_documents
          WHERE contact_id = :id
          ORDER BY created_at DESC, id DESC'
    );
    $stmt->execute([':id' => $contactId]);
    respond(['data' => $stmt->fetchAll(), 'count' => $stmt->rowCount()]);
}

/** Store an uploaded document (base64 data URI) for a contact. */
function create_document(int $contactId, array $body): void
{
    ensure_documents_table();
    ensure_contact_exists($contactId);

    $data = (string)($body['data'] ?? '');
    if ($data === '' || !preg_match('~^data:[a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+;base64,~', $data)) {
        fail('Valid base64 document data URI required');
    }

    $comma = strpos($data, ',');
    $b64 = $comma !== false ? substr($data, $comma + 1) : '';
    if ($b64 === '') fail('Document payload is empty');

    // Guard against oversized uploads before decoding (base64 is ~4/3 the size).
    if ((strlen($b64) * 3) / 4 > DOCUMENT_MAX_BYTES + 1024) {
        fail('Document too large (max 10 MB)');
    }

    $bytes = base64_decode($b64, true);
    if ($bytes === false) fail('Document payload is not valid base64');
    $actualSize = strlen($bytes);
    if ($actualSize > DOCUMENT_MAX_BYTES) fail('Document too large (max 10 MB)');

    $tab = (string)($body['tab'] ?? 'internal');
    if (!in_array($tab, ['internal', 'sent', 'received'], true)) $tab = 'internal';

    $pdo = db();
    $stmt = $pdo->prepare(
        'INSERT INTO contact_documents (contact_id, name, size, mime, tab, data)
         VALUES (:c, :name, :size, :mime, :tab, :data)'
    );
    $stmt->execute([
        ':c' => $contactId,
        ':name' => normalize_optional($body['name'] ?? null) ?? 'document',
        ':size' => $actualSize,
        ':mime' => normalize_optional($body['mime'] ?? null) ?? '',
        ':tab' => $tab,
        ':data' => $data,
    ]);
    respond(['data' => ['id' => (int)$pdo->lastInsertId()], 'message' => 'Document uploaded'], 201);
}

function delete_document(int $id): void
{
    ensure_documents_table();
    $stmt = db()->prepare('DELETE FROM contact_documents WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Document not found', 404);
    respond(['message' => 'Document deleted']);
}

/** Stream a stored document's bytes: inline for viewing, attachment for download. */
function serve_document(int $id, bool $download = false): void
{
    ensure_documents_table();
    $stmt = db()->prepare('SELECT name, mime, data FROM contact_documents WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row || !preg_match('~^data:([a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+);base64,(.+)$~s', $row['data'], $m)) {
        http_response_code(404);
        exit;
    }
    $bytes = base64_decode($m[2], true);
    if ($bytes === false) {
        http_response_code(404);
        exit;
    }
    $mime = $row['mime'] !== '' ? $row['mime'] : $m[1];
    $filename = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)$row['name']);
    if ($filename === '') $filename = 'document-' . $id;

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . $filename . '"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    echo $bytes;
    exit;
}

/* ------------------- STAFF USERS (My Staff) ------------------- */

/** Decode a stored JSON text column into a PHP array (or [] when empty). */
function decode_json_field(?string $raw): array
{
    if ($raw === null || $raw === '') return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

/** Encode a PHP structure to JSON text (or null when empty). */
function encode_json_field($value): ?string
{
    if ($value === null) return null;
    if (is_array($value) && count($value) === 0) return null;
    $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return $json === false ? null : $json;
}

function list_staff(): void
{
    ensure_approval_column();
    ensure_manager_id_column();
    $rows = db()->query('SELECT * FROM staff_users ORDER BY full_name')->fetchAll();

    $payload = array_map('staff_payload', $rows);

    respond(['data' => $payload, 'count' => count($payload)]);
}

/** Common INSERT/UPDATE for a staff user; returns the staff id. */
function upsert_staff(array $body, ?int $existingId = null): int
{
    $firstName = normalize_optional($body['first_name'] ?? null);
    if ($firstName === null || $firstName === '') {
        fail('First name is required');
    }

    $phone = normalize_optional($body['phone'] ?? null);
    $email = normalize_optional($body['email'] ?? null);
    $lastName = normalize_optional($body['last_name'] ?? null);
    $extension = normalize_optional($body['extension'] ?? null);
    $calendar = normalize_optional($body['calendar'] ?? null);
    $systemId = normalize_optional($body['system_id'] ?? null);
    $signature = $body['signature'] ?? null;
    $avatarData = $body['avatar_data'] ?? null; // base64 data URI
    $restrictData = !empty($body['restrict_data']) ? 1 : 0;
    $userType = in_array($body['user_type'] ?? '', ['Admin', 'Dealer', 'Follower'], true) ? $body['user_type'] : 'Follower';
    // A Follower belongs to the Dealer who created them. Anyone else gets NULL.
    $managerId = null;
    if (isset($body['manager_id'])) {
        $managerId = $body['manager_id'] === null ? null : to_int((string)$body['manager_id']);
        if ($managerId !== null && $managerId <= 0) $managerId = null;
    }
    $rawPassword = isset($body['password']) && $body['password'] !== ''
        ? (string)$body['password']
        : null;
    $password = $rawPassword !== null ? hash_password($rawPassword) : null;
    if ($password !== null) ensure_password_plain_column();
    ensure_approval_column();
    ensure_manager_id_column();
    ensure_staff_roles_enum();

    // No two staff users (admin/dealer/follower) may share an email or phone
    // number, so duplicate dealer/follower accounts can never be created.
    // The form can store several values ("a@x.com, b@y.com"), so every part is
    // checked; phones are compared digits-only to ignore formatting. Existing
    // accounts are never re-validated so legacy rows keep saving fine.
    $selfId = $existingId ?? 0;
    $splitValues = static function (?string $raw): array {
        if ($raw === null || trim($raw) === '') return [];
        return array_values(array_filter(array_map('trim', explode(',', $raw)), static fn($v) => $v !== ''));
    };
    $newEmails = $existingId === null ? $splitValues($email) : [];
    $newPhones = $existingId === null ? $splitValues($phone) : [];
    if ($newEmails || $newPhones) {
        $rows = db()->prepare('SELECT full_name, email, phone FROM staff_users WHERE id <> :self');
        $rows->execute([':self' => $selfId]);
        $takenEmails = [];
        $takenPhones = [];
        foreach ($rows->fetchAll() as $r) {
            foreach ($splitValues($r['email'] ?? null) as $e) {
                $takenEmails[strtolower($e)] = $r['full_name'];
            }
            foreach ($splitValues($r['phone'] ?? null) as $p) {
                $digits = preg_replace('/\D+/', '', $p);
                if ($digits !== '') $takenPhones[$digits] = $r['full_name'];
            }
        }
        foreach ($newEmails as $e) {
            $key = strtolower($e);
            if (isset($takenEmails[$key])) {
                fail('This email (' . $e . ') is already used by "' . trim((string)$takenEmails[$key]) . '". Please use a different email.', 409);
            }
        }
        foreach ($newPhones as $p) {
            $digits = preg_replace('/\D+/', '', $p);
            if ($digits !== '' && isset($takenPhones[$digits])) {
                fail('This phone number (' . $p . ') is already used by "' . trim((string)$takenPhones[$digits]) . '". Please use a different phone number.', 409);
            }
        }
    }

    $pdo = db();

    if ($existingId !== null) {
        // manager_id is only touched when explicitly provided so a follower's
        // own profile edit never detaches them from their dealer.
        $hasManager = array_key_exists('manager_id', $body);
        $stmt = $pdo->prepare(
            'UPDATE staff_users SET first_name = :fn, last_name = :ln, email = :email, phone = :phone,
                    extension = :ext, calendar = :cal, system_id = :sid, signature = :sig,
                    avatar_data = :avatar, restrict_data = :rd, user_type = :type'
                    . ($hasManager ? ', manager_id = :mgr' : '') .
                    ', call_voicemail = :cv, availability = :av, calendar_config = :cc, permissions = :perm
                    ' . ($password !== null ? ', password = :password, password_plain = :ppassword' : '') . '
             WHERE id = :id'
        );
        $params = [
            ':fn' => $firstName,
            ':ln' => $lastName,
            ':email' => $email,
            ':phone' => $phone,
            ':ext' => $extension,
            ':cal' => $calendar,
            ':sid' => $systemId,
            ':sig' => $signature,
            ':avatar' => $avatarData,
            ':rd' => $restrictData,
            ':type' => $userType,
            ':cv' => encode_json_field($body['call_voicemail'] ?? null),
            ':av' => encode_json_field($body['availability'] ?? null),
            ':cc' => encode_json_field($body['calendar_config'] ?? null),
            ':perm' => encode_json_field($body['permissions'] ?? null),
        ];
        if ($hasManager) $params[':mgr'] = $managerId;
        if ($password !== null) {
            $params[':password'] = $password;
            $params[':ppassword'] = $rawPassword;
        }
        $params[':id'] = $existingId;
        $stmt->execute($params);
        if ($stmt->rowCount() === 0) {
            // Still succeeded if no columns changed, so verify existence.
            $check = $pdo->prepare('SELECT id FROM staff_users WHERE id = :id');
            $check->execute([':id' => $existingId]);
            if (!$check->fetch()) fail('Staff user not found', 404);
        }
        return $existingId;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO staff_users (first_name, last_name, email, phone, extension, calendar, system_id,
                                  signature, avatar_data, restrict_data, user_type, manager_id,
                                  call_voicemail, availability, calendar_config, permissions'
                                  . ($password !== null ? ', password, password_plain' : '') . ')
         VALUES (:fn, :ln, :email, :phone, :ext, :cal, :sid, :sig, :avatar, :rd, :type, :mgr,
                 :cv, :av, :cc, :perm'
                 . ($password !== null ? ', :password, :ppassword' : '') . ')'
    );
    $insertParams = [
        ':fn' => $firstName,
        ':ln' => $lastName,
        ':email' => $email,
        ':phone' => $phone,
        ':ext' => $extension,
        ':cal' => $calendar,
        ':sid' => $systemId,
        ':sig' => $signature,
        ':avatar' => $avatarData,
        ':rd' => $restrictData,
        ':type' => $userType,
        ':mgr' => $managerId,
        ':cv' => encode_json_field($body['call_voicemail'] ?? null),
        ':av' => encode_json_field($body['availability'] ?? null),
        ':cc' => encode_json_field($body['calendar_config'] ?? null),
        ':perm' => encode_json_field($body['permissions'] ?? null),
    ];
    if ($password !== null) {
        $insertParams[':password'] = $password;
        $insertParams[':ppassword'] = $rawPassword;
    }
    $stmt->execute($insertParams);
    return (int)$pdo->lastInsertId();
}

function create_staff(array $body): void
{
    $rawPasswordProvided = isset($body['password']) && trim((string)$body['password']) !== '';
    // If no password was supplied, auto-generate one so the new user can be
    // emailed working credentials instead of being locked out.
    $rawPassword = $rawPasswordProvided ? (string)$body['password'] : generate_strong_password();
    if (!$rawPasswordProvided) {
        $body['password'] = $rawPassword;
    }

    try {
        $id = upsert_staff($body, null);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') fail('Duplicate email already exists', 409);
        fail('Database error: ' . $e->getMessage(), 500);
    }

    // Send the new team member a welcome email with their login details.
    $email = normalize_optional($body['email'] ?? null);
    if ($email !== null) {
        $name = trim((string)($body['first_name'] ?? '') . ' ' . (string)($body['last_name'] ?? ''));
        $loginUrl = (defined('APP_URL') ? APP_URL : '') . '/';
        $esc = static fn ($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
        $p = 'style="margin:0 0 12px 0;font-size:14px;line-height:22px;color:#334155;"';
        $bodyHtml =
            '<p ' . $p . '>Hi ' . $esc($name !== '' ? $name : 'there') . ',</p>'
            . '<p ' . $p . '>Welcome! An account has been created for you on <strong>Expert Builders & Developers</strong>. Your login details are below:</p>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin:0 0 16px 0;">'
            . '<tr><td style="padding:10px 14px 4px 14px;font-size:13px;color:#334155;"><strong>Email:</strong> ' . $esc($email) . '</td></tr>'
            . '<tr><td style="padding:4px 14px 10px 14px;font-size:13px;color:#334155;"><strong>Password:</strong> ' . $esc($rawPassword) . '</td></tr>'
            . '</table>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 16px 0;"><tr><td style="background-color:#EB5F1B;border-radius:8px;">'
            . '<a href="' . htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8') . '" style="display:inline-block;padding:11px 26px;font-size:14px;font-weight:bold;color:#ffffff;text-decoration:none;">Log in here</a>'
            . '</td></tr></table>'
            . '<p ' . $p . '>Please log in and change your password once you are in.</p>';
        send_app_mail($email, $name, 'Your Expert Builders & Developers account has been created', $bodyHtml);
    }

    respond(['data' => ['id' => $id], 'message' => 'Staff user created'], 201);
}

function update_staff(int $id, array $body): void
{
    try {
        $updated = upsert_staff($body, $id);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') fail('Duplicate email already exists', 409);
        fail('Database error: ' . $e->getMessage(), 500);
    }
    respond(['data' => ['id' => $updated], 'message' => 'Staff user updated']);
}

function delete_staff(int $id): void
{
    $stmt = db()->prepare('DELETE FROM staff_users WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Staff user not found', 404);
    respond(['message' => 'Staff user deleted']);
}

/** Update a contact: mainly for assigning a staff owner (assigned_to). */
function update_contact(int $id, array $body): void
{
    ensure_contact_exists($id);

    // Verify assigned staff exists when provided.
    $assignedTo = null;
    if (array_key_exists('assigned_to', $body)) {
        $assignedTo = $body['assigned_to'] === null ? null : to_int((string)$body['assigned_to']);
        if ($assignedTo !== null && $assignedTo > 0) {
            $check = db()->prepare('SELECT id FROM staff_users WHERE id = :id');
            $check->execute([':id' => $assignedTo]);
            if (!$check->fetch()) fail('Assigned staff user not found', 404);
        }
    }

    $allowed = ['first_name', 'last_name', 'phone', 'email', 'business_name', 'contact_type', 'notes', 'avatar_data', 'avatar_color'];
    $sets = [];
    $params = [':id' => $id];

    foreach ($allowed as $field) {
        if (array_key_exists($field, $body)) {
            $value = normalize_optional($body[$field]);
            if ($field === 'contact_type') {
                $value = in_array($value ?? '', ['Lead', 'Customer', 'Vendor', 'Partner'], true) ? $value : '';
            }
            $sets[] = "$field = :$field";
            $params[":$field"] = $value;
        }
    }

    if (array_key_exists('custom_fields', $body)) {
        $sets[] = 'custom_fields = :custom_fields';
        $params[':custom_fields'] = normalize_custom_fields($body['custom_fields']);
    }

    // Replace the full tag set when the request includes a "tags" list.
    if (array_key_exists('tags', $body)) {
        $tagInput = array_values(array_filter(
            array_map(fn($t) => trim((string)$t), (array)$body['tags']),
            fn($t) => $t !== ''
        ));
        $pdo = db();
        $pdo->prepare('DELETE FROM contact_tags WHERE contact_id = :id')->execute([':id' => $id]);
        foreach ($tagInput as $tagName) {
            $tagId = ensure_tag($pdo, $tagName);
            if ($tagId > 0) {
                $pdo->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (:c, :t)')
                    ->execute([':c' => $id, ':t' => $tagId]);
            }
        }
        // Keep is_lead consistent with the new tag set / contact type.
        $lead = ($body['contact_type'] ?? '') === 'Lead'
            || in_array('warm lead', $tagInput, true)
            || in_array('hot lead', $tagInput, true)
            || in_array('cold lead', $tagInput, true);
        $sets[] = 'is_lead = :is_lead';
        $params[':is_lead'] = $lead ? 1 : 0;
    } elseif (array_key_exists('contact_type', $body)) {
        // Type-only edit (no tags sent): keep is_lead consistent so switching
        // Lead <-> Customer is reflected in the Leads smart list immediately.
        $sets[] = 'is_lead = :is_lead';
        $params[':is_lead'] = ($body['contact_type'] === 'Lead') ? 1 : 0;
    }

    if ($assignedTo !== null || array_key_exists('assigned_to', $body)) {
        $sets[] = 'assigned_to = :assigned_to';
        $params[':assigned_to'] = $assignedTo;
    }

    if (!$sets) fail('No fields to update');

    // Every successful edit bumps the activity timestamp so the table's
    // "Last activity" column reflects people editing the contact.
    $sets[] = 'last_activity_at = NOW()';

    $pdo = db();
    $pdo->beginTransaction();
    try {
        // Capture the previous owner + contact name so we only notify on change.
        $prev = $pdo->prepare('SELECT assigned_to, full_name FROM contacts WHERE id = :id');
        $prev->execute([':id' => $id]);
        $prevRow = $prev->fetch();
        $prevOwner = $prevRow ? (int)($prevRow['assigned_to'] ?? 0) : 0;
        $contactName = $prevRow['full_name'] ?? 'Contact';

        $stmt = $pdo->prepare('UPDATE contacts SET ' . implode(', ', $sets) . ' WHERE id = :id');
        $stmt->execute($params);

        // Mutual exclusion: the new owner can no longer be a follower.
        if ($assignedTo !== null && $assignedTo > 0) {
            $pdo->prepare('DELETE FROM contact_followers WHERE contact_id = :c AND staff_id = :s')
                ->execute([':c' => $id, ':s' => $assignedTo]);
        }

        $pdo->commit();

        // Notify the new owner only when the assignment actually changed.
        if ($assignedTo !== null && $assignedTo > 0 && $assignedTo !== $prevOwner) {
            notify_staff(
                $assignedTo,
                $id,
                'lead_assigned',
                'New lead assigned to you',
                $contactName . ' has been assigned to you.'
            );
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    respond(['data' => ['id' => $id], 'message' => 'Contact updated']);
}

/** List the staff users following a contact. */
function list_followers(int $contactId): void
{
    ensure_contact_exists($contactId);
    $rows = db()->prepare(
        'SELECT s.id, s.first_name, s.last_name, s.full_name, s.user_type, s.avatar_data
           FROM contact_followers cf
           JOIN staff_users s ON s.id = cf.staff_id
          WHERE cf.contact_id = :id
          ORDER BY s.full_name'
    );
    $rows->execute([':id' => $contactId]);
    respond(['data' => $rows->fetchAll(), 'count' => $rows->rowCount()]);
}

/** Add a follower. Owner and follower are mutually exclusive: a follower can
 *  never be the assigned owner, and the assigned owner can never be a follower. */
function add_follower(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);
    $staffId = to_int((string)($body['staff_id'] ?? 0));
    if ($staffId <= 0) fail('staff_id is required');

    $check = db()->prepare('SELECT id FROM staff_users WHERE id = :id');
    $check->execute([':id' => $staffId]);
    if (!$check->fetch()) fail('Staff user not found', 404);

    $pdo = db();
    $nmStmt = $pdo->prepare('SELECT full_name FROM contacts WHERE id = :id');
    $nmStmt->execute([':id' => $contactId]);
    $nmRow = $nmStmt->fetch();
    $contactName = $nmRow['full_name'] ?? 'Contact';

    $pdo->beginTransaction();
    try {
        // Mutual exclusion: if this staff is the assigned owner, remove that role.
        $pdo->prepare('UPDATE contacts SET assigned_to = NULL WHERE id = :cid AND assigned_to = :sid')
            ->execute([':cid' => $contactId, ':sid' => $staffId]);

        $stmt = $pdo->prepare('INSERT IGNORE INTO contact_followers (contact_id, staff_id) VALUES (:c, :s)');
        $stmt->execute([':c' => $contactId, ':s' => $staffId]);
        $added = $stmt->rowCount() > 0;
        $pdo->commit();

        if ($added) {
            notify_staff(
                $staffId,
                $contactId,
                'follower_added',
                'You are now following a contact',
                'You have been added as a follower of ' . $contactName . '.'
            );
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    respond(['message' => 'Follower added'], 201);
}

/** Remove a follower. */
function remove_follower(int $contactId, int $staffId): void
{
    ensure_contact_exists($contactId);
    $stmt = db()->prepare('DELETE FROM contact_followers WHERE contact_id = :c AND staff_id = :s');
    $stmt->execute([':c' => $contactId, ':s' => $staffId]);
    if ($stmt->rowCount() === 0) fail('Follower not found', 404);
    respond(['message' => 'Follower removed']);
}

/** List persisted activity entries for a contact. */
function list_activities(int $contactId): void
{
    ensure_contact_exists($contactId);
    $rows = db()->prepare(
        'SELECT id, type, title, detail, created_at
           FROM contact_activities
          WHERE contact_id = :id
          ORDER BY created_at DESC, id DESC'
    );
    $rows->execute([':id' => $contactId]);
    respond(['data' => $rows->fetchAll(), 'count' => $rows->rowCount()]);
}

/** Persist an activity entry for a contact (date/time + URL detail). */
function create_activity(int $contactId, array $body): void
{
    ensure_contact_exists($contactId);
    $type = normalize_optional($body['type'] ?? null) ?? 'contact';
    $title = normalize_optional($body['title'] ?? null);
    $detail = normalize_optional($body['detail'] ?? null);
    if ($title === null) fail('title is required');

    $pdo = db();
    $stmt = $pdo->prepare(
        'INSERT INTO contact_activities (contact_id, type, title, detail, created_at)
         VALUES (:c, :type, :title, :detail, NOW())'
    );
    $stmt->execute([':c' => $contactId, ':type' => $type, ':title' => $title, ':detail' => $detail]);

    respond(['data' => ['id' => (int)$pdo->lastInsertId()], 'message' => 'Activity logged']);
}

/* ----------------------- AUTH & NOTIFICATIONS ----------------------- */

/** Shape a staff row for API responses: decode JSON fields, hide password. */
function staff_payload(array $row): array
{
    unset($row['password'], $row['password_plain']);
    $row['call_voicemail'] = decode_json_field($row['call_voicemail'] ?? null);
    $row['availability'] = decode_json_field($row['availability'] ?? null);
    $row['calendar_config'] = decode_json_field($row['calendar_config'] ?? null);
    $row['permissions'] = decode_json_field($row['permissions'] ?? null);
    return $row;
}

/**
 * Signed, stateless one-click login token for approval emails.
 * Payload = email|expiry|HMAC(password_hash). Valid for 30 minutes and
 * automatically invalidated the moment the account's password changes.
 */
function make_login_token(array $row): string
{
    $expires = (string)(time() + 1800);
    $payload = ($row['email'] ?? '') . '|' . $expires;
    $sig = hash_hmac('sha256', $payload, ($row['password'] ?? '') . '|yadea-magic-login');
    return rtrim(strtr(base64_encode($payload . '|' . $sig), '+/', '-_'), '=');
}

/** Validate a magic login token; returns the staff row or null. */
function verify_login_token(string $token): ?array
{
    $raw = base64_decode(strtr($token, '-_', '+/'), true);
    if ($raw === false) return null;
    $parts = explode('|', $raw);
    if (count($parts) !== 3) return null;
    [$email, $expires, $sig] = $parts;
    if (!ctype_digit($expires) || (int)$expires < time() || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM staff_users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch();
    if (!$row) return null;
    $expected = hash_hmac('sha256', $email . '|' . $expires, ($row['password'] ?? '') . '|yadea-magic-login');
    if (!hash_equals($expected, $sig)) return null;
    return $row;
}

/** POST /auth/magic-login { token } -> session payload like /auth/login. */
function magic_login(array $body): void
{
    $token = trim((string)($body['token'] ?? ''));
    if ($token === '') fail('Token is required', 400);
    $row = verify_login_token($token);
    if (!$row) fail('This login link is invalid or has expired. Please sign in manually.', 401);
    if ((int)($row['approved'] ?? 1) !== 1) {
        fail('Your account is pending admin approval.', 403);
    }
    respond(['data' => staff_payload($row), 'message' => 'Login successful']);
}

/** POST /auth/login  { email, password } -> the staff user or 401. */
function login(array $body): void
{
    $email = normalize_optional($body['email'] ?? null);
    $password = (string)($body['password'] ?? '');
    if ($email === null || $password === '') {
        fail('Email and password are required', 400);
    }

    $stmt = db()->prepare('SELECT * FROM staff_users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch();
    if (!$row || !verify_password($password, $row['password'] ?? null)) {
        fail('Invalid email or password', 401);
    }
    // Accounts created through public registration stay locked until an
    // Admin approves them under Settings -> My Staff.
    if (isset($row['approved']) && (int)$row['approved'] !== 1) {
        fail('Your account is pending admin approval. You will receive an email once it is approved.', 403);
    }

    respond(['data' => staff_payload($row), 'message' => 'Login successful']);
}

/**
 * Lazy migration: staff_users.password_plain keeps a recoverable copy of the
 * password so auto-provisioned dealers can see it again in account settings.
 */
function ensure_password_plain_column(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $check = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'staff_users'
            AND COLUMN_NAME  = 'password_plain'"
    );
    $check->execute();
    if ((int)$check->fetchColumn() === 0) {
        db()->exec(
            "ALTER TABLE staff_users ADD COLUMN password_plain VARCHAR(255) DEFAULT NULL AFTER password"
        );
    }
}

/**
 * Lazy migration: staff_users.approved gates logins. Defaults to 1 so
 * admin-created staff are never locked out; public registrations insert 0
 * and wait for an Admin to approve them under Settings -> My Staff.
 */
function ensure_approval_column(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $check = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'staff_users'
            AND COLUMN_NAME  = 'approved'"
    );
    $check->execute();
    if ((int)$check->fetchColumn() === 0) {
        db()->exec(
            "ALTER TABLE staff_users ADD COLUMN approved TINYINT(1) NOT NULL DEFAULT 1 AFTER password_plain"
        );
    }
}

/**
 * Lazy migration: staff_users.manager_id lets a Dealer own their Followers.
 * Kept defensive so admin-created Followers never fail to INSERT when the
 * dedicated staff_roles.sql migration has not been applied to the database.
 */
function ensure_manager_id_column(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $check = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'staff_users'
            AND COLUMN_NAME  = 'manager_id'"
    );
    $check->execute();
    if ((int)$check->fetchColumn() === 0) {
        db()->exec(
            "ALTER TABLE staff_users ADD COLUMN manager_id INT UNSIGNED DEFAULT NULL AFTER user_type"
        );
    }
}

/**
 * Lazy migration: staff_users.user_type must accept Admin/Dealer/Follower.
 * staff.sql originally created ENUM('Admin','User'); without this, saving a
 * 'Dealer' or 'Follower' row is rejected in strict mode (or silently emptied).
 * Only re-runs the ALTER when the new values are missing from the column def.
 */
function ensure_staff_roles_enum(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $check = db()->prepare(
        "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'staff_users'
            AND COLUMN_NAME  = 'user_type'"
    );
    $check->execute();
    $type = (string)($check->fetchColumn() ?: '');
    if ($type !== '' && !str_contains($type, 'Dealer') && !str_contains($type, 'Follower')) {
        db()->exec(
            "ALTER TABLE staff_users MODIFY user_type ENUM('Admin', 'Dealer', 'Follower') NOT NULL DEFAULT 'Follower'"
        );
    }
}

/**
 * Soft-delete support for contacts: DELETE always keeps the row, it just stamps
 * deleted_at so the live views hide it. Idempotent migration (safe to run on
 * every request) that (1) adds contacts.deleted_at when missing and (2) rebuilds
 * v_contacts_with_tags / v_leads to exclude soft-deleted rows. The rebuilt views
 * match the production shape (custom_fields + assigned_to staff join).
 */
function ensure_soft_delete_support(): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    $pdo = db();

    // 1) Column migration.
    $colCheck = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'contacts'
            AND COLUMN_NAME  = 'deleted_at'"
    );
    $colCheck->execute();
    if ((int)$colCheck->fetchColumn() === 0) {
        $pdo->exec('ALTER TABLE contacts ADD COLUMN deleted_at DATETIME DEFAULT NULL AFTER notes');
    }

    // 2) View migration: rebuild only when the view still lacks deleted_at (idempotent).
    $viewCheck = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'v_contacts_with_tags'
            AND COLUMN_NAME  = 'deleted_at'"
    );
    $viewCheck->execute();
    if ((int)$viewCheck->fetchColumn() > 0) return;

    $pdo->exec('DROP VIEW IF EXISTS v_leads');
    $pdo->exec('DROP VIEW IF EXISTS v_contacts_with_tags');
    $pdo->exec(
        "CREATE VIEW v_contacts_with_tags AS
         SELECT
           c.id,
           c.full_name            AS name,
           c.first_name,
           c.last_name,
           c.phone,
           c.email,
           c.business_name,
           c.contact_type,
           c.is_lead,
           c.avatar_color,
           c.avatar_data,
           c.assigned_to,
           CONCAT(s.first_name, ' ', s.last_name) AS assigned_to_name,
           s.avatar_data AS assigned_to_avatar,
           c.notes,
           c.deleted_at,
           c.custom_fields,
           c.created_at,
           c.last_activity_at,
           c.updated_at,
           COALESCE(GROUP_CONCAT(t.name ORDER BY t.name SEPARATOR ','), '') AS tags,
           COALESCE(GROUP_CONCAT(t.id   ORDER BY t.name SEPARATOR ','), '') AS tag_ids
         FROM contacts c
         LEFT JOIN staff_users s ON s.id = c.assigned_to
         LEFT JOIN contact_tags ct ON ct.contact_id = c.id
         LEFT JOIN tags t         ON t.id         = ct.tag_id
         WHERE c.deleted_at IS NULL
         GROUP BY c.id"
    );
    $pdo->exec(
        "CREATE VIEW v_leads AS
         SELECT *
         FROM v_contacts_with_tags
         WHERE is_lead = 1
            OR contact_type = 'Lead'
            OR FIND_IN_SET('warm lead', tags)
            OR FIND_IN_SET('hot lead',  tags)
            OR FIND_IN_SET('cold lead', tags)"
    );
}

/**
 * Branded confirmation email sent to a dealer right after they submit the
 * dealership form. Includes their website credentials (when known) and tells
 * them whether they can already log in or must wait for admin approval.
 */
function send_dealer_registration_mail(string $email, string $name, ?string $plain, bool $approved): void
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return;
    $esc = static fn ($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

    $p = 'style="margin:0 0 12px 0;font-size:14px;line-height:22px;color:#334155;"';
    $html = '<p ' . $p . '>Hi ' . $esc($name !== '' ? $name : 'there') . ',</p>'
        . '<p ' . $p . '>Thank you for registering as a dealer with <strong>Expert Builders & Developers</strong>. '
        . 'We have received your dealership registration form successfully.</p>';

    if ($plain !== null && $plain !== '') {
        $html .= '<p style="margin:0 0 8px 0;font-size:14px;color:#334155;">Your website account details:</p>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin:0 0 16px 0;">'
            . '<tr><td style="padding:10px 14px 4px 14px;font-size:13px;color:#334155;"><strong>Email:</strong> ' . $esc($email) . '</td></tr>'
            . '<tr><td style="padding:4px 14px 10px 14px;font-size:13px;color:#334155;"><strong>Password:</strong> ' . $esc($plain) . '</td></tr>'
            . '</table>';
    }

    if ($approved) {
        $html .= '<p ' . $p . '>Your account is already <strong style="color:#059669;">active</strong> — you can log in anytime using the details above.</p>';
    } else {
        $html .= '<p ' . $p . '>Your account is currently <strong style="color:#B45309;">pending administrator approval</strong>. '
            . 'Login stays disabled until our team approves your registration — you will receive a second email '
            . 'with a login button as soon as that happens.</p>';
    }

    send_app_mail($email, $name, 'We received your dealership registration', $html);
}

/**
 * POST /auth/register-dealer
 * Public endpoint used by the Dealership Registration form: finds or creates
 * a Dealer staff account for the submitted email and returns it together with
 * the working password so the website can log the dealer in automatically.
 */
function register_dealer(array $body): void
{
    $email = normalize_optional($body['email'] ?? null);
    if ($email === null || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('A valid email is required', 400);
    }
    $firstName = normalize_optional($body['first_name'] ?? null) ?? 'New';
    $lastName = normalize_optional($body['last_name'] ?? null) ?? 'Dealer';
    $phone = normalize_optional($body['phone'] ?? null);
    // "Dealership Code" from the form is stored as the staff system_id so it
    // shows up in My Staff and the sidebar workspace box.
    $systemId = normalize_optional($body['dealership_code'] ?? null);

    ensure_password_plain_column();
    ensure_approval_column();
    ensure_staff_roles_enum();
    $pdo = db();

    $findByEmail = $pdo->prepare('SELECT * FROM staff_users WHERE email = :email LIMIT 1');
    $findByEmail->execute([':email' => $email]);
    $existing = $findByEmail->fetch();

    // Existing dealers keep their profile in sync when they register again:
    // a freshly entered Dealership Code updates the stored system_id.
    if ($existing && $systemId !== null && ($existing['system_id'] ?? null) !== $systemId) {
        $pdo->prepare('UPDATE staff_users SET system_id = :sid WHERE id = :id')
            ->execute([':sid' => $systemId, ':id' => $existing['id']]);
        $existing['system_id'] = $systemId;
    }

    // Already an account AND we still know its password: hand it back as-is.
    if ($existing && !empty($existing['password_plain'])) {
        send_dealer_registration_mail(
            $email,
            trim($firstName . ' ' . $lastName),
            (string)$existing['password_plain'],
            (int)($existing['approved'] ?? 1) === 1
        );
        respond([
            'data' => staff_payload($existing),
            'password' => $existing['password_plain'],
            'message' => 'Existing dealer account',
        ]);
    }

    // New account, or an existing one whose password is not recoverable:
    // (re)set the credentials so this submitter can always be logged in.
    $plain = generate_strong_password();
    $hash = hash_password($plain);

    if ($existing) {
        $upd = $pdo->prepare(
            'UPDATE staff_users SET password = :p, password_plain = :pp WHERE id = :id'
        );
        $upd->execute([':p' => $hash, ':pp' => $plain, ':id' => $existing['id']]);
        $findByEmail->execute([':email' => $email]);
        send_dealer_registration_mail(
            $email,
            trim($firstName . ' ' . $lastName),
            $plain,
            (int)($existing['approved'] ?? 1) === 1
        );
        respond([
            'data' => staff_payload($findByEmail->fetch()),
            'password' => $plain,
            'message' => 'Existing dealer account credentials reset',
        ]);
    }

    try {
        $ins = $pdo->prepare(
            'INSERT INTO staff_users (first_name, last_name, email, phone, system_id,
                                      user_type, restrict_data, password, password_plain, approved)
             VALUES (:fn, :ln, :email, :phone, :sid, \'Dealer\', 0, :p, :pp, 0)'
        );
        $ins->execute([
            ':fn' => $firstName,
            ':ln' => $lastName,
            ':email' => $email,
            ':phone' => $phone,
            ':sid' => $systemId,
            ':p' => $hash,
            ':pp' => $plain,
        ]);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            // Raced with another submission for the same email.
            $findByEmail->execute([':email' => $email]);
            $row = $findByEmail->fetch();
            send_dealer_registration_mail(
                $email,
                trim($firstName . ' ' . $lastName),
                $row['password_plain'] ?? null,
                (int)($row['approved'] ?? 1) === 1
            );
            respond([
                'data' => staff_payload($row),
                'password' => $row['password_plain'] ?? null,
                'message' => 'Existing dealer account',
            ]);
        }
        fail('Database error: ' . $e->getMessage(), 500);
    }

    $get = $pdo->prepare('SELECT * FROM staff_users WHERE id = :id');
    $get->execute([':id' => (int)$pdo->lastInsertId()]);
    $created = $get->fetch();

    // Every Admin learns about the pending registration on their portal
    // (notifications bell) and by email, so they can approve it quickly.
    $dealerName = trim($firstName . ' ' . $lastName);
    $detail = 'New dealer registration: ' . $dealerName . ' (' . $email . ')'
        . ' is waiting for approval under Settings -> My Staff.';
    $admins = $pdo->query("SELECT id FROM staff_users WHERE user_type = 'Admin'")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($admins as $adminId) {
        notify_staff((int)$adminId, null, 'dealer_registration', 'New dealer registration', $detail);
    }

    // Confirmation + credentials email to the dealer who filled the form.
    send_dealer_registration_mail($email, $dealerName, $plain, false);

    respond([
        'data' => staff_payload($created),
        'password' => $plain,
        'message' => 'Dealer account created and pending approval',
    ], 201);
}

/**
 * POST /staff/{id}/approve
 * Admin action from Settings -> My Staff: unlocks the account, drops a
 * portal notification for the user and emails them a login link.
 */
function approve_staff(int $id): void
{
    ensure_approval_column();
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM staff_users WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) fail('Staff user not found', 404);

    if ((int)($row['approved'] ?? 1) !== 1) {
        $upd = $pdo->prepare('UPDATE staff_users SET approved = 1 WHERE id = :id');
        $upd->execute([':id' => $id]);
    }

    $name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
    $loginUrl = (defined('APP_URL') ? APP_URL : '') . '/';

    // One-click signed login link: opens the CRM already signed in as this
    // user. Falls back to the normal login page when the token is expired.
    $magicUrl = $loginUrl . '#/magic-login/' . make_login_token($row);

    // Portal notification for the approved user.
    notify_staff($id, null, 'account_approved', 'Account approved', 'Your account has been approved. You can now log in to the website.');

    // Richer approval email with the one-click login button.
    if (!empty($row['email'])) {
        $bodyHtml = '<p style="margin:0 0 12px 0;font-size:14px;line-height:22px;color:#334155;">Hi '
            . htmlspecialchars($name !== '' ? $name : 'there', ENT_QUOTES, 'UTF-8') . ',</p>'
            . '<p style="margin:0 0 16px 0;font-size:14px;line-height:22px;color:#334155;">Good news! Your dealership registration has been <strong style="color:#059669;">approved</strong>. Click the button below and you will be signed in to your account right away.</p>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 16px 0;"><tr><td style="background-color:#EB5F1B;border-radius:8px;">'
            . '<a href="' . htmlspecialchars($magicUrl, ENT_QUOTES, 'UTF-8') . '" style="display:inline-block;padding:11px 26px;font-size:14px;font-weight:bold;color:#ffffff;text-decoration:none;">Login to your account</a>'
            . '</td></tr></table>'
            . '<p style="margin:0;font-size:13px;line-height:20px;color:#64748b;">The button signs you in directly. If it has expired or does not work, sign in with your email and password at:<br>'
            . '<a href="' . htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8') . '" style="color:#EB5F1B;word-break:break-all;">' . htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8') . '</a></p>';
        send_app_mail(
            (string)$row['email'],
            $name,
            'Your dealership registration is approved',
            $bodyHtml
        );
    }

    $stmt->execute([':id' => $id]);
    respond(['data' => staff_payload($stmt->fetch()), 'message' => 'User approved']);
}

/** POST /auth/reveal-password { email } -> stored plain password (or null). */
function reveal_password(array $body): void
{
    $email = normalize_optional($body['email'] ?? null);
    if ($email === null) fail('Email is required');
    ensure_password_plain_column();
    $stmt = db()->prepare('SELECT password_plain FROM staff_users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch();
    respond(['data' => ['password' => $row['password_plain'] ?? null]]);
}

/**
 * Create a notification row for a staff user and attempt a best-effort
 * email. $contactId may be null (e.g. generic messages). Returns the id.
 */
function notify_staff(int $staffId, ?int $contactId, string $type, string $title, string $detail): int
{
    $pdo = db();
    $stmt = $pdo->prepare(
        'INSERT INTO notifications (staff_id, contact_id, type, title, detail, created_at)
         VALUES (:sid, :cid, :type, :title, :detail, NOW())'
    );
    $stmt->execute([
        ':sid' => $staffId,
        ':cid' => $contactId,
        ':type' => $type,
        ':title' => text_clip($title, 250),
        ':detail' => text_clip($detail, 495),
    ]);
    $id = (int)$pdo->lastInsertId();

    // Best-effort email copy of the notification.
    $recipient = $pdo->prepare('SELECT email, first_name, last_name FROM staff_users WHERE id = :id');
    $recipient->execute([':id' => $staffId]);
    $r = $recipient->fetch();
    if ($r && ($r['email'] ?? null) !== null) {
        $name = trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''));
        $body = '<p>Hi ' . htmlspecialchars($name ?: 'there') . ',</p>'
            . '<p>' . htmlspecialchars($title) . '</p>'
            . '<p>' . htmlspecialchars($detail) . '</p>'
            . '<p style="color:#64748b;font-size:12px">Expert Builders CRM Notification</p>';
        send_notification_email($r['email'], $title, $body);
    }

    return $id;
}

/** GET /notifications?staff_id=N[&unread=1] -> list for one user. */
function list_notifications(array $filters): void
{
    $staffId = to_int((string)($filters['staff_id'] ?? 0));
    if ($staffId <= 0) fail('staff_id is required');

    $where = 'n.staff_id = :sid';
    $params = [':sid' => $staffId];
    if (!empty($filters['unread'])) {
        $where .= ' AND n.is_read = 0';
    }

    $rows = db()->prepare(
        'SELECT n.id, n.contact_id, n.type, n.title, n.detail, n.is_read, n.created_at,
                c.full_name AS contact_name
           FROM notifications n
           LEFT JOIN contacts c ON c.id = n.contact_id
          WHERE ' . $where . '
          ORDER BY n.created_at DESC, n.id DESC
          LIMIT 100'
    );
    $rows->execute($params);
    $data = $rows->fetchAll();

    // Timestamps are stored in the MySQL server's own timezone; tag them
    // with that UTC offset so browsers compute "x minutes ago" correctly
    // no matter which timezone the client is in.
    $offRow = db()->query(
        'SELECT SEC_TO_TIME(TIMESTAMPDIFF(SECOND, UTC_TIMESTAMP(), NOW())) AS o'
    )->fetch();
    $raw = (string)($offRow['o'] ?? '00:00:00');
    $sign = $raw !== '' && $raw[0] === '-' ? '-' : '+';
    $parts = array_pad(explode(':', ltrim($raw, '-')), 3, '0');
    $off = sprintf('%s%02d:%02d', $sign, (int)$parts[0], (int)$parts[1]);
    foreach ($data as &$row) {
        if (!empty($row['created_at'])) {
            $row['created_at'] = date('Y-m-d\TH:i:s', strtotime($row['created_at'])) . $off;
        }
    }
    unset($row);

    respond(['data' => $data, 'count' => count($data)]);
}

/** GET /notifications/unread-count?staff_id=N */
function notifications_unread_count(int $staffId): void
{
    if ($staffId <= 0) fail('staff_id is required');
    $stmt = db()->prepare('SELECT COUNT(*) FROM notifications WHERE staff_id = :sid AND is_read = 0');
    $stmt->execute([':sid' => $staffId]);
    respond(['data' => ['unread' => (int)$stmt->fetchColumn()]]);
}

/** POST /notifications/{id}/read */
function mark_notification_read(int $id): void
{
    $stmt = db()->prepare('UPDATE notifications SET is_read = 1 WHERE id = :id');
    $stmt->execute([':id' => $id]);
    respond(['message' => 'Notification marked as read']);
}

/** POST /notifications/read-all  { staff_id } */
function mark_all_notifications_read(array $body): void
{
    $staffId = to_int((string)($body['staff_id'] ?? 0));
    if ($staffId <= 0) fail('staff_id is required');
    db()->prepare('UPDATE notifications SET is_read = 1 WHERE staff_id = :sid AND is_read = 0')
        ->execute([':sid' => $staffId]);
    respond(['message' => 'All notifications marked as read']);
}

/**
 * POST /notifications  { staff_ids: [], contact_id?, type?, title, detail }
 * Generic client-side notification (e.g. @mention in an internal comment,
 * or a message sent to a contact whose owner/followers should be notified).
 */
function create_notification(array $body): void
{
    $staffIds = array_values(array_unique(array_map(
        'to_int',
        array_filter((array)($body['staff_ids'] ?? []), fn($s) => (int)$s > 0)
    )));
    if (!$staffIds) fail('staff_ids is required');

    $contactId = isset($body['contact_id']) && (int)$body['contact_id'] > 0
        ? (int)$body['contact_id'] : null;
    $type = normalize_optional($body['type'] ?? null) ?? 'assignment';
    $title = normalize_optional($body['title'] ?? null) ?? 'New notification';
    $detail = normalize_optional($body['detail'] ?? null) ?? '';

    $ids = [];
    foreach ($staffIds as $sid) {
        $ids[] = notify_staff($sid, $contactId, $type, $title, $detail);
    }
    respond(['data' => ['ids' => $ids, 'count' => count($ids)], 'message' => 'Notification(s) created'], 201);
}

/* ----------------------- DEALER / FRANCHISE DASHBOARD ----------------------- */

/**
 * Summary for the owner: per-dealer (User role) lead assignment counts and
 * how many unassigned leads are still waiting to be handed out.
 */
function dealer_dashboard_summary(): void
{
    $rows = db()->query(
        "SELECT s.id AS dealer_id, s.full_name, s.email, s.phone, s.avatar_data,
                COUNT(v.id) AS total,
                SUM(CASE WHEN v.id IS NOT NULL AND COALESCE(dls.status, 'non_contacted') = 'non_contacted' THEN 1 ELSE 0 END) AS non_contacted,
                SUM(CASE WHEN v.id IS NOT NULL AND COALESCE(dls.status, 'non_contacted') = 'contacted' THEN 1 ELSE 0 END) AS contacted,
                SUM(CASE WHEN v.id IS NOT NULL AND COALESCE(dls.status, 'non_contacted') = 'closed' THEN 1 ELSE 0 END) AS closed,
                SUM(CASE WHEN v.id IS NOT NULL AND COALESCE(dls.status, 'non_contacted') = 'customer' THEN 1 ELSE 0 END) AS customer,
                SUM(CASE WHEN v.id IS NOT NULL AND COALESCE(dls.status, 'non_contacted') = 'rejected' THEN 1 ELSE 0 END) AS rejected
           FROM staff_users s
           LEFT JOIN v_leads v ON v.assigned_to = s.id
           LEFT JOIN dealer_lead_status dls ON dls.contact_id = v.id AND dls.dealer_id = s.id
          WHERE s.user_type = 'Dealer'
          GROUP BY s.id, s.full_name, s.email, s.phone, s.avatar_data
          ORDER BY s.full_name"
    )->fetchAll();

    foreach ($rows as &$r) {
        foreach (['total', 'non_contacted', 'contacted', 'closed', 'customer', 'rejected'] as $k) {
            $r[$k] = (int)$r[$k];
        }
    }

    $un = db()->query(
        "SELECT COUNT(*) AS c FROM v_leads v
          WHERE v.assigned_to IS NULL
            AND NOT EXISTS (SELECT 1 FROM dealer_lead_status d WHERE d.contact_id = v.id)"
    )->fetch();
    $unassigned = (int)($un['c'] ?? 0);

    respond(['data' => ['dealers' => $rows, 'unassigned' => $unassigned]]);
}

/**
 * Leads assigned to one dealer (with their tracking status).
 * Includes leads assigned either via the dashboard (dealer_lead_status)
 * or via the CRM contact assignment (contacts.assigned_to). Leads without
 * a tracking row default to non_contacted.
 */
function dealer_leads(int $dealerId, ?string $status = null): void
{
    $sql = "SELECT v.id AS contact_id, v.name, v.phone, v.email, v.business_name, v.created_at,
                   COALESCE(dls.status, 'non_contacted') AS status,
                   COALESCE(dls.response_channel, '') AS response_channel,
                   dls.response_note,
                   dls.contacted_at, dls.responded_at, dls.closed_at, dls.updated_at,
                   v.tags, v.tag_ids
              FROM v_leads v
              LEFT JOIN dealer_lead_status dls
                ON dls.contact_id = v.id AND dls.dealer_id = :dealer
             WHERE v.assigned_to = :dealer2";
    $params = [':dealer' => $dealerId, ':dealer2' => $dealerId];
    if ($status !== null && $status !== '') {
        $sql .= ' AND COALESCE(dls.status, \'non_contacted\') = :status';
        $params[':status'] = $status;
    }
    $sql .= ' ORDER BY COALESCE(dls.updated_at, v.created_at) DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['created_at'] = $row['created_at'] ?? null;
        $row['tags'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
        $row['tag_ids'] = $row['tag_ids'] !== '' ? array_map('to_int', explode(',', $row['tag_ids'])) : [];
    }
    respond(['data' => $rows, 'count' => count($rows)]);
}

/**
 * The signed-in user's OWN leads only:
 *  - Dealer   -> leads assigned to them.
 *  - Follower -> leads assigned to them OR that they follow (never the whole
 *                managing dealer's pipeline).
 * Status tracking rows are read from the user's pipeline owner (the dealer),
 * so a follower sees exactly the status the dealer set on those leads.
 */
function my_dealer_leads(int $staffId, ?string $status = null): void
{
    $row = db()->prepare('SELECT user_type, manager_id FROM staff_users WHERE id = :id');
    $row->execute([':id' => $staffId]);
    $u = $row->fetch();
    if (!$u) fail('Staff user not found', 404);

    if (($u['user_type'] ?? '') === 'Dealer') {
        $trackDealer = $staffId;
        $where = 'v.assigned_to = :me';
        $params = [':me' => $staffId];
    } else {
        $trackDealer = (int)($u['manager_id'] ?? $staffId);
        $where = '(v.assigned_to = :me OR v.id IN (SELECT contact_id FROM contact_followers WHERE staff_id = :me2))';
        $params = [':me' => $staffId, ':me2' => $staffId];
    }
    $params[':track'] = $trackDealer;

    $sql = "SELECT v.id AS contact_id, v.name, v.phone, v.email, v.business_name, v.created_at,
                   COALESCE(dls.status, 'non_contacted') AS status,
                   COALESCE(dls.response_channel, '') AS response_channel,
                   dls.response_note,
                   dls.contacted_at, dls.responded_at, dls.closed_at, dls.updated_at,
                   v.tags, v.tag_ids
              FROM v_leads v
              LEFT JOIN dealer_lead_status dls
                ON dls.contact_id = v.id AND dls.dealer_id = :track
             WHERE " . $where;
    if ($status !== null && $status !== '') {
        $sql .= ' AND COALESCE(dls.status, \'non_contacted\') = :status';
        $params[':status'] = $status;
    }
    $sql .= ' ORDER BY COALESCE(dls.updated_at, v.created_at) DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row2) {
        $row2['created_at'] = $row2['created_at'] ?? null;
        $row2['tags'] = $row2['tags'] !== '' ? explode(',', $row2['tags']) : [];
        $row2['tag_ids'] = $row2['tag_ids'] !== '' ? array_map('to_int', explode(',', $row2['tag_ids'])) : [];
    }
    respond(['data' => $rows, 'count' => count($rows)]);
}

/** Leads that are not yet assigned to any dealer. */
function dealer_unassigned_leads(): void
{
    $stmt = db()->prepare(
        "SELECT v.* FROM v_leads v
          WHERE v.assigned_to IS NULL
            AND NOT EXISTS (SELECT 1 FROM dealer_lead_status d WHERE d.contact_id = v.id)
          ORDER BY v.created_at DESC"
    );
    $stmt->execute();
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['tags'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
        $row['tag_ids'] = $row['tag_ids'] !== '' ? array_map('to_int', explode(',', $row['tag_ids'])) : [];
        $row['custom_fields'] = decode_custom_fields($row['custom_fields'] ?? null);
    }
    respond(['data' => $rows, 'count' => count($rows)]);
}

/**
 * Assign leads to a dealer.
 * Either explicit ids (checkbox selection) OR a date filter:
 *   { "filter": { "type": "days"|"weeks"|"months"|"years", "value": N } }
 *   { "filter": { "type": "range", "from": "YYYY-MM-DD", "to": "YYYY-MM-DD" } }
 *   { "filter": { "type": "all" } }
 */
function assign_leads_to_dealer(array $body): void
{
    $dealerId = to_int((string)($body['dealer_id'] ?? 0));
    if ($dealerId <= 0) fail('dealer_id is required');

    $d = db()->prepare('SELECT id, user_type FROM staff_users WHERE id = :id');
    $d->execute([':id' => $dealerId]);
    $drow = $d->fetch();
    if (!$drow) fail('Dealer not found', 404);
    if (($drow['user_type'] ?? '') !== 'Dealer') fail('Selected user is not a Dealer', 400);

    $pdo = db();
    $contactIds = [];

    if (!empty($body['contact_ids']) && is_array($body['contact_ids'])) {
        $contactIds = array_values(array_filter(
            array_map(fn($c) => to_int((string)$c), $body['contact_ids']),
            fn($c) => $c > 0
        ));
    } elseif (isset($body['filter']) && is_array($body['filter'])) {
        $f = $body['filter'];
        $type = (string)($f['type'] ?? 'all');
        $where = 'is_lead = 1';
        if (in_array($type, ['days', 'weeks', 'months', 'years'], true)) {
            $value = max(1, (int)($f['value'] ?? 1));
            $where .= " AND created_at >= DATE_SUB(NOW(), INTERVAL $value $type)";
        } elseif ($type === 'range') {
            $from = trim((string)($f['from'] ?? ''));
            $to = trim((string)($f['to'] ?? ''));
            if ($from !== '') {
                $where .= ' AND created_at >= :from';
                $fromParam[':from'] = $from;
            }
            if ($to !== '') {
                $where .= ' AND created_at <= :to';
                $toParam[':to'] = $to;
            }
        }
        // Only leads that aren't already assigned to a dealer.
        $sql = "SELECT id FROM v_leads WHERE $where AND v_leads.assigned_to IS NULL
                  AND NOT EXISTS (
                    SELECT 1 FROM dealer_lead_status d WHERE d.contact_id = v_leads.id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(($fromParam ?? []) + ($toParam ?? []));
        $contactIds = array_map(fn($r) => (int)$r['id'], $stmt->fetchAll());
    }

    if (!$contactIds) {
        respond(['data' => ['assigned' => 0], 'message' => 'No leads to assign']);
    }

    $pdo->beginTransaction();
    try {
        $assigned = 0;
        $assignedIds = [];
        $ins = $pdo->prepare('INSERT INTO dealer_lead_status (contact_id, dealer_id) VALUES (:c, :d)');
        $upd = $pdo->prepare('UPDATE contacts SET assigned_to = :d, last_activity_at = NOW() WHERE id = :c');
        foreach ($contactIds as $cid) {
            $exists = $pdo->prepare('SELECT id FROM contacts WHERE id = :id');
            $exists->execute([':id' => $cid]);
            if (!$exists->fetch()) continue;

            $taken = $pdo->prepare('SELECT dealer_id FROM dealer_lead_status WHERE contact_id = :c LIMIT 1');
            $taken->execute([':c' => $cid]);
            $cur = $taken->fetchColumn();
            if ($cur !== false) {
                if ((int)$cur === $dealerId) continue;
                $pdo->prepare('DELETE FROM dealer_lead_status WHERE contact_id = :c')->execute([':c' => $cid]);
            }

            $ins->execute([':c' => $cid, ':d' => $dealerId]);
            $upd->execute([':d' => $dealerId, ':c' => $cid]);
            $assigned++;
            $assignedIds[] = $cid;
        }
        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    // Tell the dealer they got new leads so the bell lights up.
    if ($assigned > 0) {
        $contactName = null;
        if ($assigned === 1 && isset($assignedIds[0])) {
            $nm = $pdo->prepare('SELECT full_name FROM contacts WHERE id = :id');
            $nm->execute([':id' => $assignedIds[0]]);
            $contactName = $nm->fetchColumn() ?: null;
        }
        notify_staff(
            $dealerId,
            $assigned === 1 ? ($assignedIds[0] ?? null) : null,
            'lead_assigned',
            $assigned === 1 ? 'New lead assigned to you' : "$assigned leads assigned to you",
            $assigned === 1
                ? ($contactName ?: 'A lead') . ' has been assigned to you.'
                : "$assigned new lead(s) have been assigned to you. Open your dashboard to start contacting them."
        );
    }

    respond(['data' => ['assigned' => $assigned], 'message' => "$assigned lead(s) assigned"]);
}

/** A dealer updates the tracking status of one of their assigned leads. */
function update_dealer_lead_status(int $contactId, array $body): void
{
    $dealerId = to_int((string)($body['dealer_id'] ?? 0));
    if ($dealerId <= 0) fail('dealer_id is required');

    $allowed = ['non_contacted', 'contacted', 'closed', 'customer', 'rejected'];
    $status = (string)($body['status'] ?? '');
    if (!in_array($status, $allowed, true)) fail('Invalid status');

    $channel = (string)($body['response_channel'] ?? '');
    $note = $body['response_note'] ?? null;
    if ($note !== null && trim((string)$note) === '') $note = null;

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $chk = $pdo->prepare(
            'SELECT c.id FROM contacts c
              WHERE c.id = :c
                AND (c.assigned_to = :d OR EXISTS (
                       SELECT 1 FROM dealer_lead_status dl WHERE dl.contact_id = c.id AND dl.dealer_id = :d2))'
        );
        $chk->execute([':c' => $contactId, ':d' => $dealerId, ':d2' => $dealerId]);
        if (!$chk->fetch()) fail('Lead not assigned to this dealer', 404);

        $ins = $pdo->prepare(
            'INSERT INTO dealer_lead_status (contact_id, dealer_id, status, response_channel, response_note)
             VALUES (:c, :d, :status, :channel, :note)
             ON DUPLICATE KEY UPDATE status = VALUES(status), response_channel = VALUES(response_channel), response_note = VALUES(response_note)'
        );
        $params = [
            ':c' => $contactId,
            ':d' => $dealerId,
            ':status' => $status,
            ':channel' => $channel,
            ':note' => $note,
        ];
        $ins->execute($params);

        $sets = ['status = :status', 'response_channel = :channel', 'response_note = :note'];
        if (in_array($status, ['contacted', 'closed', 'customer', 'rejected'], true)) {
            $sets[] = 'contacted_at = COALESCE(contacted_at, NOW())';
        }
        if (in_array($status, ['closed', 'customer', 'rejected'], true)) {
            $sets[] = 'responded_at = COALESCE(responded_at, NOW())';
        }
        if (in_array($status, ['customer', 'rejected'], true)) {
            $sets[] = 'closed_at = COALESCE(closed_at, NOW())';
        }

        $pdo->prepare(
            'UPDATE dealer_lead_status SET ' . implode(', ', $sets)
            . ' WHERE contact_id = :c AND dealer_id = :d'
        )->execute($params);
        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    // Everyone following this lead (other than the dealer doing the update)
    // gets a heads-up so the team stays in the loop.
    $statusLabels = [
        'non_contacted' => 'Non-Contacted',
        'contacted' => 'Contacted',
        'closed' => 'Closed',
        'customer' => 'Customer',
        'rejected' => 'Rejected',
    ];
    $nm = $pdo->prepare('SELECT full_name FROM contacts WHERE id = :id');
    $nm->execute([':id' => $contactId]);
    $cname = $nm->fetchColumn() ?: 'A lead';
    $dn = $pdo->prepare('SELECT full_name FROM staff_users WHERE id = :id');
    $dn->execute([':id' => $dealerId]);
    $dname = $dn->fetchColumn() ?: 'A team member';
    $actorId = to_int((string)($body['actor_id'] ?? 0));
    if ($actorId > 0 && $actorId !== $dealerId) {
        $an = $pdo->prepare('SELECT full_name FROM staff_users WHERE id = :id');
        $an->execute([':id' => $actorId]);
        $actorName = $an->fetchColumn() ?: $dname;
        $detail = $actorName . ' marked ' . $cname . ' as ' . $label . '.';
    } else {
        $detail = $dname . ' marked ' . $cname . ' as ' . $label . '.';
    }

    // Everyone following this lead (other than the dealer doing the update)
    // gets a heads-up so the team stays in the loop.
    $followers = $pdo->prepare('SELECT staff_id FROM contact_followers WHERE contact_id = :c AND staff_id <> :d');
    $followers->execute([':c' => $contactId, ':d' => $dealerId]);
    foreach ($followers->fetchAll() as $f) {
        notify_staff((int)$f['staff_id'], $contactId, 'lead_assigned', 'Lead status updated', $detail);
    }

    // Admins are told too so they see pipeline movement without checking manually.
    $admins = $pdo->query("SELECT id FROM staff_users WHERE user_type = 'Admin'")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($admins as $aid) {
        notify_staff((int)$aid, $contactId, 'lead_assigned', 'Lead status updated', $detail);
    }

    respond(['message' => 'Lead status updated']);
}

/** Move many leads into a bucket at once (checkbox selection). */
function bulk_update_dealer_lead_status(array $body): void
{
    $dealerId = to_int((string)($body['dealer_id'] ?? 0));
    if ($dealerId <= 0) fail('dealer_id is required');

    $allowed = ['non_contacted', 'contacted', 'closed', 'customer', 'rejected'];
    $status = (string)($body['status'] ?? '');
    if (!in_array($status, $allowed, true)) fail('Invalid status');

    $channel = (string)($body['response_channel'] ?? '');
    $note = $body['response_note'] ?? null;
    if ($note !== null && trim((string)$note) === '') $note = null;

    $ids = $body['contact_ids'] ?? null;
    if (!is_array($ids) || !$ids) fail('contact_ids are required');

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $updated = 0;
        $ins = $pdo->prepare(
            'INSERT INTO dealer_lead_status (contact_id, dealer_id, status, response_channel, response_note)
             VALUES (:c, :d, :status, :channel, :note)
             ON DUPLICATE KEY UPDATE status = VALUES(status), response_channel = VALUES(response_channel), response_note = VALUES(response_note)'
        );
        $upd = $pdo->prepare(
            'UPDATE dealer_lead_status SET status = :status, response_channel = :channel, response_note = :note,
                    contacted_at = CASE WHEN :contacted THEN COALESCE(contacted_at, NOW()) ELSE contacted_at END,
                    responded_at = CASE WHEN :responded THEN COALESCE(responded_at, NOW()) ELSE responded_at END,
                    closed_at = CASE WHEN :closed THEN COALESCE(closed_at, NOW()) ELSE closed_at END
             WHERE contact_id = :c AND dealer_id = :d'
        );
        foreach ($ids as $raw) {
            $cid = to_int((string)$raw);
            if ($cid <= 0) continue;
            $chk = $pdo->prepare(
                'SELECT c.id FROM contacts c
                  WHERE c.id = :c
                    AND (c.assigned_to = :d OR EXISTS (
                           SELECT 1 FROM dealer_lead_status dl WHERE dl.contact_id = c.id AND dl.dealer_id = :d2))'
            );
            $chk->execute([':c' => $cid, ':d' => $dealerId, ':d2' => $dealerId]);
            if (!$chk->fetch()) continue;

            $ins->execute([
                ':c' => $cid,
                ':d' => $dealerId,
                ':status' => $status,
                ':channel' => $channel,
                ':note' => $note,
            ]);
            $upd->execute([
                ':status' => $status,
                ':channel' => $channel,
                ':note' => $note,
                ':contacted' => in_array($status, ['contacted', 'closed', 'customer', 'rejected'], true) ? 1 : 0,
                ':responded' => in_array($status, ['closed', 'customer', 'rejected'], true) ? 1 : 0,
                ':closed' => in_array($status, ['customer', 'rejected'], true) ? 1 : 0,
                ':c' => $cid,
                ':d' => $dealerId,
            ]);
            $updated++;
        }
        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        fail('Database error: ' . $e->getMessage(), 500);
    }

    respond(['data' => ['updated' => $updated], 'message' => "$updated lead(s) moved to $status"]);
}

/* ------------------- SMART LISTS (server-side, multi-user) ------------------- */

/**
 * Resolve the current acting user id. Endpoints accept an explicit
 * "user_id" (the logged-in staff member) since the CRM has no session.
 */
function smart_list_user(array $filters, array $body = []): int
{
    $id = to_int((string)($body['user_id'] ?? ($filters['user_id'] ?? 0)));
    if ($id <= 0) fail('user_id is required');
    return $id;
}

/** Build the array representation of a smart list row + its shares. */
function smart_list_payload(array $row): array
{
    $shares = db()->prepare(
        'SELECT user_id FROM smart_list_shares WHERE smart_list_id = :id ORDER BY user_id'
    );
    $shares->execute([':id' => $row['id']]);
    $shareIds = array_map(fn($s) => (int)$s['user_id'], $shares->fetchAll());

    return [
        'id' => (int)$row['id'],
        'name' => $row['name'],
        'filters' => decode_json_field($row['filters'] ?? null),
        'sort_by' => $row['sort_by'] ?? '',
        'fields' => decode_json_field($row['fields'] ?? null),
        'members' => decode_json_field($row['members'] ?? null),
        'dealer_id' => $row['dealer_id'] !== null ? (int)$row['dealer_id'] : null,
        'dealer_name' => $row['dealer_name'] ?? null,
        'shared_all' => (int)($row['shared_all'] ?? 0) === 1,
        'shared_user_ids' => $shareIds,
        'created_by' => (int)$row['created_by'],
        'created_by_name' => $row['created_by_name'] ?? '',
        'created_at' => $row['created_at'] ?? null,
        'updated_at' => $row['updated_at'] ?? null,
    ];
}

/** Visibility: a list is visible when owned, shared explicitly, or shared with everyone. */
function smart_lists_visible(int $userId): PDOStatement
{
    return db()->prepare(
        'SELECT sl.*, s.full_name AS created_by_name, d.full_name AS dealer_name
           FROM smart_lists sl
           LEFT JOIN staff_users s ON s.id = sl.created_by
           LEFT JOIN staff_users d ON d.id = sl.dealer_id
          WHERE sl.created_by = :me
             OR sl.shared_all = 1
             OR sl.id IN (SELECT smart_list_id FROM smart_list_shares WHERE user_id = :me2)
          ORDER BY sl.created_at DESC, sl.id DESC'
    );
}

/** GET /smart-lists?user_id=N -> every list visible to the user. */
function list_smart_lists(array $filters): void
{
    $userId = smart_list_user($filters);
    $stmt = smart_lists_visible($userId);
    $stmt->execute([':me' => $userId, ':me2' => $userId]);
    $rows = $stmt->fetchAll();

    $rows = filter_smart_lists_for_staff($rows, $userId);

    respond(['data' => array_map('smart_list_payload', $rows), 'count' => count($rows)]);
}

/** Contact ids a staff user owns (assigned) or follows. */
function staff_accessible_contact_ids(int $userId): array
{
    $stmt = db()->prepare(
        'SELECT id FROM contacts
          WHERE assigned_to = :me
             OR id IN (SELECT contact_id FROM contact_followers WHERE staff_id = :me2)'
    );
    $stmt->execute([':me' => $userId, ':me2' => $userId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Dealers and followers start with a clean slate: until leads are assigned to
 * them they see no smart lists at all. Afterwards a shared list appears only
 * when it is assigned to them (dealer_id), shared explicitly with them, or
 * contains at least one of their own contacts. Admins are unaffected.
 */
function filter_smart_lists_for_staff(array $rows, int $userId): array
{
    if (!$rows) return $rows;
    $u = db()->prepare('SELECT user_type FROM staff_users WHERE id = :id');
    $u->execute([':id' => $userId]);
    $type = (string)($u->fetchColumn() ?: '');
    if ($type === '' || $type === 'Admin') return $rows;

    $mineSet = array_fill_keys(staff_accessible_contact_ids($userId), true);
    $shared = db()->prepare('SELECT smart_list_id FROM smart_list_shares WHERE user_id = :u');
    $shared->execute([':u' => $userId]);
    $sharedSet = array_fill_keys(array_map('intval', $shared->fetchAll(PDO::FETCH_COLUMN)), true);

    $out = [];
    foreach ($rows as $row) {
        if ((int)$row['created_by'] === $userId
            || (int)($row['dealer_id'] ?? 0) === $userId
            || isset($sharedSet[(int)$row['id']])) {
            $out[] = $row;
            continue;
        }
        foreach (decode_json_field($row['members'] ?? null) as $m) {
            if (is_numeric($m) && isset($mineSet[(int)$m])) {
                $out[] = $row;
                break;
            }
        }
    }
    return $out;
}

/** Validate and normalize the JSON-column inputs of a smart list. */
function smart_list_input(array $body): array
{
    $name = trim((string)($body['name'] ?? ''));
    if ($name === '') fail('name is required');

    $asIntArray = function ($value): array {
        if (!is_array($value)) return [];
        return array_values(array_unique(array_filter(
            array_map(fn($v) => to_int((string)$v), $value),
            fn($v) => $v > 0
        )));
    };
    $asStrArray = function ($value): array {
        if (!is_array($value)) return [];
        return array_values(array_filter(array_map(fn($v) => trim((string)$v), $value), fn($v) => $v !== ''));
    };

    $dealerId = $body['dealer_id'] ?? null;

    return [
        'name' => $name,
        'filters' => encode_json_field($asStrArray($body['filters'] ?? null)),
        'sort_by' => (($body['sort_by'] ?? '') !== '') ? trim((string)$body['sort_by']) : null,
        'fields' => encode_json_field($asStrArray($body['fields'] ?? null)),
        'members' => encode_json_field($asIntArray($body['members'] ?? null)),
        'dealer_id' => ($dealerId === null || $dealerId === '' || (int)$dealerId <= 0) ? null : (int)$dealerId,
        'shared_all' => !empty($body['shared_all']) ? 1 : 0,
        'share_ids' => $asIntArray($body['shared_user_ids'] ?? null),
    ];
}

/** Replace the share rows for a smart list (owner always keeps access). */
function smart_list_set_shares(int $listId, array $shareIds, int $ownerId): void
{
    $pdo = db();
    $pdo->prepare('DELETE FROM smart_list_shares WHERE smart_list_id = :id')->execute([':id' => $listId]);
    $ins = $pdo->prepare('INSERT INTO smart_list_shares (smart_list_id, user_id) VALUES (:l, :u)');
    foreach ($shareIds as $uid) {
        if ((int)$uid === $ownerId) continue;
        $ins->execute([':l' => $listId, ':u' => (int)$uid]);
    }
}

/** Fetch a smart list row with creator/dealer names. */
function smart_list_fetch(int $id): array
{
    $row = db()->prepare(
        'SELECT sl.*, s.full_name AS created_by_name, d.full_name AS dealer_name
           FROM smart_lists sl
           LEFT JOIN staff_users s ON s.id = sl.created_by
           LEFT JOIN staff_users d ON d.id = sl.dealer_id
          WHERE sl.id = :id'
    );
    $row->execute([':id' => $id]);
    return $row->fetch() ?: [];
}

/** POST /smart-lists  { user_id, name, filters?, sort_by?, fields?, members?, dealer_id?, shared_all?, shared_user_ids? } */
function create_smart_list(array $body): void
{
    $userId = smart_list_user([], $body);
    $input = smart_list_input($body);
    $pdo = db();

    $dup = $pdo->prepare('SELECT id FROM smart_lists WHERE created_by = :me AND name = :name');
    $dup->execute([':me' => $userId, ':name' => $input['name']]);
    if ($dup->fetch()) fail('A smart list with this name already exists');

    $stmt = $pdo->prepare(
        'INSERT INTO smart_lists (name, filters, sort_by, fields, members, dealer_id, shared_all, created_by)
         VALUES (:name, :filters, :sort_by, :fields, :members, :dealer_id, :shared_all, :created_by)'
    );
    $stmt->execute([
        ':name' => $input['name'],
        ':filters' => $input['filters'],
        ':sort_by' => $input['sort_by'],
        ':fields' => $input['fields'],
        ':members' => $input['members'],
        ':dealer_id' => $input['dealer_id'],
        ':shared_all' => $input['shared_all'],
        ':created_by' => $userId,
    ]);
    $id = (int)$pdo->lastInsertId();
    smart_list_set_shares($id, $input['share_ids'], $userId);

    respond(['data' => smart_list_payload(smart_list_fetch($id)), 'message' => 'Smart list created'], 201);
}

/** PUT /smart-lists/{id}  { user_id, name, ... } -> only the owner may edit. */
function update_smart_list(int $id, array $body): void
{
    $userId = smart_list_user([], $body);
    $input = smart_list_input($body);
    $pdo = db();

    $existing = $pdo->prepare('SELECT id, created_by FROM smart_lists WHERE id = :id');
    $existing->execute([':id' => $id]);
    $row = $existing->fetch();
    if (!$row) fail('Smart list not found', 404);
    if ((int)$row['created_by'] !== $userId) fail('Only the owner can edit this smart list', 403);

    $dup = $pdo->prepare('SELECT id FROM smart_lists WHERE created_by = :me AND name = :name AND id <> :id');
    $dup->execute([':me' => $userId, ':name' => $input['name'], ':id' => $id]);
    if ($dup->fetch()) fail('A smart list with this name already exists');

    $pdo->prepare(
        'UPDATE smart_lists
            SET name = :name, filters = :filters, sort_by = :sort_by, fields = :fields,
                members = :members, dealer_id = :dealer_id, shared_all = :shared_all
          WHERE id = :id'
    )->execute([
        ':name' => $input['name'],
        ':filters' => $input['filters'],
        ':sort_by' => $input['sort_by'],
        ':fields' => $input['fields'],
        ':members' => $input['members'],
        ':dealer_id' => $input['dealer_id'],
        ':shared_all' => $input['shared_all'],
        ':id' => $id,
    ]);
    smart_list_set_shares($id, $input['share_ids'], $userId);

    respond(['data' => smart_list_payload(smart_list_fetch($id)), 'message' => 'Smart list updated']);
}

/** DELETE /smart-lists/{id}?user_id=N -> only the owner may delete. */
function delete_smart_list(int $id, array $filters): void
{
    $userId = smart_list_user($filters);
    $pdo = db();

    $existing = $pdo->prepare('SELECT id, created_by FROM smart_lists WHERE id = :id');
    $existing->execute([':id' => $id]);
    $row = $existing->fetch();
    if (!$row) fail('Smart list not found', 404);
    if ((int)$row['created_by'] !== $userId) fail('Only the owner can delete this smart list', 403);

    $pdo->prepare('DELETE FROM smart_lists WHERE id = :id')->execute([':id' => $id]);
    respond(['message' => 'Smart list deleted']);
}

/** POST /smart-lists/{id}/duplicate  { user_id } -> a copy owned by the caller. */
function duplicate_smart_list(int $id, array $body): void
{
    $userId = smart_list_user([], $body);
    $pdo = db();

    $src = $pdo->prepare('SELECT * FROM smart_lists WHERE id = :id');
    $src->execute([':id' => $id]);
    $row = $src->fetch();
    if (!$row) fail('Smart list not found', 404);

    $name = $row['name'] . ' (copy)';
    $dup = $pdo->prepare('SELECT id FROM smart_lists WHERE created_by = :me AND name = :name');
    $dup->execute([':me' => $userId, ':name' => $name]);
    if ($dup->fetch()) fail('A smart list named "' . $name . '" already exists');

    $pdo->prepare(
        'INSERT INTO smart_lists (name, filters, sort_by, fields, members, dealer_id, shared_all, created_by)
         VALUES (:name, :filters, :sort_by, :fields, :members, :dealer_id, 0, :created_by)'
    )->execute([
        ':name' => $name,
        ':filters' => $row['filters'],
        ':sort_by' => $row['sort_by'],
        ':fields' => $row['fields'],
        ':members' => $row['members'],
        ':dealer_id' => $row['dealer_id'],
        ':created_by' => $userId,
    ]);
    $newId = (int)$pdo->lastInsertId();

    respond(['data' => smart_list_payload(smart_list_fetch($newId)), 'message' => 'Smart list duplicated']);
}

/* ----------------------- FORM IMAGES (short form links) ----------------------- */

/** Ensure the form_images table exists (created lazily so no manual SQL is needed). */
function ensure_form_images_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS form_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            data MEDIUMTEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

/** POST /form-images { image: "<base64 data URI>" } -> store, return { id }. */
function store_form_image(array $body): void
{
    $image = $body['image'] ?? '';
    if (!is_string($image) || $image === '' || !preg_match('~^data:image/[a-zA-Z0-9.+-]+;base64,~', $image)) {
        fail('Valid base64 image data URI required');
    }
    if (strlen($image) > 12 * 1024 * 1024) {
        fail('Image too large (max 12 MB)');
    }
    ensure_form_images_table();
    $stmt = db()->prepare('INSERT INTO form_images (data) VALUES (:data)');
    $stmt->execute([':data' => $image]);
    respond(['data' => ['id' => (int)db()->lastInsertId()]]);
}

/** GET /form-images/{id} -> raw image bytes with the right content type. */
function get_form_image(int $id): void
{
    ensure_form_images_table();
    $stmt = db()->prepare('SELECT data FROM form_images WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) {
        http_response_code(404);
        exit;
    }
    if (!preg_match('~^data:image/([a-zA-Z0-9.+-]+);base64,(.+)$~s', $row['data'], $m)) {
        http_response_code(404);
        exit;
    }
    $ext = strtolower($m[1]);
    $mime = $ext === 'jpeg' ? 'image/jpeg' : 'image/' . $ext;
    $bytes = base64_decode($m[2], true);
    if ($bytes === false) {
        http_response_code(404);
        exit;
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    header('Cache-Control: public, max-age=31536000, immutable');
    echo $bytes;
    exit;
}

/* ----------------------- FORM BUILDER (persisted) ----------------------- */

/** Create the forms table on first use so no manual SQL step is required. */
function ensure_forms_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS forms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(191) NOT NULL,
            updated_by VARCHAR(191) DEFAULT "",
            elements MEDIUMTEXT NULL,
            header MEDIUMTEXT NULL,
            cols TINYINT NOT NULL DEFAULT 1,
            campaign_id INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

/** Decode JSON columns of a form row for the API response. */
function form_payload(array $row): array
{
    $row['elements'] = decode_json_field($row['elements'] ?? null);
    $row['header'] = decode_json_field($row['header'] ?? null);
    $row['cols'] = (int)$row['cols'] === 2 ? 2 : 1;
    return $row;
}

/** GET /forms -> every saved builder form. */
function list_forms(): void
{
    ensure_forms_table();
    $rows = db()->query('SELECT * FROM forms ORDER BY updated_at DESC, id DESC')->fetchAll();
    $rows = array_map('form_payload', $rows);
    respond(['data' => $rows, 'count' => count($rows)]);
}

/**
 * GET /forms/{id} -> one saved form. Public on purpose: short share links
 * (#/f/{id}) must render for visitors who are not signed in.
 */
function get_form(int $id): void
{
    ensure_forms_table();
    $stmt = db()->prepare('SELECT * FROM forms WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) fail('Form not found', 404);
    respond(['data' => form_payload($row)]);
}

/** POST /forms { name, updated_by?, elements?, header?, cols?, campaign_id? } */
function create_form(array $body): void
{
    ensure_forms_table();
    $name = normalize_optional($body['name'] ?? null);
    if ($name === null || $name === '') fail('Form name is required');

    $stmt = db()->prepare(
        'INSERT INTO forms (name, updated_by, elements, header, cols, campaign_id)
         VALUES (:name, :updated_by, :elements, :header, :cols, :campaign_id)'
    );
    $stmt->execute([
        ':name' => $name,
        ':updated_by' => normalize_optional($body['updated_by'] ?? null) ?? '',
        ':elements' => encode_json_field($body['elements'] ?? null),
        ':header' => encode_json_field($body['header'] ?? null),
        ':cols' => ((int)($body['cols'] ?? 1)) === 2 ? 2 : 1,
        ':campaign_id' => isset($body['campaign_id']) && (int)$body['campaign_id'] > 0 ? (int)$body['campaign_id'] : null,
    ]);
    $id = (int)db()->lastInsertId();
    $stmt = db()->prepare('SELECT * FROM forms WHERE id = :id');
    $stmt->execute([':id' => $id]);
    respond(['data' => form_payload($stmt->fetch() ?: ['id' => $id]), 'message' => 'Form saved'], 201);
}

/** PUT /forms/{id} — full update of the builder form. */
function update_form(int $id, array $body): void
{
    ensure_forms_table();
    $stmt = db()->prepare('SELECT id FROM forms WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->fetchColumn() === false) fail('Form not found', 404);

    $sets = [];
    $params = [':id' => $id];
    if (array_key_exists('name', $body)) {
        $name = normalize_optional($body['name']);
        if ($name === null || $name === '') fail('Form name is required');
        $sets[] = 'name = :name';
        $params[':name'] = $name;
    }
    if (array_key_exists('updated_by', $body)) {
        $sets[] = 'updated_by = :updated_by';
        $params[':updated_by'] = normalize_optional($body['updated_by']) ?? '';
    }
    if (array_key_exists('elements', $body)) {
        $sets[] = 'elements = :elements';
        $params[':elements'] = encode_json_field($body['elements']);
    }
    if (array_key_exists('header', $body)) {
        $sets[] = 'header = :header';
        $params[':header'] = encode_json_field($body['header']);
    }
    if (array_key_exists('cols', $body)) {
        $sets[] = 'cols = :cols';
        $params[':cols'] = ((int)$body['cols']) === 2 ? 2 : 1;
    }
    if (array_key_exists('campaign_id', $body)) {
        $sets[] = 'campaign_id = :campaign_id';
        $params[':campaign_id'] = $body['campaign_id'] !== null && (int)$body['campaign_id'] > 0 ? (int)$body['campaign_id'] : null;
    }
    if (!$sets) fail('No fields to update');

    db()->prepare('UPDATE forms SET ' . implode(', ', $sets) . ' WHERE id = :id')->execute($params);
    $stmt = db()->prepare('SELECT * FROM forms WHERE id = :id');
    $stmt->execute([':id' => $id]);
    respond(['data' => form_payload($stmt->fetch() ?: []), 'message' => 'Form updated']);
}

/** DELETE /forms/{id} */
function delete_form(int $id): void
{
    ensure_forms_table();
    $stmt = db()->prepare('DELETE FROM forms WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Form not found', 404);
    respond(['message' => 'Form deleted']);
}

/* ----------------------- SALES TAX INVOICES ----------------------- */

/** Create the invoices table on first use so no manual SQL step is required. */
function ensure_invoices_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS invoices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            invoice_no VARCHAR(191) NOT NULL,
            dated VARCHAR(20) DEFAULT "",
            strn VARCHAR(64) DEFAULT "",
            address VARCHAR(255) DEFAULT "",
            customer_name VARCHAR(255) DEFAULT "",
            qty INT NOT NULL DEFAULT 1,
            motorcycle VARCHAR(255) DEFAULT "",
            model_year VARCHAR(20) DEFAULT "",
            colour VARCHAR(100) DEFAULT "",
            engine_no VARCHAR(100) DEFAULT "",
            chassis_no VARCHAR(100) DEFAULT "",
            value_excl DECIMAL(12,2) NOT NULL DEFAULT 0,
            tax_rate DECIMAL(6,2) NOT NULL DEFAULT 18,
            tax_payable DECIMAL(12,2) NOT NULL DEFAULT 0,
            value_incl DECIMAL(12,2) NOT NULL DEFAULT 0,
            created_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_invoices_invoice_no (invoice_no),
            INDEX idx_invoices_created_by (created_by)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );

    // Lazy migration for installs created before the editable seller address.
    $col = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'invoices'
            AND COLUMN_NAME  = 'address'"
    );
    $col->execute();
    if ((int)$col->fetchColumn() === 0) {
        db()->exec('ALTER TABLE invoices ADD COLUMN address VARCHAR(255) DEFAULT "" AFTER strn');
    }
}

/** Cast an invoice row's numeric columns for the API response. */
function invoice_payload(array $row): array
{
    foreach (['id', 'qty'] as $k) {
        $row[$k] = (int)$row[$k];
    }
    foreach (['value_excl', 'tax_rate', 'tax_payable', 'value_incl'] as $k) {
        $row[$k] = (float)$row[$k];
    }
    $row['created_by'] = isset($row['created_by']) && $row['created_by'] !== null ? (int)$row['created_by'] : null;
    return $row;
}

/**
 * GET /invoices[?search=&created_by=]
 * Newest first; optional search across number/customer/bike/engine/chassis.
 * created_by scopes a non-admin user to their own invoices.
 */
function list_invoices(array $filters): void
{
    ensure_invoices_table();
    $where = [];
    $params = [];

    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $cols = ['invoice_no', 'customer_name', 'motorcycle', 'engine_no', 'chassis_no'];
        $pats = [];
        foreach ($cols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $where[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['created_by'])) {
        $params[':created_by'] = to_int((string)$filters['created_by']);
        $where[] = 'created_by = :created_by';
    }

    $sql = 'SELECT * FROM invoices';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    respond(['data' => array_map('invoice_payload', $rows), 'count' => count($rows)]);
}

/**
 * GET /invoices/next-number
 * Suggests the next sequential invoice number from the highest numeric
 * invoice_no already saved ("084" -> "085", keeping the digit width).
 */
function next_invoice_number(): void
{
    ensure_invoices_table();
    $rows = db()->query('SELECT invoice_no FROM invoices')->fetchAll(PDO::FETCH_COLUMN);
    $max = 0;
    $width = 3;
    foreach ($rows as $no) {
        $digits = preg_replace('/\D+/', '', (string)$no);
        if ($digits !== '' && (int)$digits >= $max) {
            $max = (int)$digits;
            $width = max($width, strlen(ltrim($digits, '0')) ?: 1);
        }
    }
    respond(['data' => ['invoice_no' => str_pad((string)($max + 1), $width, '0', STR_PAD_LEFT)]]);
}

/** Shared insert/update column list for an invoice request body. */
function invoice_columns(array $body): array
{
    $qty = max(1, to_int((string)($body['qty'] ?? 1)));
    $num = static function ($v): float {
        $cleaned = preg_replace('/[^0-9.\-]/', '', (string)($v ?? 0));
        return (float)($cleaned === '' ? 0 : $cleaned);
    };

    return [
        'invoice_no' => trim((string)($body['invoice_no'] ?? '')),
        'dated' => normalize_optional($body['dated'] ?? null) ?? '',
        'strn' => normalize_optional($body['strn'] ?? null) ?? '',
        'address' => normalize_optional($body['address'] ?? null) ?? '',
        'customer_name' => normalize_optional($body['customer_name'] ?? null) ?? '',
        'qty' => $qty,
        'motorcycle' => normalize_optional($body['motorcycle'] ?? null) ?? '',
        'model_year' => normalize_optional($body['model_year'] ?? null) ?? '',
        'colour' => normalize_optional($body['colour'] ?? null) ?? '',
        'engine_no' => normalize_optional($body['engine_no'] ?? null) ?? '',
        'chassis_no' => normalize_optional($body['chassis_no'] ?? null) ?? '',
        'value_excl' => $num($body['value_excl'] ?? 0),
        'tax_rate' => $num($body['tax_rate'] ?? 0),
        'tax_payable' => $num($body['tax_payable'] ?? 0),
        'value_incl' => $num($body['value_incl'] ?? 0),
    ];
}

/** POST /invoices — save a new sales tax invoice. */
function create_invoice(array $body): void
{
    ensure_invoices_table();
    $c = invoice_columns($body);
    if ($c['invoice_no'] === '') fail('Invoice number is required');

    // Never allow two invoices with the same visible number.
    $dup = db()->prepare('SELECT id FROM invoices WHERE invoice_no = :no');
    $dup->execute([':no' => $c['invoice_no']]);
    if ($dup->fetchColumn() !== false) {
        fail('An invoice with number "' . $c['invoice_no'] . '" already exists', 409);
    }

    $createdBy = isset($body['created_by']) && (int)$body['created_by'] > 0 ? (int)$body['created_by'] : null;

    $stmt = db()->prepare(
        'INSERT INTO invoices (invoice_no, dated, strn, address, customer_name, qty, motorcycle, model_year,
                               colour, engine_no, chassis_no, value_excl, tax_rate, tax_payable,
                               value_incl, created_by)
         VALUES (:no, :dated, :strn, :address, :cust, :qty, :moto, :year, :colour, :engine, :chassis,
                 :vexcl, :rate, :tpay, :vincl, :created_by)'
    );
    $stmt->execute([
        ':no' => $c['invoice_no'],
        ':dated' => $c['dated'],
        ':strn' => $c['strn'],
        ':address' => $c['address'],
        ':cust' => $c['customer_name'],
        ':qty' => $c['qty'],
        ':moto' => $c['motorcycle'],
        ':year' => $c['model_year'],
        ':colour' => $c['colour'],
        ':engine' => $c['engine_no'],
        ':chassis' => $c['chassis_no'],
        ':vexcl' => $c['value_excl'],
        ':rate' => $c['tax_rate'],
        ':tpay' => $c['tax_payable'],
        ':vincl' => $c['value_incl'],
        ':created_by' => $createdBy,
    ]);
    $id = (int)db()->lastInsertId();

    $get = db()->prepare('SELECT * FROM invoices WHERE id = :id');
    $get->execute([':id' => $id]);
    respond(['data' => invoice_payload($get->fetch() ?: ['id' => $id]), 'message' => 'Invoice saved'], 201);
}

/** PUT /invoices/{id} — update an existing sales tax invoice. */
function update_invoice(int $id, array $body): void
{
    ensure_invoices_table();
    $existing = db()->prepare('SELECT id FROM invoices WHERE id = :id');
    $existing->execute([':id' => $id]);
    if ($existing->fetchColumn() === false) fail('Invoice not found', 404);

    $c = invoice_columns($body);
    if ($c['invoice_no'] === '') fail('Invoice number is required');

    // The duplicate check must ignore the invoice being edited itself.
    $dup = db()->prepare('SELECT id FROM invoices WHERE invoice_no = :no AND id <> :id');
    $dup->execute([':no' => $c['invoice_no'], ':id' => $id]);
    if ($dup->fetchColumn() !== false) {
        fail('An invoice with number "' . $c['invoice_no'] . '" already exists', 409);
    }

    db()->prepare(
        'UPDATE invoices SET invoice_no = :no, dated = :dated, strn = :strn, address = :address,
                customer_name = :cust, qty = :qty, motorcycle = :moto, model_year = :year, colour = :colour,
                engine_no = :engine, chassis_no = :chassis, value_excl = :vexcl, tax_rate = :rate,
                tax_payable = :tpay, value_incl = :vincl
          WHERE id = :id'
    )->execute([
        ':no' => $c['invoice_no'],
        ':dated' => $c['dated'],
        ':strn' => $c['strn'],
        ':address' => $c['address'],
        ':cust' => $c['customer_name'],
        ':qty' => $c['qty'],
        ':moto' => $c['motorcycle'],
        ':year' => $c['model_year'],
        ':colour' => $c['colour'],
        ':engine' => $c['engine_no'],
        ':chassis' => $c['chassis_no'],
        ':vexcl' => $c['value_excl'],
        ':rate' => $c['tax_rate'],
        ':tpay' => $c['tax_payable'],
        ':vincl' => $c['value_incl'],
        ':id' => $id,
    ]);

    $get = db()->prepare('SELECT * FROM invoices WHERE id = :id');
    $get->execute([':id' => $id]);
    respond(['data' => invoice_payload($get->fetch() ?: []), 'message' => 'Invoice updated']);
}

/** DELETE /invoices/{id} */
function delete_invoice(int $id): void
{
    ensure_invoices_table();
    $stmt = db()->prepare('DELETE FROM invoices WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Invoice not found', 404);
    respond(['message' => 'Invoice deleted']);
}

/* ----------------------- RECEIPT VOUCHERS ----------------------- */

/** Create the receipts table on first use so no manual SQL step is required. */
function ensure_receipts_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS receipts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            receipt_no VARCHAR(64) NOT NULL,
            reg_no VARCHAR(128) DEFAULT "",
            dated VARCHAR(20) DEFAULT "",
            received_from VARCHAR(255) DEFAULT "",
            amount DECIMAL(14,2) NOT NULL DEFAULT 0,
            amount_words VARCHAR(255) DEFAULT "",
            payment_type VARCHAR(64) DEFAULT "",
            payment_via VARCHAR(64) DEFAULT "",
            previous_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
            current_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
            file_details VARCHAR(255) DEFAULT "",
            created_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_receipts_no (receipt_no),
            INDEX idx_receipts_reg (reg_no),
            INDEX idx_receipts_created_by (created_by)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

/** Cast a receipt row's numeric columns for the API response. */
function receipt_payload(array $row): array
{
    foreach (['amount', 'previous_balance', 'current_balance'] as $k) {
        $row[$k] = isset($row[$k]) ? (float)$row[$k] : 0.0;
    }
    $row['created_by'] = isset($row['created_by']) && $row['created_by'] !== null ? (int)$row['created_by'] : null;
    return $row;
}

/**
 * GET /receipts[?search=&created_by=]
 * Newest first; optional search across number/customer/reg/type.
 */
function list_receipts(array $filters): void
{
    ensure_receipts_table();
    $where = [];
    $params = [];

    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $cols = ['receipt_no', 'reg_no', 'received_from', 'payment_type', 'payment_via'];
        $pats = [];
        foreach ($cols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $where[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['created_by'])) {
        $params[':created_by'] = to_int((string)$filters['created_by']);
        $where[] = 'created_by = :created_by';
    }

    $sql = 'SELECT * FROM receipts';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    respond(['data' => array_map('receipt_payload', $rows), 'count' => count($rows)]);
}

/**
 * GET /receipts/next-number
 * Suggests the next sequential receipt number ("RDC-01462" -> "RDC-01463").
 */
function next_receipt_number(): void
{
    ensure_receipts_table();
    $rows = db()->query('SELECT receipt_no FROM receipts')->fetchAll(PDO::FETCH_COLUMN);
    $max = 0;
    foreach ($rows as $no) {
        $digits = preg_replace('/\D+/', '', (string)$no);
        if ($digits !== '' && (int)$digits > $max) {
            $max = (int)$digits;
        }
    }
    respond(['data' => ['receipt_no' => 'RDC-' . str_pad((string)($max + 1), 5, '0', STR_PAD_LEFT)]]);
}

/** Shared insert/update column list for a receipt request body. */
function receipt_columns(array $body): array
{
    $num = static function ($v): float {
        $cleaned = preg_replace('/[^0-9.\-]/', '', (string)($v ?? 0));
        return (float)($cleaned === '' ? 0 : $cleaned);
    };

    return [
        'receipt_no' => trim((string)($body['receipt_no'] ?? '')),
        'reg_no' => normalize_optional($body['reg_no'] ?? null) ?? '',
        'dated' => normalize_optional($body['dated'] ?? null) ?? '',
        'received_from' => normalize_optional($body['received_from'] ?? null) ?? '',
        'amount' => $num($body['amount'] ?? 0),
        'amount_words' => normalize_optional($body['amount_words'] ?? null) ?? '',
        'payment_type' => normalize_optional($body['payment_type'] ?? null) ?? '',
        'payment_via' => normalize_optional($body['payment_via'] ?? null) ?? '',
        'previous_balance' => $num($body['previous_balance'] ?? 0),
        'current_balance' => $num($body['current_balance'] ?? 0),
        'file_details' => normalize_optional($body['file_details'] ?? null) ?? '',
    ];
}

/** Recompute every account statement's paid amounts from its receipts. */
function sync_all_account_statements(): void
{
    if (!table_exists('account_statements')) return;
    $ids = db()->query('SELECT id FROM account_statements')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $sid) {
        sync_statement_from_receipts((int)$sid);
    }
}

/**
 * Ensure an account statement exists for a receipt's member, creating one
 * automatically when the member comes from a Receipt Voucher for the first
 * time. Returns the statement id (0 when there is no member to attach to).
 */
function ensure_statement_for_receipt(array $c, ?int $createdBy, int $receiptId = 0): int
{
    ensure_account_statements_table();
    $member = trim((string)($c['received_from'] ?? ''));
    $reg = trim((string)($c['reg_no'] ?? ''));
    if ($member === '' && $reg === '') return 0;

    // Try to match an existing statement by registration no / file no / name.
    $sid = 0;
    if ($reg !== '') {
        $q = db()->prepare(
            'SELECT id FROM account_statements
              WHERE registration_no = :a1 OR file_no = :a1
                 OR registration_no LIKE :b1 OR file_no LIKE :b1
              ORDER BY id DESC LIMIT 1'
        );
        $q->execute([':a1' => $reg, ':b1' => '%' . $reg . '%']);
        $sid = (int)$q->fetchColumn();
    }
    if ($sid === 0 && $member !== '') {
        $q = db()->prepare(
            'SELECT id FROM account_statements WHERE LOWER(member_name) = LOWER(:m)
              ORDER BY id DESC LIMIT 1'
        );
        $q->execute([':m' => $member]);
        $sid = (int)$q->fetchColumn();
    }

    $createdNew = $sid === 0;

    if ($createdNew) {
        // No statement yet — create one from the receipt voucher's member.
        $fileNo = $reg !== ''
            ? $reg
            : (preg_match('/File\s*#?\s*([0-9]+)/i', (string)($c['file_details'] ?? ''), $m) ? $m[1] : '');
        db()->prepare(
            'INSERT INTO account_statements (registration_no, member_name, file_no, file_status, created_by)
             VALUES (:reg, :member, :file_no, "Active", :cb)'
        )->execute([
            ':reg' => $reg,
            ':member' => $member !== '' ? $member : 'Member ' . $reg,
            ':file_no' => $fileNo,
            ':cb' => $createdBy,
        ]);
        $sid = (int)db()->lastInsertId();
    } else {
        $sid = (int)$sid;
    }

    // Seed a ledger row for this receipt when the statement has no rows yet,
    // so the receipt amount still shows inside the statement while a proper
    // schedule hasn't been generated.
    if ($receiptId > 0) {
        $rowCount = db()->prepare('SELECT COUNT(*) FROM account_statement_rows WHERE statement_id = :sid');
        $rowCount->execute([':sid' => $sid]);
        if ((int)$rowCount->fetchColumn() === 0) {
            $amt = (float)$c['amount'];
            $dated = (string)($c['dated'] ?? '');
            db()->prepare(
                'INSERT INTO account_statement_rows
                    (statement_id, seq, description, inst_no, due_date, due_amount, paid_amount, paid_date, outstanding, receipt_id)
                 VALUES (:sid, 1, :desc, :inst, :ddate, :due_amt, :paid_amt, :pdate, 0, :rid)'
            )->execute([
                ':sid' => $sid,
                ':desc' => 'Payment received - ' . (string)($c['receipt_no'] ?? ''),
                ':inst' => (string)($c['receipt_no'] ?? ''),
                ':ddate' => $dated,
                ':due_amt' => $amt,
                ':paid_amt' => $amt,
                ':pdate' => $dated,
                ':rid' => $receiptId,
            ]);
        }
    }
    return $sid;
}

/** POST /receipts — save a new receipt voucher (auto-updates account statements). */
function create_receipt(array $body): void
{
    ensure_receipts_table();
    $c = receipt_columns($body);
    if ($c['receipt_no'] === '') fail('Receipt number is required');

    $dup = db()->prepare('SELECT id FROM receipts WHERE receipt_no = :no');
    $dup->execute([':no' => $c['receipt_no']]);
    if ($dup->fetchColumn() !== false) {
        fail('A receipt with number "' . $c['receipt_no'] . '" already exists', 409);
    }

    $createdBy = isset($body['created_by']) && (int)$body['created_by'] > 0 ? (int)$body['created_by'] : null;

    db()->prepare(
        'INSERT INTO receipts (receipt_no, reg_no, dated, received_from, amount, amount_words,
                               payment_type, payment_via, previous_balance, current_balance,
                               file_details, created_by)
         VALUES (:no, :reg, :dated, :from, :amount, :words, :ptype, :pvia, :prev, :curr, :fdet, :created_by)'
    )->execute([
        ':no' => $c['receipt_no'],
        ':reg' => $c['reg_no'],
        ':dated' => $c['dated'],
        ':from' => $c['received_from'],
        ':amount' => $c['amount'],
        ':words' => $c['amount_words'],
        ':ptype' => $c['payment_type'],
        ':pvia' => $c['payment_via'],
        ':prev' => $c['previous_balance'],
        ':curr' => $c['current_balance'],
        ':fdet' => $c['file_details'],
        ':created_by' => $createdBy,
    ]);
    $id = (int)db()->lastInsertId();
    ensure_statement_for_receipt($c, $createdBy, $id);
    sync_all_account_statements();

    $get = db()->prepare('SELECT * FROM receipts WHERE id = :id');
    $get->execute([':id' => $id]);
    respond(['data' => receipt_payload($get->fetch() ?: ['id' => $id]), 'message' => 'Receipt saved'], 201);
}

/** PUT /receipts/{id} — update an existing receipt voucher. */
function update_receipt(int $id, array $body): void
{
    ensure_receipts_table();
    $existing = db()->prepare('SELECT id, created_by FROM receipts WHERE id = :id');
    $existing->execute([':id' => $id]);
    $existingRow = $existing->fetch();
    if ($existingRow === false) fail('Receipt not found', 404);

    $c = receipt_columns($body);
    if ($c['receipt_no'] === '') fail('Receipt number is required');

    $dup = db()->prepare('SELECT id FROM receipts WHERE receipt_no = :no AND id <> :id');
    $dup->execute([':no' => $c['receipt_no'], ':id' => $id]);
    if ($dup->fetchColumn() !== false) {
        fail('A receipt with number "' . $c['receipt_no'] . '" already exists', 409);
    }

    db()->prepare(
        'UPDATE receipts SET receipt_no = :no, reg_no = :reg, dated = :dated, received_from = :from,
                amount = :amount, amount_words = :words, payment_type = :ptype, payment_via = :pvia,
                previous_balance = :prev, current_balance = :curr, file_details = :fdet
          WHERE id = :id'
    )->execute([
        ':no' => $c['receipt_no'],
        ':reg' => $c['reg_no'],
        ':dated' => $c['dated'],
        ':from' => $c['received_from'],
        ':amount' => $c['amount'],
        ':words' => $c['amount_words'],
        ':ptype' => $c['payment_type'],
        ':pvia' => $c['payment_via'],
        ':prev' => $c['previous_balance'],
        ':curr' => $c['current_balance'],
        ':fdet' => $c['file_details'],
        ':id' => $id,
    ]);
    $createdBy = isset($existingRow['created_by']) && $existingRow['created_by'] !== null ? (int)$existingRow['created_by'] : null;
    ensure_statement_for_receipt($c, $createdBy, $id);
    sync_all_account_statements();

    $get = db()->prepare('SELECT * FROM receipts WHERE id = :id');
    $get->execute([':id' => $id]);
    respond(['data' => receipt_payload($get->fetch() ?: []), 'message' => 'Receipt updated']);
}

/** DELETE /receipts/{id} */
function delete_receipt(int $id): void
{
    ensure_receipts_table();
    $stmt = db()->prepare('DELETE FROM receipts WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Receipt not found', 404);
    sync_all_account_statements();
    respond(['message' => 'Receipt deleted']);
}

/* ----------------------- ACCOUNT STATEMENTS ----------------------- */

function ensure_account_statements_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS account_statements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            registration_no VARCHAR(64) DEFAULT "",
            booking_date VARCHAR(20) DEFAULT "",
            member_name VARCHAR(255) DEFAULT "",
            file_no VARCHAR(64) DEFAULT "",
            so VARCHAR(255) DEFAULT "",
            plot_size VARCHAR(64) DEFAULT "",
            cnic VARCHAR(64) DEFAULT "",
            file_type VARCHAR(64) DEFAULT "",
            address VARCHAR(255) DEFAULT "",
            block VARCHAR(64) DEFAULT "",
            phone_no VARCHAR(64) DEFAULT "",
            street VARCHAR(64) DEFAULT "",
            file_status VARCHAR(64) DEFAULT "Active",
            cost_of_land DECIMAL(14,2) NOT NULL DEFAULT 0,
            remarks VARCHAR(255) DEFAULT "",
            created_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_as_reg (registration_no),
            INDEX idx_as_member (member_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
    db()->exec(
        'CREATE TABLE IF NOT EXISTS account_statement_rows (
            id INT AUTO_INCREMENT PRIMARY KEY,
            statement_id INT NOT NULL,
            seq INT NOT NULL DEFAULT 0,
            description VARCHAR(255) DEFAULT "",
            inst_no VARCHAR(64) DEFAULT "",
            due_date VARCHAR(20) DEFAULT "",
            due_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
            paid_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
            paid_date VARCHAR(20) DEFAULT "",
            outstanding DECIMAL(14,2) NOT NULL DEFAULT 0,
            receipt_id INT NULL,
            INDEX idx_asr_statement (statement_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

/** Cast + derive a ledger row for the API response. */
function statement_row_payload(array $row, bool $recompute = true): array
{
    foreach (['seq', 'statement_id'] as $k) {
        $row[$k] = isset($row[$k]) ? (int)$row[$k] : 0;
    }
    foreach (['due_amount', 'paid_amount', 'outstanding'] as $k) {
        $row[$k] = isset($row[$k]) ? (float)$row[$k] : 0.0;
    }
    if ($recompute) {
        $row['outstanding'] = max(0.0, (float)$row['due_amount'] - (float)$row['paid_amount']);
    }
    $row['receipt_id'] = isset($row['receipt_id']) && $row['receipt_id'] !== null ? (int)$row['receipt_id'] : null;
    return $row;
}

/** Build the full statement payload: ledger rows + derived summary numbers. */
function account_statement_payload(array $stmt): array
{
    if (!$stmt) return $stmt;
    $stmt['id'] = (int)$stmt['id'];
    $stmt['cost_of_land'] = isset($stmt['cost_of_land']) ? (float)$stmt['cost_of_land'] : 0.0;
    $stmt['created_by'] = isset($stmt['created_by']) && $stmt['created_by'] !== null ? (int)$stmt['created_by'] : null;

    $q = db()->prepare('SELECT * FROM account_statement_rows WHERE statement_id = :sid ORDER BY seq, id');
    $q->execute([':sid' => $stmt['id']]);
    $rows = array_map('statement_row_payload', $q->fetchAll());

    $received = 0.0;
    foreach ($rows as $r) {
        $received += (float)$r['paid_amount'];
    }
    $stmt['rows'] = $rows;
    $stmt['received_amount'] = round($received, 2);
    $stmt['balance'] = round(max(0.0, $stmt['cost_of_land'] - $received), 2);
    $stmt['payment_progress'] = $stmt['cost_of_land'] > 0
        ? round(($received / $stmt['cost_of_land']) * 100, 2)
        : 0.0;
    $stmt['generated_on'] = gmdate('d M Y g:i A');
    return $stmt;
}

/** GET /account-statements[?search=&created_by=] */
function list_account_statements(array $filters): void
{
    ensure_account_statements_table();
    $where = [];
    $params = [];
    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $cols = ['registration_no', 'member_name', 'file_no', 'so', 'cnic', 'phone_no'];
        $pats = [];
        foreach ($cols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $where[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['created_by'])) {
        $params[':created_by'] = to_int((string)$filters['created_by']);
        $where[] = 'created_by = :created_by';
    }
    $sql = 'SELECT * FROM account_statements';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = array_map('account_statement_payload', $stmt->fetchAll());
    respond(['data' => $rows, 'count' => count($rows)]);
}

/** GET /account-statements/{id} — single statement + ledger rows. */
function get_account_statement(int $id): void
{
    ensure_account_statements_table();
    $stmt = db()->prepare('SELECT * FROM account_statements WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) fail('Account statement not found', 404);
    respond(['data' => account_statement_payload($row)]);
}

/** Shared insert/update column list for an account statement body. */
function account_statement_columns(array $body): array
{
    $num = static function ($v): float {
        $cleaned = preg_replace('/[^0-9.\-]/', '', (string)($v ?? 0));
        return (float)($cleaned === '' ? 0 : $cleaned);
    };
    return [
        'registration_no' => normalize_optional($body['registration_no'] ?? null) ?? '',
        'booking_date' => normalize_optional($body['booking_date'] ?? null) ?? '',
        'member_name' => normalize_optional($body['member_name'] ?? null) ?? '',
        'file_no' => normalize_optional($body['file_no'] ?? null) ?? '',
        'so' => normalize_optional($body['so'] ?? null) ?? '',
        'plot_size' => normalize_optional($body['plot_size'] ?? null) ?? '',
        'cnic' => normalize_optional($body['cnic'] ?? null) ?? '',
        'file_type' => normalize_optional($body['file_type'] ?? null) ?? '',
        'address' => normalize_optional($body['address'] ?? null) ?? '',
        'block' => normalize_optional($body['block'] ?? null) ?? '',
        'phone_no' => normalize_optional($body['phone_no'] ?? null) ?? '',
        'street' => normalize_optional($body['street'] ?? null) ?? '',
        'file_status' => normalize_optional($body['file_status'] ?? null) ?? '',
        'cost_of_land' => $num($body['cost_of_land'] ?? 0),
        'remarks' => normalize_optional($body['remarks'] ?? null) ?? '',
    ];
}

/** POST /account-statements — create a statement (empty ledger). */
function create_account_statement(array $body): void
{
    ensure_account_statements_table();
    $c = account_statement_columns($body);
    $createdBy = isset($body['created_by']) && (int)$body['created_by'] > 0 ? (int)$body['created_by'] : null;

    db()->prepare(
        'INSERT INTO account_statements
            (registration_no, booking_date, member_name, file_no, so, plot_size, cnic, file_type,
             address, block, phone_no, street, file_status, cost_of_land, remarks, created_by)
         VALUES (:reg, :bdate, :member, :file_no, :so, :psize, :cnic, :ftype,
                 :addr, :block, :phone, :street, :fstatus, :cost, :remarks, :created_by)'
    )->execute([
        ':reg' => $c['registration_no'],
        ':bdate' => $c['booking_date'],
        ':member' => $c['member_name'],
        ':file_no' => $c['file_no'],
        ':so' => $c['so'],
        ':psize' => $c['plot_size'],
        ':cnic' => $c['cnic'],
        ':ftype' => $c['file_type'],
        ':addr' => $c['address'],
        ':block' => $c['block'],
        ':phone' => $c['phone_no'],
        ':street' => $c['street'],
        ':fstatus' => $c['file_status'] !== '' ? $c['file_status'] : 'Active',
        ':cost' => $c['cost_of_land'],
        ':remarks' => $c['remarks'],
        ':created_by' => $createdBy,
    ]);
    $id = (int)db()->lastInsertId();
    get_account_statement($id);
}

/** PUT /account-statements/{id} */
function update_account_statement(int $id, array $body): void
{
    ensure_account_statements_table();
    $existing = db()->prepare('SELECT id FROM account_statements WHERE id = :id');
    $existing->execute([':id' => $id]);
    if ($existing->fetchColumn() === false) fail('Account statement not found', 404);

    $c = account_statement_columns($body);
    db()->prepare(
        'UPDATE account_statements SET registration_no = :reg, booking_date = :bdate, member_name = :member,
                file_no = :file_no, so = :so, plot_size = :psize, cnic = :cnic, file_type = :ftype,
                address = :addr, block = :block, phone_no = :phone, street = :street,
                file_status = :fstatus, cost_of_land = :cost, remarks = :remarks
          WHERE id = :id'
    )->execute([
        ':reg' => $c['registration_no'],
        ':bdate' => $c['booking_date'],
        ':member' => $c['member_name'],
        ':file_no' => $c['file_no'],
        ':so' => $c['so'],
        ':psize' => $c['plot_size'],
        ':cnic' => $c['cnic'],
        ':ftype' => $c['file_type'],
        ':addr' => $c['address'],
        ':block' => $c['block'],
        ':phone' => $c['phone_no'],
        ':street' => $c['street'],
        ':fstatus' => $c['file_status'] !== '' ? $c['file_status'] : 'Active',
        ':cost' => $c['cost_of_land'],
        ':remarks' => $c['remarks'],
        ':id' => $id,
    ]);
    sync_statement_from_receipts($id);
    get_account_statement($id);
}

/** DELETE /account-statements/{id} */
function delete_account_statement(int $id): void
{
    ensure_account_statements_table();
    $delRows = db()->prepare('DELETE FROM account_statement_rows WHERE statement_id = :id');
    $delRows->execute([':id' => $id]);
    $stmt = db()->prepare('DELETE FROM account_statements WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Account statement not found', 404);
    respond(['message' => 'Account statement deleted']);
}

/** POST /account-statements/{id}/rows — add a ledger row. */
function add_statement_row(int $sid, array $body): void
{
    ensure_account_statements_table();
    $check = db()->prepare('SELECT id FROM account_statements WHERE id = :id');
    $check->execute([':id' => $sid]);
    if ($check->fetchColumn() === false) fail('Account statement not found', 404);

    $desc = normalize_optional($body['description'] ?? null) ?? '';
    if ($desc === '') fail('Row description is required');
    $seq = (int)($body['seq'] ?? 0);
    $due = (float)preg_replace('/[^0-9.\-]/', '', (string)($body['due_amount'] ?? 0));
    $paid = (float)preg_replace('/[^0-9.\-]/', '', (string)($body['paid_amount'] ?? 0));
    $outstanding = max(0.0, $due - $paid);

    db()->prepare(
        'INSERT INTO account_statement_rows
            (statement_id, seq, description, inst_no, due_date, due_amount, paid_amount, paid_date, outstanding)
         VALUES (:sid, :seq, :desc, :inst, :ddate, :due, :paid, :pdate, :out)'
    )->execute([
        ':sid' => $sid,
        ':seq' => $seq,
        ':desc' => $desc,
        ':inst' => normalize_optional($body['inst_no'] ?? null) ?? '',
        ':ddate' => normalize_optional($body['due_date'] ?? null) ?? '',
        ':due' => $due,
        ':paid' => $paid,
        ':pdate' => normalize_optional($body['paid_date'] ?? null) ?? '',
        ':out' => $outstanding,
    ]);
    sync_statement_from_receipts($sid);
    get_account_statement($sid);
}

/** PUT /account-statements/{sid}/rows/{rid} */
function update_statement_row(int $sid, int $rid, array $body): void
{
    ensure_account_statements_table();
    $check = db()->prepare('SELECT id FROM account_statement_rows WHERE id = :rid AND statement_id = :sid');
    $check->execute([':rid' => $rid, ':sid' => $sid]);
    if ($check->fetchColumn() === false) fail('Ledger row not found', 404);

    $desc = normalize_optional($body['description'] ?? null) ?? '';
    $due = (float)preg_replace('/[^0-9.\-]/', '', (string)($body['due_amount'] ?? 0));
    $paid = (float)preg_replace('/[^0-9.\-]/', '', (string)($body['paid_amount'] ?? 0));
    $outstanding = max(0.0, $due - $paid);

    db()->prepare(
        'UPDATE account_statement_rows SET
                seq = :seq, description = :desc, inst_no = :inst, due_date = :ddate,
                due_amount = :due, paid_amount = :paid, paid_date = :pdate, outstanding = :out,
                receipt_id = :receipt_id
          WHERE id = :rid AND statement_id = :sid'
    )->execute([
        ':seq' => (int)($body['seq'] ?? 0),
        ':desc' => $desc,
        ':inst' => normalize_optional($body['inst_no'] ?? null) ?? '',
        ':ddate' => normalize_optional($body['due_date'] ?? null) ?? '',
        ':due' => $due,
        ':paid' => $paid,
        ':pdate' => normalize_optional($body['paid_date'] ?? null) ?? '',
        ':out' => $outstanding,
        ':receipt_id' => isset($body['receipt_id']) && (int)$body['receipt_id'] > 0 ? (int)$body['receipt_id'] : null,
        ':rid' => $rid,
        ':sid' => $sid,
    ]);
    sync_statement_from_receipts($sid);
    get_account_statement($sid);
}

/** DELETE /account-statements/{sid}/rows/{rid} */
function delete_statement_row(int $sid, int $rid): void
{
    ensure_account_statements_table();
    $stmt = db()->prepare('DELETE FROM account_statement_rows WHERE id = :rid AND statement_id = :sid');
    $stmt->execute([':rid' => $rid, ':sid' => $sid]);
    if ($stmt->rowCount() === 0) fail('Ledger row not found', 404);
    sync_statement_from_receipts($sid);
    respond(['message' => 'Ledger row deleted']);
}

/**
 * POST /account-statements/{id}/schedule
 * Seeds the standard 31-row installment schedule like the Excel template:
 * one Booking/Advance row sized to the cost of land, then 30 installments
 * where every 6th is a "Half-Yearly Installment" and the rest regular.
 */
function generate_statement_schedule(int $sid): void
{
    ensure_account_statements_table();
    $stmt = db()->prepare('SELECT * FROM account_statements WHERE id = :id');
    $stmt->execute([':id' => $sid]);
    $st = $stmt->fetch();
    if (!$st) fail('Account statement not found', 404);

    // Clear any pre-existing schedule rows first (idempotent re-generation).
    $del = db()->prepare('DELETE FROM account_statement_rows WHERE statement_id = :id');
    $del->execute([':id' => $sid]);

    $cost = (float)$st['cost_of_land'];
    $ins = db()->prepare(
        'INSERT INTO account_statement_rows
            (statement_id, seq, description, inst_no, due_date, due_amount, paid_amount, paid_date, outstanding)
         VALUES (:sid, :seq, :desc, :inst, :ddate, :due, :paid, :pdate, :out)'
    );

    $seq = 1;
    $ins->execute([
        ':sid' => $sid, ':seq' => $seq++, ':desc' => 'Booking/Advance', ':inst' => '-',
        ':ddate' => 'N/A', ':due' => $cost, ':paid' => 0, ':pdate' => '', ':out' => $cost,
    ]);

    for ($i = 1; $i <= 30; $i++) {
        $isHalf = ($i % 6) === 0;
        $ins->execute([
            ':sid' => $sid, ':seq' => $seq++, ':desc' => $isHalf ? 'Half-Yearly Installment' : 'Regular Installment',
            ':inst' => (string)$i, ':ddate' => '', ':due' => 0, ':paid' => 0, ':pdate' => '', ':out' => 0,
        ]);
    }
    sync_statement_from_receipts($sid);
    get_account_statement($sid);
}

/** Receipts that belong to a statement (matched by reg # / file # / member name). */
function matching_receipts_for_statement(array $stmt): array
{
    $refs = array_values(array_filter(
        [$stmt['registration_no'] ?? '', $stmt['file_no'] ?? ''],
        fn($v) => trim((string)$v) !== ''
    ));
    $byId = [];
    if ($refs) {
        foreach ($refs as $ref) {
            $q = db()->prepare('SELECT * FROM receipts WHERE reg_no LIKE :ref ORDER BY dated IS NULL, dated, id');
            $q->execute([':ref' => '%' . trim((string)$ref) . '%']);
            foreach ($q->fetchAll() as $r) {
                $byId[(int)$r['id']] = $r;
            }
        }
    } else {
        $member = trim((string)($stmt['member_name'] ?? ''));
        if ($member === '') return [];
        $q = db()->prepare('SELECT * FROM receipts WHERE LOWER(received_from) = LOWER(:m) ORDER BY dated IS NULL, dated, id');
        $q->execute([':m' => $member]);
        foreach ($q->fetchAll() as $r) {
            $byId[(int)$r['id']] = $r;
        }
    }
    $receipts = array_values($byId);
    usort($receipts, static function ($a, $b): int {
        $da = (string)($a['dated'] ?? '');
        $db = (string)($b['dated'] ?? '');
        if ($da !== $db) return strcmp($da, $db);
        return (int)$a['id'] <=> (int)$b['id'];
    });
    return $receipts;
}

/**
 * Re-allocate every receipt for a statement across its ledger rows, in
 * receipt date order. Paid amounts are reset first so editing or deleting a
 * receipt keeps the statement consistent (the UI surfaces which rows are
 * receipt-driven via the receipt_id link).
 */
function sync_statement_from_receipts(int $statementId): void
{
    if (!table_exists('account_statements')) return;
    $stmt = db()->prepare('SELECT * FROM account_statements WHERE id = :id');
    $stmt->execute([':id' => $statementId]);
    $st = $stmt->fetch();
    if (!$st) return;

    $q = db()->prepare('SELECT * FROM account_statement_rows WHERE statement_id = :sid ORDER BY seq, id');
    $q->execute([':sid' => $statementId]);
    $rows = $q->fetchAll();
    if (!$rows) return;

    $receipts = matching_receipts_for_statement($st);

    // Reset paid columns before re-applying receipts (idempotent re-sync).
    $reset = db()->prepare(
        'UPDATE account_statement_rows SET paid_amount = 0, paid_date = "", outstanding = due_amount, receipt_id = NULL
          WHERE statement_id = :sid'
    );
    $reset->execute([':sid' => $statementId]);

    $upd = db()->prepare(
        'UPDATE account_statement_rows
            SET paid_amount = :paid, paid_date = :pdate, outstanding = :out, receipt_id = :receipt_id
          WHERE id = :id'
    );

    $rowIds = array_column($rows, 'id');
    foreach ($receipts as $receipt) {
        $remaining = (float)$receipt['amount'];
        $assigned = false;
        foreach ($rowIds as $i => $rid) {
            if ($remaining <= 0) break;
            $due = (float)$rows[$i]['due_amount'];
            $paid = (float)$rows[$i]['paid_amount'];
            $outstanding = max(0.0, $due - $paid);
            if ($outstanding <= 0) continue;

            $take = min($remaining, $outstanding);
            $newPaid = $paid + $take;
            $paidDate = $rows[$i]['paid_date'] !== '' ? $rows[$i]['paid_date'] : (string)($receipt['dated'] ?? '');
            $upd->execute([
                ':paid' => $newPaid,
                ':pdate' => $paidDate,
                ':out' => max(0.0, $due - $newPaid),
                ':receipt_id' => $assigned ? null : (int)$receipt['id'],
                ':id' => $rid,
            ]);
            $rows[$i]['paid_amount'] = $newPaid;
            $rows[$i]['paid_date'] = $paidDate;
            $rows[$i]['outstanding'] = max(0.0, $due - $newPaid);
            $remaining -= $take;
            $assigned = true;
        }
    }
}

/** Small table-existence helper used by the lazy-migration codepaths. */
function table_exists(string $table): bool
{
    $st = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.TABLES
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t"
    );
    $st->execute([':t' => $table]);
    return (int)$st->fetchColumn() > 0;
}

/* ----------------------- EMAILS (SMTP campaign sender) ----------------------- */

/**
 * POST /emails/send { to: string|string[], cc?, bcc?, subject, html, from_name? }
 * Sends the composed message through the crm@yadea.com.pk SMTP account.
 */
function send_email_campaign(array $body): void
{
    $to = $body['to'] ?? ($body['recipients'] ?? null);
    if ($to === null) fail('"to" (string or array of emails) is required');
    if (trim((string)($body['subject'] ?? '')) === '') fail('Subject is required');
    if (trim((string)($body['html'] ?? '')) === '') fail('Message body (html) is required');

    $result = send_crm_mail([
        'to' => $to,
        'cc' => $body['cc'] ?? null,
        'bcc' => $body['bcc'] ?? null,
        'subject' => (string)$body['subject'],
        'html' => (string)$body['html'],
        'from_name' => $body['from_name'] ?? null,
    ]);

    respond([
        'data' => [
            'sent_count' => count($result['sent']),
            'failed_count' => count($result['failed']),
            'sent' => $result['sent'],
            'failed' => $result['failed'],
        ],
        'message' => count($result['sent']) . ' email(s) sent via SMTP',
    ]);
}

/**
 * POST /emails/test { to, subject?, html? } -> quick deliverability check.
 */
function send_test_email(array $body): void
{
    $to = trim((string)($body['to'] ?? ''));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) fail('A valid "to" email is required');

    $subject = trim((string)($body['subject'] ?? '')) ?: 'Expert Builders CRM — SMTP test email';
    $html = trim((string)($body['html'] ?? ''))
        ?: '<p style="margin:0 0 10px 0;font-size:14px;color:#334155;">This is a test message from Expert Builders CRM.</p>'
            . '<p style="margin:0;font-size:13px;color:#64748b;">If you received this, the SMTP account '
            . htmlspecialchars(defined('SMTP_USER') ? SMTP_USER : '', ENT_QUOTES, 'UTF-8')
            . ' is working correctly.</p>';

    $result = send_crm_mail(['to' => $to, 'subject' => $subject, 'html' => $html]);
    if (count($result['sent']) === 1) {
        respond(['data' => ['sent' => $result['sent'], 'failed' => $result['failed']], 'message' => "Test email sent to {$to}"]);
    }
    fail('SMTP send failed: ' . (reset($result['failed']) ?: 'unknown error'));
}

/* ----------------------- PORTAL SUBMISSIONS (dealership + inquiries) ----------------------- */

/**
 * Shared store for the two public-style portal forms: dealership
 * applications and customer support inquiries. Admins can assign inquiries
 * to Dealer staff accounts.
 */
function ensure_portal_submissions_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    db()->exec(
        'CREATE TABLE IF NOT EXISTS portal_submissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(20) NOT NULL,
            code VARCHAR(24) DEFAULT "",
            name VARCHAR(255) DEFAULT "",
            email VARCHAR(255) DEFAULT "",
            phone VARCHAR(64) DEFAULT "",
            business_name VARCHAR(255) DEFAULT "",
            address VARCHAR(255) DEFAULT "",
            years_in_business VARCHAR(16) DEFAULT "",
            oem_dealer VARCHAR(16) DEFAULT "",
            province VARCHAR(64) DEFAULT "",
            city VARCHAR(64) DEFAULT "",
            property_ownership VARCHAR(64) DEFAULT "",
            structure VARCHAR(64) DEFAULT "",
            file_name VARCHAR(255) DEFAULT "",
            chassis_number VARCHAR(100) DEFAULT "",
            order_number VARCHAR(100) DEFAULT "",
            problem_category VARCHAR(120) DEFAULT "",
            reason TEXT,
            assigned_to INT NULL,
            status VARCHAR(20) NOT NULL DEFAULT "new",
            created_by INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ps_type (type),
            INDEX idx_ps_assigned (assigned_to)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );
}

/** Normalise every submission text field in one place. */
function portal_submission_fields(array $body): array
{
    $t = static fn ($v): string => normalize_optional($v ?? null) ?? '';
    return [
        'name' => $t($body['name'] ?? ''),
        'email' => $t($body['email'] ?? ''),
        'phone' => $t($body['phone'] ?? ''),
        'business_name' => $t($body['business_name'] ?? ''),
        'address' => $t($body['address'] ?? ''),
        'years_in_business' => $t($body['years_in_business'] ?? ''),
        'oem_dealer' => $t($body['oem_dealer'] ?? ''),
        'province' => $t($body['province'] ?? ''),
        'city' => $t($body['city'] ?? ''),
        'property_ownership' => $t($body['property_ownership'] ?? ''),
        'structure' => $t($body['structure'] ?? ''),
        'file_name' => $t($body['file_name'] ?? ''),
        'chassis_number' => $t($body['chassis_number'] ?? ''),
        'order_number' => $t($body['order_number'] ?? ''),
        'problem_category' => $t($body['problem_category'] ?? ''),
        'reason' => $t($body['reason'] ?? ''),
    ];
}

function portal_submission_payload(array $row): array
{
    $row['id'] = (int)$row['id'];
    $row['assigned_to'] = $row['assigned_to'] !== null ? (int)$row['assigned_to'] : null;
    $row['created_by'] = $row['created_by'] !== null ? (int)$row['created_by'] : null;
    return $row;
}

/** POST /submissions - create a dealership application or inquiry ticket. */
function create_submission(array $body): void
{
    ensure_portal_submissions_table();
    $type = ($body['type'] ?? '') === 'inquiry' ? 'inquiry' : 'dealership';
    $f = portal_submission_fields($body);

    if ($f['name'] === '' && $f['business_name'] === '') fail('Name is required');
    if ($type === 'inquiry' && $f['chassis_number'] === '') fail('Chassis number is required');

    // Human-friendly reference code, retried on the rare duplicate.
    $prefix = $type === 'inquiry' ? 'TCK-' : 'DLR-';
    $code = '';
    for ($i = 0; $i < 5; $i++) {
        $candidate = $prefix . random_int(1000, 9999);
        $chk = db()->prepare('SELECT id FROM portal_submissions WHERE code = :c LIMIT 1');
        $chk->execute([':c' => $candidate]);
        if ($chk->fetchColumn() === false) {
            $code = $candidate;
            break;
        }
    }
    if ($code === '') $code = $prefix . time();

    $stmt = db()->prepare(
        'INSERT INTO portal_submissions
            (type, code, name, email, phone, business_name, address, years_in_business,
             oem_dealer, province, city, property_ownership, structure, file_name,
             chassis_number, order_number, problem_category, reason, created_by)
         VALUES (:type, :code, :name, :email, :phone, :biz, :address, :years,
                 :oem, :province, :city, :prop, :structure, :file,
                 :chassis, :order, :problem, :reason, :created_by)'
    );
    $stmt->execute([
        ':type' => $type,
        ':code' => $code,
        ':name' => $f['name'],
        ':email' => $f['email'],
        ':phone' => $f['phone'],
        ':biz' => $f['business_name'],
        ':address' => $f['address'],
        ':years' => $f['years_in_business'],
        ':oem' => $f['oem_dealer'],
        ':province' => $f['province'],
        ':city' => $f['city'],
        ':prop' => $f['property_ownership'],
        ':structure' => $f['structure'],
        ':file' => $f['file_name'],
        ':chassis' => $f['chassis_number'],
        ':order' => $f['order_number'],
        ':problem' => $f['problem_category'],
        ':reason' => $f['reason'],
        ':created_by' => isset($body['created_by']) && (int)$body['created_by'] > 0 ? (int)$body['created_by'] : null,
    ]);

    $get = db()->prepare(
        'SELECT s.*, u.full_name AS assigned_to_name FROM portal_submissions s
         LEFT JOIN staff_users u ON u.id = s.assigned_to WHERE s.id = :id'
    );
    $get->execute([':id' => (int)db()->lastInsertId()]);
    respond(['data' => portal_submission_payload($get->fetch() ?: []), 'message' => 'Submission saved'], 201);
}

/**
 * GET /submissions?type=&assigned_to=&restrict_to=&search=
 * restrict_to locks a non-admin viewer to only what is assigned to them.
 */
function list_submissions(array $filters): void
{
    ensure_portal_submissions_table();
    $where = [];
    $params = [];

    if (!empty($filters['type'])) {
        $where[] = 's.type = :type';
        $params[':type'] = $filters['type'] === 'inquiry' ? 'inquiry' : 'dealership';
    }
    if (!empty($filters['assigned_to'])) {
        $aid = to_int((string)$filters['assigned_to']);
        if ($aid > 0) {
            $where[] = 's.assigned_to = :aid';
            $params[':aid'] = $aid;
        }
    }
    if (!empty($filters['restrict_to'])) {
        // Dealers only ever see inquiries assigned to them.
        $rid = to_int((string)$filters['restrict_to']);
        $where[] = 's.assigned_to = :rid';
        $params[':rid'] = $rid;
    }
    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $cols = ['s.code', 's.name', 's.email', 's.phone', 's.business_name', 's.city', 's.chassis_number', 's.problem_category'];
        $pats = [];
        foreach ($cols as $i => $col) {
            $pname = ':search' . $i;
            $params[$pname] = $term;
            $pats[] = "$col LIKE $pname";
        }
        $where[] = '(' . implode(' OR ', $pats) . ')';
    }

    $sql = 'SELECT s.*, u.full_name AS assigned_to_name FROM portal_submissions s
            LEFT JOIN staff_users u ON u.id = s.assigned_to';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY s.id DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    respond(['data' => array_map('portal_submission_payload', $stmt->fetchAll()), 'count' => $stmt->rowCount()]);
}

/** POST /submissions/{id}/assign { assigned_to } -> assign/unassign a dealer. */
function assign_submission(int $id, array $body): void
{
    ensure_portal_submissions_table();
    $dealerId = to_int((string)($body['assigned_to'] ?? 0));

    if ($dealerId > 0) {
        $chk = db()->prepare("SELECT id FROM staff_users WHERE id = :id AND user_type IN ('Admin','Dealer') LIMIT 1");
        $chk->execute([':id' => $dealerId]);
        if ($chk->fetchColumn() === false) fail('Dealer not found', 404);
    }

    $stmt = db()->prepare(
        'UPDATE portal_submissions SET assigned_to = :aid, status = :status WHERE id = :id'
    );
    $stmt->execute([
        ':aid' => $dealerId > 0 ? $dealerId : null,
        ':status' => $dealerId > 0 ? 'assigned' : 'new',
        ':id' => $id,
    ]);
    if ($stmt->rowCount() === 0) {
        $exists = db()->prepare('SELECT id FROM portal_submissions WHERE id = :id');
        $exists->execute([':id' => $id]);
        if ($exists->fetchColumn() === false) fail('Submission not found', 404);
    }

    // Portal bell + email notification so the dealer instantly knows about
    // the new assignment (email rides on notify_staff's SMTP path).
    if ($dealerId > 0) {
        $get = db()->prepare('SELECT * FROM portal_submissions WHERE id = :id');
        $get->execute([':id' => $id]);
        $s = $get->fetch();
        if ($s) {
            $isInquiry = ($s['type'] ?? '') === 'inquiry';
            $who = $s['name'] !== '' ? $s['name'] : ($s['business_name'] ?: 'A customer');
            $place = $s['city'] !== '' ? ', ' . $s['city'] : '';
            $title = $isInquiry
                ? 'New support ticket assigned to you'
                : 'New dealership application assigned to you';
            $detail = $isInquiry
                ? "Ticket {$s['code']} — {$s['problem_category']} for {$who}{$place} (chassis {$s['chassis_number']}). Open Customer Inquiries to follow up."
                : "Application {$s['code']} from {$who}{$place} ({$s['business_name']}). Open Dealership Page to review.";
            notify_staff($dealerId, null, $isInquiry ? 'inquiry_assigned' : 'application_assigned', $title, $detail);
        }
    }

    $get = db()->prepare(
        'SELECT s.*, u.full_name AS assigned_to_name FROM portal_submissions s
         LEFT JOIN staff_users u ON u.id = s.assigned_to WHERE s.id = :id'
    );
    $get->execute([':id' => $id]);
    respond([
        'data' => portal_submission_payload($get->fetch() ?: []),
        'message' => $dealerId > 0 ? 'Inquiry assigned' : 'Assignment removed',
    ]);
}

/** DELETE /submissions/{id} */
function delete_submission(int $id): void
{
    ensure_portal_submissions_table();
    db()->prepare('DELETE FROM portal_submissions WHERE id = :id')->execute([':id' => $id]);
    respond(['message' => 'Submission deleted']);
}

/* ================================================================
 * PROPERTY INVENTORY
 *
 * Flat (non-contact) property records for the Property Management
 * module. Created lazily like portal_submissions so existing
 * deployments upgrade without a manual migration.
 * ================================================================ */

const PROPERTY_TYPES = ['Residential', 'Commercial', 'Industrial', 'Plot'];
/* Sale statuses the UI offers. The column stays VARCHAR so a custom status set
   from the dropdown is stored as-is instead of being reset to UnSold. */
const PROPERTY_SALE_STATUSES = ['UnSold', 'Sold'];
const PROPERTY_BUYBACK_STATUSES = [
    'Not Eligible', 'Eligible', 'Requested', 'Approved', 'Rejected',
];
const PROPERTY_STATUSES = ['Active', 'Inactive'];
const PROPERTY_PURPOSES = ['Sell', 'Rent'];
const PROPERTY_CURRENCIES = ['PKR', 'USD', 'EUR'];

function ensure_properties_table(): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    db()->exec(
        'CREATE TABLE IF NOT EXISTS properties (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(64) DEFAULT "",
            property_type VARCHAR(32) DEFAULT "Residential",
            subtype VARCHAR(64) DEFAULT "",
            purpose VARCHAR(16) DEFAULT "Sell",
            floor VARCHAR(64) DEFAULT "",
            block VARCHAR(120) DEFAULT "",
            registration_no VARCHAR(64) DEFAULT "",
            current_status VARCHAR(16) DEFAULT "UnSold",
            status VARCHAR(16) DEFAULT "Active",
            sale_price DECIMAL(20,2) DEFAULT 0,
            currency VARCHAR(8) DEFAULT "PKR",
            installment_available TINYINT(1) NOT NULL DEFAULT 0,
            advance_amount DECIMAL(20,2) DEFAULT 0,
            installment_count INT DEFAULT 0,
            monthly_installment DECIMAL(20,2) DEFAULT 0,
            balloon_payment_available TINYINT(1) NOT NULL DEFAULT 0,
            balloon_amount DECIMAL(20,2) DEFAULT 0,
            balloon_payment_count INT DEFAULT 0,
            balloting_fee_available TINYINT(1) NOT NULL DEFAULT 0,
            balloting_fee DECIMAL(20,2) DEFAULT 0,
            possession_fee_available TINYINT(1) NOT NULL DEFAULT 0,
            possession_fee DECIMAL(20,2) DEFAULT 0,
            development_fee_available TINYINT(1) NOT NULL DEFAULT 0,
            development_fee DECIMAL(20,2) DEFAULT 0,
            ready_for_possession TINYINT(1) NOT NULL DEFAULT 0,
            bedrooms VARCHAR(16) DEFAULT "",
            bathrooms VARCHAR(16) DEFAULT "",
            amenities TEXT,
            video_url VARCHAR(500) DEFAULT "",
            contact_email VARCHAR(160) DEFAULT "",
            contact_mobile VARCHAR(255) DEFAULT "",
            contact_landline VARCHAR(64) DEFAULT "",
            original_price DECIMAL(20,2) DEFAULT 0,
            discount DECIMAL(20,2) DEFAULT 0,
            payment_plan VARCHAR(255) DEFAULT "",
            customer VARCHAR(255) DEFAULT "",
            agent VARCHAR(255) DEFAULT "",
            sale_date DATE NULL,
            booking_date DATE NULL,
            transfer_status VARCHAR(32) DEFAULT "Not Initiated",
            transfer_date DATE NULL,
            transfer_from VARCHAR(255) DEFAULT "",
            transfer_to VARCHAR(255) DEFAULT "",
            buyback_status VARCHAR(32) DEFAULT "Not Eligible",
            buyback_price DECIMAL(20,2) DEFAULT 0,
            buyback_requested_on DATE NULL,
            buyback_approved_on DATE NULL,
            address VARCHAR(255) DEFAULT "",
            city VARCHAR(120) DEFAULT "",
            area VARCHAR(120) DEFAULT "",
            size VARCHAR(64) DEFAULT "",
            unit VARCHAR(64) DEFAULT "",
            latitude DECIMAL(10,7) NULL,
            longitude DECIMAL(10,7) NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_prop_status (status),
            INDEX idx_prop_type (property_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
    );

    // Column migration: the CREATE TABLE above is a no-op once the table
    // exists, so add the Location/Purpose columns explicitly.
    $colCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'purpose'"
    );
    $colCheck->execute();
    if ((int)$colCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN subtype VARCHAR(64) DEFAULT "" AFTER property_type');
        db()->exec('ALTER TABLE properties ADD COLUMN purpose VARCHAR(16) DEFAULT "Sell" AFTER subtype');
    }

    $priceCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'currency'"
    );
    $priceCheck->execute();
    if ((int)$priceCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN currency VARCHAR(8) DEFAULT "PKR" AFTER sale_price');
        db()->exec('ALTER TABLE properties ADD COLUMN installment_available TINYINT(1) NOT NULL DEFAULT 0 AFTER currency');
        db()->exec('ALTER TABLE properties ADD COLUMN ready_for_possession TINYINT(1) NOT NULL DEFAULT 0 AFTER installment_available');
    }

    $planCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'advance_amount'"
    );
    $planCheck->execute();
    if ((int)$planCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN advance_amount DECIMAL(20,2) DEFAULT 0 AFTER installment_available');
        db()->exec('ALTER TABLE properties ADD COLUMN installment_count INT DEFAULT 0 AFTER advance_amount');
        db()->exec('ALTER TABLE properties ADD COLUMN monthly_installment DECIMAL(20,2) DEFAULT 0 AFTER installment_count');
    }

    $feeCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'balloon_payment_available'"
    );
    $feeCheck->execute();
    if ((int)$feeCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN balloon_payment_available TINYINT(1) NOT NULL DEFAULT 0 AFTER monthly_installment');
        db()->exec('ALTER TABLE properties ADD COLUMN balloting_fee_available TINYINT(1) NOT NULL DEFAULT 0 AFTER balloon_payment_available');
        db()->exec('ALTER TABLE properties ADD COLUMN balloting_fee DECIMAL(20,2) DEFAULT 0 AFTER balloting_fee_available');
        db()->exec('ALTER TABLE properties ADD COLUMN possession_fee_available TINYINT(1) NOT NULL DEFAULT 0 AFTER balloting_fee');
        db()->exec('ALTER TABLE properties ADD COLUMN possession_fee DECIMAL(20,2) DEFAULT 0 AFTER possession_fee_available');
        db()->exec('ALTER TABLE properties ADD COLUMN development_fee_available TINYINT(1) NOT NULL DEFAULT 0 AFTER possession_fee');
        db()->exec('ALTER TABLE properties ADD COLUMN development_fee DECIMAL(20,2) DEFAULT 0 AFTER development_fee_available');
    }

    $balloonAmountCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'balloon_amount'"
    );
    $balloonAmountCheck->execute();
    if ((int)$balloonAmountCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN balloon_amount DECIMAL(20,2) DEFAULT 0 AFTER balloon_payment_available');
        db()->exec('ALTER TABLE properties ADD COLUMN balloon_payment_count INT DEFAULT 0 AFTER balloon_amount');
    }

    $amenityCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'amenities'"
    );
    $amenityCheck->execute();
    if ((int)$amenityCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN bedrooms VARCHAR(16) DEFAULT "" AFTER ready_for_possession');
        db()->exec('ALTER TABLE properties ADD COLUMN bathrooms VARCHAR(16) DEFAULT "" AFTER bedrooms');
        db()->exec('ALTER TABLE properties ADD COLUMN amenities TEXT AFTER bathrooms');
    }

    $amenitiesTextCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'amenities'
            AND DATA_TYPE    = 'text'"
    );
    $amenitiesTextCheck->execute();
    if ((int)$amenitiesTextCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties MODIFY COLUMN amenities TEXT');
    }

    /* Buy-back columns. The tab used to be hard-coded placeholders, so an
       existing table needs them added one by one. */
    $buybackCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'buyback_status'"
    );
    $buybackCheck->execute();
    if ((int)$buybackCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN buyback_status VARCHAR(32) DEFAULT "Not Eligible" AFTER transfer_to');
        db()->exec('ALTER TABLE properties ADD COLUMN buyback_price DECIMAL(20,2) DEFAULT 0 AFTER buyback_status');
        db()->exec('ALTER TABLE properties ADD COLUMN buyback_requested_on DATE NULL AFTER buyback_price');
        db()->exec('ALTER TABLE properties ADD COLUMN buyback_approved_on DATE NULL AFTER buyback_requested_on');
    }

    $mediaCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'video_url'"
    );
    $mediaCheck->execute();
    if ((int)$mediaCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN video_url VARCHAR(500) DEFAULT "" AFTER amenities');
        db()->exec('ALTER TABLE properties ADD COLUMN contact_email VARCHAR(160) DEFAULT "" AFTER video_url');
        db()->exec('ALTER TABLE properties ADD COLUMN contact_mobile VARCHAR(255) DEFAULT "" AFTER contact_email');
        db()->exec('ALTER TABLE properties ADD COLUMN contact_landline VARCHAR(64) DEFAULT "" AFTER contact_mobile');
    }

    $geoCheck = db()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME   = 'properties'
            AND COLUMN_NAME  = 'latitude'"
    );
    $geoCheck->execute();
    if ((int)$geoCheck->fetchColumn() === 0) {
        db()->exec('ALTER TABLE properties ADD COLUMN latitude DECIMAL(10,7) NULL AFTER unit');
        db()->exec('ALTER TABLE properties ADD COLUMN longitude DECIMAL(10,7) NULL AFTER latitude');
    }

    // No starter inventory: the table stays empty until a property is added.
}

/** Whitelist + normalise every writable property column. */
function property_fields(array $body): array
{
    $t = static fn ($v): string => normalize_optional($v ?? null) ?? '';
    $pick = static function ($v, array $allowed, array $fallback) use ($t): string {
        $v = $t($v);
        return in_array($v, $allowed, true) ? $v : $fallback;
    };
    $money = static function ($v): float {
        $v = normalize_optional($v ?? null);
        return $v === null || $v === '' ? 0.0 : (float)preg_replace('/[^0-9.\-]/', '', (string)$v);
    };
    $flag = static fn ($v): int => (int)filter_var($v ?? false, FILTER_VALIDATE_BOOLEAN);
    $coord = static function ($v): ?float {
        if ($v === null || $v === '') return null;
        $n = (float)$v;
        return is_finite($n) ? $n : null;
    };

    return [
        'name' => $t($body['name'] ?? ''),
        'code' => $t($body['code'] ?? ''),
        'property_type' => $pick($body['property_type'] ?? '', PROPERTY_TYPES, 'Residential'),
        'subtype' => $t($body['subtype'] ?? ''),
        'purpose' => $pick($body['purpose'] ?? '', PROPERTY_PURPOSES, 'Sell'),
        'floor' => $t($body['floor'] ?? ''),
        'block' => $t($body['block'] ?? ''),
        'registration_no' => $t($body['registration_no'] ?? ''),
        /* Accept any non-empty status so custom dropdown values survive a save. */
'current_status' => $t($body['current_status'] ?? '') ?: 'UnSold',
        'status' => $pick($body['status'] ?? '', PROPERTY_STATUSES, 'Active'),
        'sale_price' => $money($body['sale_price'] ?? 0),
        'currency' => $pick($body['currency'] ?? '', PROPERTY_CURRENCIES, 'PKR'),
        'installment_available' => $flag($body['installment_available'] ?? false),
        'advance_amount' => $money($body['advance_amount'] ?? 0),
        'installment_count' => (int)(float)str_replace(',', '', trim((string)($body['installment_count'] ?? '0'))),
        'monthly_installment' => $money($body['monthly_installment'] ?? 0),
        'balloon_payment_available' => $flag($body['balloon_payment_available'] ?? false),
        'balloon_amount' => $money($body['balloon_amount'] ?? 0),
        'balloon_payment_count' => (int)(float)str_replace(',', '', trim((string)($body['balloon_payment_count'] ?? '0'))),
        'balloting_fee_available' => $flag($body['balloting_fee_available'] ?? false),
        'balloting_fee' => $money($body['balloting_fee'] ?? 0),
        'possession_fee_available' => $flag($body['possession_fee_available'] ?? false),
        'possession_fee' => $money($body['possession_fee'] ?? 0),
        'development_fee_available' => $flag($body['development_fee_available'] ?? false),
        'development_fee' => $money($body['development_fee'] ?? 0),
        'ready_for_possession' => $flag($body['ready_for_possession'] ?? false),
        'bedrooms' => $t($body['bedrooms'] ?? ''),
        'bathrooms' => $t($body['bathrooms'] ?? ''),
        'amenities' => $t($body['amenities'] ?? ''),
        'video_url' => mb_substr($t($body['video_url'] ?? ''), 0, 500),
        'contact_email' => mb_substr($t($body['contact_email'] ?? ''), 0, 160),
        'contact_mobile' => mb_substr($t($body['contact_mobile'] ?? ''), 0, 255),
        'contact_landline' => mb_substr($t($body['contact_landline'] ?? ''), 0, 64),
        'original_price' => $money($body['original_price'] ?? 0),
        'discount' => $money($body['discount'] ?? 0),
        'payment_plan' => $t($body['payment_plan'] ?? ''),
        'customer' => $t($body['customer'] ?? ''),
        'agent' => $t($body['agent'] ?? ''),
        'sale_date' => $t($body['sale_date'] ?? '') ?: null,
        'booking_date' => $t($body['booking_date'] ?? '') ?: null,
        'transfer_status' => $t($body['transfer_status'] ?? '') ?: 'Not Initiated',
        'transfer_date' => $t($body['transfer_date'] ?? '') ?: null,
        'transfer_from' => $t($body['transfer_from'] ?? ''),
        'transfer_to' => $t($body['transfer_to'] ?? ''),
        'buyback_status' => $pick($body['buyback_status'] ?? '', PROPERTY_BUYBACK_STATUSES, 'Not Eligible'),
        'buyback_price' => $money($body['buyback_price'] ?? 0),
        'buyback_requested_on' => $t($body['buyback_requested_on'] ?? '') ?: null,
        'buyback_approved_on' => $t($body['buyback_approved_on'] ?? '') ?: null,
        'address' => $t($body['address'] ?? ''),
        'city' => $t($body['city'] ?? ''),
        'area' => $t($body['area'] ?? ''),
        'size' => $t($body['size'] ?? ''),
        'unit' => $t($body['unit'] ?? ''),
        'latitude' => $coord($body['latitude'] ?? null),
        'longitude' => $coord($body['longitude'] ?? null),
        'description' => $t($body['description'] ?? ''),
    ];
}

function property_payload(array $row): array
{
    $row['id'] = (int)$row['id'];
    foreach (['sale_price', 'original_price', 'discount'] as $f) {
        if (isset($row[$f])) $row[$f] = (float)$row[$f];
    }
    foreach (['installment_available', 'ready_for_possession', 'installment_count', 'balloon_payment_available', 'balloon_payment_count', 'balloting_fee_available', 'possession_fee_available', 'development_fee_available'] as $f) {
        if (isset($row[$f])) $row[$f] = (int)$row[$f];
    }
    foreach (['advance_amount', 'monthly_installment', 'balloon_amount', 'balloting_fee', 'possession_fee', 'development_fee'] as $f) {
        if (isset($row[$f])) $row[$f] = (float)$row[$f];
    }
    foreach (['latitude', 'longitude'] as $f) {
        if (isset($row[$f])) $row[$f] = $row[$f] === null ? null : (float)$row[$f];
    }
    return $row;
}

/** GET /properties?search=&property_type=&current_status=&status=&floor=&block= */
function list_properties(array $filters): void
{
    ensure_properties_table();
    $where = [];
    $params = [];

    if (!empty($filters['search'])) {
        $term = '%' . $filters['search'] . '%';
        $cols = ['name', 'code', 'registration_no', 'block', 'floor'];
        $pats = [];
        foreach ($cols as $i => $col) {
            $p = ':s' . $i;
            $params[$p] = $term;
            $pats[] = "$col LIKE $p";
        }
        $where[] = '(' . implode(' OR ', $pats) . ')';
    }
    if (!empty($filters['property_type'])) {
        $where[] = 'property_type = :ptype';
        $params[':ptype'] = $filters['property_type'];
    }
    if (!empty($filters['current_status'])) {
        $where[] = 'current_status = :cstatus';
        $params[':cstatus'] = $filters['current_status'];
    }
    if (!empty($filters['status'])) {
        $where[] = 'status = :pstatus';
        $params[':pstatus'] = $filters['status'];
    }
    if (!empty($filters['floor'])) {
        $where[] = 'floor = :floor';
        $params[':floor'] = $filters['floor'];
    }
    if (!empty($filters['block'])) {
        $where[] = 'block = :block';
        $params[':block'] = $filters['block'];
    }

    $sql = 'SELECT * FROM properties';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id ASC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    respond(['data' => array_map('property_payload', $stmt->fetchAll()), 'count' => $stmt->rowCount()]);
}

/** POST /properties */
function create_property(array $body): void
{
    ensure_properties_table();
    $f = property_fields($body);
    if ($f['name'] === '') fail('Property name is required');

    /* No code from the client? Hand out the next sequential one: Expert Inv 001, 002, ... */
    if ($f['code'] === '') {
        $next = (int) db()->query(
            "SELECT COALESCE(MAX(
                        IF(code REGEXP '^[0-9]+$', CAST(code AS UNSIGNED),
                        IF(code LIKE 'Expert Inv %', CAST(SUBSTRING(code, 12) AS UNSIGNED), 0))), 0) + 1
               FROM properties WHERE code <> ''"
        )->fetchColumn();
        $f['code'] = sprintf('Expert Inv %03d', $next);
    }

    $stmt = db()->prepare(
        'INSERT INTO properties
            (name, code, property_type, subtype, purpose, floor, block, registration_no,
             current_status, status,
             sale_price, currency, installment_available, advance_amount, installment_count,
             monthly_installment, balloon_payment_available, balloon_amount, balloon_payment_count,
             balloting_fee_available, balloting_fee,
             possession_fee_available, possession_fee,
             development_fee_available, development_fee, ready_for_possession,
             bedrooms, bathrooms, amenities, video_url,
             contact_email, contact_mobile, contact_landline,
             original_price, discount, payment_plan, customer, agent, sale_date,
             booking_date, transfer_status, transfer_date, transfer_from, transfer_to,
             buyback_status, buyback_price, buyback_requested_on, buyback_approved_on,
             address, city, area, size, unit, latitude, longitude, description)
         VALUES (:name, :code, :ptype, :subtype, :purpose, :floor, :block, :reg, :cstatus, :status,
                 :sale, :currency, :installment, :adv_amt, :inst_count, :monthly,
                 :balloon, :balloon_amt, :balloon_count, :balloting_on, :balloting_fee, :pos_fee_on, :pos_fee,
                 :dev_fee_on, :dev_fee, :possession,
                 :bedrooms, :bathrooms, :amenities, :video_url,
                 :c_email, :c_mobile, :c_landline,
                 :orig, :disc, :plan, :cust, :agent, :sale_date,
                 :book_date, :tstatus, :tdate, :tfrom, :tto,
                 :address, :city, :area, :size, :unit, :latitude, :longitude, :description)'
    );
    $stmt->execute([
        ':name' => $f['name'], ':code' => $f['code'], ':ptype' => $f['property_type'],
        ':subtype' => $f['subtype'], ':purpose' => $f['purpose'],
        ':floor' => $f['floor'], ':block' => $f['block'], ':reg' => $f['registration_no'],
        ':cstatus' => $f['current_status'], ':status' => $f['status'],
        ':sale' => $f['sale_price'],
        ':currency' => $f['currency'], ':installment' => $f['installment_available'],
        ':adv_amt' => $f['advance_amount'],
        ':inst_count' => $f['installment_count'],
        ':monthly' => $f['monthly_installment'],
        ':balloon' => $f['balloon_payment_available'],
        ':balloon_amt' => $f['balloon_amount'],
        ':balloon_count' => $f['balloon_payment_count'],
        ':balloting_on' => $f['balloting_fee_available'], ':balloting_fee' => $f['balloting_fee'],
        ':pos_fee_on' => $f['possession_fee_available'], ':pos_fee' => $f['possession_fee'],
        ':dev_fee_on' => $f['development_fee_available'], ':dev_fee' => $f['development_fee'],
        ':possession' => $f['ready_for_possession'],
        ':bedrooms' => $f['bedrooms'], ':bathrooms' => $f['bathrooms'],
        ':amenities' => $f['amenities'], ':video_url' => $f['video_url'],
        ':c_email' => $f['contact_email'], ':c_mobile' => $f['contact_mobile'],
        ':c_landline' => $f['contact_landline'],
        ':orig' => $f['original_price'], ':disc' => $f['discount'],
        ':plan' => $f['payment_plan'], ':cust' => $f['customer'], ':agent' => $f['agent'],
        ':sale_date' => $f['sale_date'], ':book_date' => $f['booking_date'],
        ':tstatus' => $f['transfer_status'], ':tdate' => $f['transfer_date'],
        ':tfrom' => $f['transfer_from'], ':tto' => $f['transfer_to'],
        ':bb_status' => $f['buyback_status'], ':bb_price' => $f['buyback_price'],
        ':bb_requested' => $f['buyback_requested_on'], ':bb_approved' => $f['buyback_approved_on'],
        ':address' => $f['address'], ':city' => $f['city'], ':area' => $f['area'],
        ':size' => $f['size'], ':unit' => $f['unit'],
        ':latitude' => $f['latitude'], ':longitude' => $f['longitude'],
        ':description' => $f['description'],
    ]);

    $get = db()->prepare('SELECT * FROM properties WHERE id = :id');
    $get->execute([':id' => (int)db()->lastInsertId()]);
    respond(['data' => property_payload($get->fetch() ?: []), 'message' => 'Property created'], 201);
}

/** PUT /properties/{id} */
function update_property(int $id, array $body): void
{
    ensure_properties_table();
    $exists = db()->prepare('SELECT * FROM properties WHERE id = :id');
    $exists->execute([':id' => $id]);
    $current = $exists->fetch();
    if (!$current) fail('Property not found', 404);

    /* Partial update: anything absent from the body keeps its stored value, so a
       rename (or any single field edit) cannot wipe the rest of the listing. */
    $f = property_fields(array_merge($current, $body));
    if ($f['name'] === '') fail('Property name is required');

    $sets = [];
    $params = [':id' => $id];
    foreach ($f as $col => $val) {
        $sets[] = "$col = :$col";
        $params[":$col"] = $val;
    }

    db()->prepare('UPDATE properties SET ' . implode(', ', $sets) . ' WHERE id = :id')->execute($params);

    $get = db()->prepare('SELECT * FROM properties WHERE id = :id');
    $get->execute([':id' => $id]);
    respond(['data' => property_payload($get->fetch() ?: []), 'message' => 'Property updated']);
}

/** DELETE /properties/{id} */
function delete_property(int $id): void
{
    ensure_properties_table();
    $stmt = db()->prepare('DELETE FROM properties WHERE id = :id');
    $stmt->execute([':id' => $id]);
    if ($stmt->rowCount() === 0) fail('Property not found', 404);
    respond(['message' => 'Property deleted']);
}

/** Max size (bytes) accepted for a single property image. */
const PROPERTY_IMAGE_MAX_BYTES = 5242880; // 5 MB

/** Create the property_images table on first use so no manual SQL step is required. */
function ensure_property_images_table(): void
{
    db()->exec(
        "CREATE TABLE IF NOT EXISTS property_images (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
            property_id INT          NOT NULL,
            name        VARCHAR(255) NOT NULL DEFAULT '',
            size        INT UNSIGNED NOT NULL DEFAULT 0,
            mime        VARCHAR(150) NOT NULL DEFAULT '',
            data        LONGTEXT     NOT NULL,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_image_property (property_id),
            CONSTRAINT fk_image_property FOREIGN KEY (property_id)
              REFERENCES properties(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function ensure_property_exists(int $propertyId): void
{
    ensure_properties_table();
    $exists = db()->prepare('SELECT id FROM properties WHERE id = :id');
    $exists->execute([':id' => $propertyId]);
    if ($exists->fetchColumn() === false) fail('Property not found', 404);
}

/** GET /properties/{id}/images — metadata only, never the image bytes. */
function list_property_images(int $propertyId): void
{
    ensure_property_images_table();
    ensure_property_exists($propertyId);
    $stmt = db()->prepare(
        'SELECT id, property_id, name, size, mime, created_at
           FROM property_images
          WHERE property_id = :id
          ORDER BY id ASC'
    );
    $stmt->execute([':id' => $propertyId]);
    respond(['data' => $stmt->fetchAll(), 'count' => $stmt->rowCount()]);
}

/** POST /properties/{id}/images — store an uploaded image as a base64 data URI. */
function create_property_image(int $propertyId, array $body): void
{
    ensure_property_images_table();
    ensure_property_exists($propertyId);

    $data = (string)($body['data'] ?? '');
    if ($data === '' || !preg_match('~^data:image/[a-zA-Z0-9.+-]+;base64,~', $data)) {
        fail('Valid base64 image data URI required');
    }

    $comma = strpos($data, ',');
    $b64 = $comma !== false ? substr($data, $comma + 1) : '';
    if ($b64 === '') fail('Image payload is empty');

    // Guard against oversized uploads before decoding (base64 is ~4/3 the size).
    if ((strlen($b64) * 3) / 4 > PROPERTY_IMAGE_MAX_BYTES + 1024) {
        fail('Image too large (max 5 MB)');
    }

    $bytes = base64_decode($b64, true);
    if ($bytes === false) fail('Image payload is not valid base64');
    $actualSize = strlen($bytes);
    if ($actualSize > PROPERTY_IMAGE_MAX_BYTES) fail('Image too large (max 5 MB)');

    $mime = strtolower(substr($data, 5, (int)strpos($data, ';') - 5));
    $stmt = db()->prepare(
        'INSERT INTO property_images (property_id, name, size, mime, data)
              VALUES (:pid, :name, :size, :mime, :data)'
    );
    $stmt->execute([
        ':pid' => $propertyId,
        ':name' => mb_substr((string)($body['name'] ?? ''), 0, 255),
        ':size' => $actualSize,
        ':mime' => $mime,
        ':data' => $data,
    ]);

    respond(['data' => ['id' => (int)db()->lastInsertId()], 'message' => 'Image uploaded'], 201);
}

/** GET /properties/{id}/images/{imageId} — the raw image bytes. */
function get_property_image(int $propertyId, int $imageId): void
{
    ensure_property_images_table();
    $stmt = db()->prepare(
        'SELECT name, mime, data FROM property_images WHERE id = :id AND property_id = :pid'
    );
    $stmt->execute([':id' => $imageId, ':pid' => $propertyId]);
    $row = $stmt->fetch();
    if (!$row) fail('Image not found', 404);
    respond(['data' => $row['data'], 'mime' => $row['mime'], 'name' => $row['name']]);
}

/** DELETE /properties/{id}/images/{imageId} */
function delete_property_image(int $propertyId, int $imageId): void
{
    ensure_property_images_table();
    $stmt = db()->prepare('DELETE FROM property_images WHERE id = :id AND property_id = :pid');
    $stmt->execute([':id' => $imageId, ':pid' => $propertyId]);
    if ($stmt->rowCount() === 0) fail('Image not found', 404);
    respond(['message' => 'Image deleted']);
}

/**
 * Repair contacts whose name fell back to "Imported Lead".
 * Their real name lives inside custom_fields.import_data (and, for very old
 * imports, nested again under import_data.custom_fields as a JSON string).
 * Idempotent: skips rows that no longer carry the placeholder name.
 */
function repair_imported_names(): void
{
    $pdo = db();
    $rows = $pdo->query(
        "SELECT id, custom_fields FROM contacts WHERE first_name = 'Imported' AND last_name = 'Lead'"
    )->fetchAll();

    $fixed = 0;
    $skipped = 0;
    foreach ($rows as $row) {
        $id = (int)$row['id'];
        $cf = decode_custom_fields($row['custom_fields'] ?? null);
        $imp = $cf['import_data'] ?? null;

        $first = null;
        $last = null;

        if (is_array($imp)) {
            // Direct snapshot shape: first_name / last_name at top level.
            $probeFirst = trim((string)($imp['first_name'] ?? ''));
            $probeLast = trim((string)($imp['last_name'] ?? ''));
            if ($probeFirst !== '' && $probeFirst !== 'Imported' && $probeLast !== 'Lead') {
                $first = $probeFirst;
                $last = $probeLast;
            }
        }

        if ($first === null && is_array($imp) && is_string($imp['custom_fields'] ?? null)) {
            // Very old imports nested a JSON string with the ORIGINAL sheet row.
            $nested = decode_json_field($imp['custom_fields']);
            $nestedImp = is_array($nested) ? ($nested['import_data'] ?? null) : null;
            if (is_array($nestedImp)) {
                $name = trim((string)($nestedImp['NAME'] ?? $nestedImp['name'] ?? ''));
                if ($name !== '') {
                    $space = strpos($name, ' ');
                    if ($space === false) {
                        $first = $name;
                    } else {
                        $first = substr($name, 0, $space);
                        $last = substr($name, $space + 1);
                    }
                }
            }
        }

        if ($first === null || $first === '' || $first === 'Imported') {
            $skipped++;
            continue;
        }

        $upd = $pdo->prepare('UPDATE contacts SET first_name = :first, last_name = :last WHERE id = :id');
        $upd->execute([':first' => $first, ':last' => $last ?? '', ':id' => $id]);
        $fixed++;
    }

    respond([
        'data' => ['matched' => count($rows), 'fixed' => $fixed, 'skipped' => $skipped],
        'message' => 'Imported-name repair finished',
    ]);
}

/* ----------------------- ROUTER ----------------------- */

$method = $_SERVER['REQUEST_METHOD'];
$parts = route_parts();
$filters = $_GET;

$resource = $parts[0] ?? 'contacts';

// Soft-delete support: DELETE keeps the DB row (deleted_at), views hide it.
if (in_array($resource, ['contacts', 'leads', 'maintenance'], true)) {
    ensure_soft_delete_support();
}

switch ($resource) {
    case 'contacts':
        if ($method === 'GET') {
            $id = $parts[1] ?? null;
            $sub = $parts[2] ?? null;
            if ($id && $sub) {
                switch ($sub) {
                    case 'opportunities': list_opportunities(to_int($id)); break;
                    case 'tasks':         list_tasks(to_int($id));         break;
                    case 'notes':         list_notes(to_int($id));         break;
                    case 'appointments':  list_appointments(to_int($id));  break;
                    case 'documents':     list_documents(to_int($id));     break;
                    case 'followers':     list_followers(to_int($id));     break;
                    case 'activities':    list_activities(to_int($id));    break;
                    default: fail('Unknown sub-resource', 404);
                }
            }
            $id ? get_contact(to_int($id)) : list_contacts($filters);
        } elseif ($method === 'POST') {
            $body = json_body();
            if (($parts[1] ?? null) === 'bulk-delete') bulk_delete($body);
            elseif (($parts[2] ?? null) !== null) {
                $cid = to_int($parts[1]);
                switch ($parts[2]) {
                    case 'opportunities': create_opportunity($cid, $body); break;
                    case 'tasks':         create_task($cid, $body);        break;
                    case 'notes':         create_note($cid, $body);        break;
                    case 'appointments':  create_appointment($cid, $body); break;
                    case 'documents':     create_document($cid, $body);    break;
                    case 'followers':     add_follower($cid, $body);       break;
                    case 'activities':    create_activity($cid, $body);    break;
                    default: fail('Unknown sub-resource', 404);
                }
            } else {
                create_contact($body);
            }
        } elseif ($method === 'PUT') {
            $id = $parts[1] ?? null;
            if (!$id) fail('Contact id required');
            update_contact(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            $id = $parts[1] ?? null;
            $sub = $parts[2] ?? null;
            if (!$id) fail('Contact id required');
            if ($sub === 'followers') {
                $staffId = to_int($parts[3] ?? 0);
                if ($staffId <= 0) fail('staff_id required');
                remove_follower(to_int($id), $staffId);
            } else {
                delete_contact(to_int($id));
            }
        }
        break;

    case 'leads':
        if ($method === 'GET') list_leads($filters);
        break;

    case 'tags':
        if ($method === 'GET') list_tags();
        break;

    case 'campaigns':
        if ($method === 'GET') list_campaigns($filters);
        break;

    case 'workflows':
        if ($method === 'GET') list_workflows($filters);
        break;

    case 'staff':
        $id = $parts[1] ?? null;
        if ($method === 'GET') {
            if ($id) {
                $rows = db()->query('SELECT * FROM staff_users WHERE id = ' . (int)$id)->fetchAll();
                if (!$rows) fail('Staff user not found', 404);
                respond(['data' => staff_payload($rows[0])]);
            }
            list_staff();
        } elseif ($method === 'POST') {
            if ($id && ($parts[2] ?? null) === 'approve') {
                approve_staff(to_int($id));
            } else {
                create_staff(json_body());
            }
        } elseif ($method === 'PUT') {
            if (!$id) fail('Staff id required');
            update_staff(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Staff id required');
            delete_staff(to_int($id));
        }
        break;

    case 'opportunities':
        if ($method === 'DELETE') {
            $id = $parts[1] ?? null;
            if (!$id) fail('Opportunity id required');
            delete_opportunity(to_int($id));
        }
        break;

    case 'tasks':
        if ($method === 'DELETE') {
            $id = $parts[1] ?? null;
            if (!$id) fail('Task id required');
            delete_task(to_int($id));
        }
        break;

    case 'notes':
        if ($method === 'DELETE') {
            $id = $parts[1] ?? null;
            if (!$id) fail('Note id required');
            delete_note(to_int($id));
        }
        break;

    case 'maintenance':
        if ($method === 'POST' && ($parts[1] ?? null) === 'repair-imported-names') {
            repair_imported_names();
        }
        if ($method === 'POST' && ($parts[1] ?? null) === 'restore-contact') {
            $id = to_int($parts[2] ?? 0);
            if ($id <= 0) fail('Contact id required');
            $stmt = db()->prepare('UPDATE contacts SET deleted_at = NULL WHERE id = :id AND deleted_at IS NOT NULL');
            $stmt->execute([':id' => $id]);
            if ($stmt->rowCount() === 0) fail('Contact not found (or already active)', 404);
            respond(['message' => 'Contact restored']);
        }
        if ($method === 'GET' && ($parts[1] ?? null) === 'deleted-contacts') {
            $rows = db()->query(
                "SELECT id, first_name, last_name, phone, email, deleted_at FROM contacts WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC"
            )->fetchAll();
            respond(['data' => $rows, 'count' => count($rows), 'message' => 'Archived contacts (kept in DB, hidden from live views)']);
        }
        fail('Unknown maintenance action', 404);
        break;

    case 'appointments':
        if ($method === 'GET') {
            list_all_appointments();
        }
        if ($method === 'DELETE') {
            $id = $parts[1] ?? null;
            if (!$id) fail('Appointment id required');
            delete_appointment(to_int($id));
        }
        break;

    case 'documents':
        $id = $parts[1] ?? null;
        if ($method === 'GET') {
            if (!$id) fail('Document id required');
            serve_document(to_int($id), ($parts[2] ?? null) === 'download');
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Document id required');
            delete_document(to_int($id));
        }
        break;

    case 'auth':
        if ($method === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
        if ($method !== 'POST') {
            fail('Only POST is allowed on /auth', 405);
        }
        $sub = $parts[1] ?? null;
        if ($sub === 'register-dealer') {
            register_dealer(json_body());
        } elseif ($sub === 'reveal-password') {
            reveal_password(json_body());
        } elseif ($sub === 'magic-login') {
            magic_login(json_body());
        } else {
            login(json_body());
        }
        break;

    case 'dealer-dashboard':
        $sub = $parts[1] ?? null;
        if ($method === 'GET') {
            if ($sub === 'summary') {
                dealer_dashboard_summary();
            } elseif ($sub === 'unassigned') {
                dealer_unassigned_leads();
            } elseif ($sub === 'leads') {
                $dealerId = to_int((string)($filters['dealer_id'] ?? 0));
                if ($dealerId <= 0) fail('dealer_id is required');
                dealer_leads($dealerId, isset($filters['status']) ? (string)$filters['status'] : null);
            } elseif ($sub === 'my-leads') {
                $staffId = to_int((string)($filters['staff_id'] ?? 0));
                if ($staffId <= 0) fail('staff_id is required');
                my_dealer_leads($staffId, isset($filters['status']) ? (string)$filters['status'] : null);
            } else {
                fail('Unknown sub-resource', 404);
            }
        } elseif ($method === 'POST') {
            if ($sub === 'assign') {
                assign_leads_to_dealer(json_body());
            } elseif ($sub === 'bulk-status') {
                bulk_update_dealer_lead_status(json_body());
            } else {
                fail('Unknown sub-resource', 404);
            }
        } elseif ($method === 'PUT') {
            if ($sub === 'leads' && ($parts[3] ?? null) === 'status') {
                update_dealer_lead_status(to_int($parts[2]), json_body());
            } else {
                fail('Unknown sub-resource', 404);
            }
        }
        break;

    case 'smart-lists':
        $id = $parts[1] ?? null;
        $sub = $parts[2] ?? null;
        if ($method === 'GET') {
            list_smart_lists($filters);
        } elseif ($method === 'POST') {
            if ($id && $sub === 'duplicate') {
                duplicate_smart_list(to_int($id), json_body());
            } else {
                create_smart_list(json_body());
            }
        } elseif ($method === 'PUT') {
            if (!$id) fail('Smart list id required');
            update_smart_list(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Smart list id required');
            delete_smart_list(to_int($id), $filters);
        }
        break;

    case 'notifications':
        if ($method === 'GET') {
            if (($parts[1] ?? null) === 'unread-count') {
                notifications_unread_count(to_int((string)($filters['staff_id'] ?? 0)));
            }
            list_notifications($filters);
        } elseif ($method === 'POST') {
            if (($parts[1] ?? null) === 'read-all') {
                mark_all_notifications_read(json_body());
            } elseif (isset($parts[1]) && ($parts[2] ?? null) === 'read') {
                mark_notification_read(to_int($parts[1]));
            } else {
                create_notification(json_body());
            }
        }
        break;

    case 'form-images':
        if ($method === 'POST') {
            store_form_image(json_body());
        } elseif ($method === 'GET') {
            $id = $parts[1] ?? null;
            if ($id === null) fail('Image id required');
            get_form_image(to_int($id));
        }
        break;

    case 'forms':
        $id = $parts[1] ?? null;
        if ($method === 'GET') {
            if ($id !== null) {
                get_form(to_int($id));
            } else {
                list_forms();
            }
        } elseif ($method === 'POST') {
            create_form(json_body());
        } elseif ($method === 'PUT') {
            if (!$id) fail('Form id required');
            update_form(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Form id required');
            delete_form(to_int($id));
        }
        break;

    case 'invoices':
        $id = $parts[1] ?? null;
        if ($method === 'GET') {
            if ($id === null) list_invoices($filters);
            elseif ($id === 'next-number') next_invoice_number();
            else fail('Unknown invoice endpoint', 404);
        } elseif ($method === 'POST') {
            create_invoice(json_body());
        } elseif ($method === 'PUT') {
            if (!$id) fail('Invoice id required');
            update_invoice(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Invoice id required');
            delete_invoice(to_int($id));
        }
        break;

    case 'receipts':
        $id = $parts[1] ?? null;
        if ($method === 'GET') {
            if ($id === null) list_receipts($filters);
            elseif ($id === 'next-number') next_receipt_number();
            else fail('Unknown receipt endpoint', 404);
        } elseif ($method === 'POST') {
            create_receipt(json_body());
        } elseif ($method === 'PUT') {
            if (!$id) fail('Receipt id required');
            update_receipt(to_int($id), json_body());
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Receipt id required');
            delete_receipt(to_int($id));
        }
        break;

    case 'account-statements':
        $id = $parts[1] ?? null;
        $sub = $parts[2] ?? null;
        if ($method === 'GET') {
            if ($id === null) list_account_statements($filters);
            else get_account_statement(to_int($id));
        } elseif ($method === 'POST') {
            if ($id !== null && $sub === 'rows') {
                add_statement_row(to_int($id), json_body());
            } elseif ($id !== null && $sub === 'schedule') {
                generate_statement_schedule(to_int($id));
            } else {
                create_account_statement(json_body());
            }
        } elseif ($method === 'PUT') {
            if (!$id) fail('Statement id required');
            if ($sub === 'rows') {
                if (!($parts[3] ?? null)) fail('Row id required');
                update_statement_row(to_int($id), to_int($parts[3]), json_body());
            } else {
                update_account_statement(to_int($id), json_body());
            }
        } elseif ($method === 'DELETE') {
            if (!$id) fail('Statement id required');
            if ($sub === 'rows') {
                if (!($parts[3] ?? null)) fail('Row id required');
                delete_statement_row(to_int($id), to_int($parts[3]));
            } else {
                delete_account_statement(to_int($id));
            }
        }
        break;

    case 'emails':
        if ($method === 'POST') {
            $sub = $parts[1] ?? null;
            if ($sub === 'test') send_test_email(json_body());
            else send_email_campaign(json_body());
        }
        break;

    case 'submissions':
        if ($method === 'GET') {
            list_submissions($filters);
        } elseif ($method === 'POST') {
            if (($parts[1] ?? null) !== null && ($parts[2] ?? null) === 'assign') {
                assign_submission(to_int($parts[1]), json_body());
            } else {
                create_submission(json_body());
            }
        } elseif ($method === 'DELETE') {
            if (!$parts[1]) fail('Submission id required');
            delete_submission(to_int($parts[1]));
        }
        break;

    case 'properties':
        if ($method === 'GET') {
            $propId = $parts[1] ?? null;
            if ($propId && ($parts[2] ?? null) === 'images') {
                if ($parts[3] ?? null) get_property_image(to_int($propId), to_int($parts[3]));
                list_property_images(to_int($propId));
            }
            if ($propId) {
                $get = db()->prepare('SELECT * FROM properties WHERE id = :id');
                $get->execute([':id' => to_int((string)$propId)]);
                $row = $get->fetch();
                if (!$row) fail('Property not found', 404);
                respond(['data' => property_payload($row)]);
            }
            list_properties($filters);
        } elseif ($method === 'POST') {
            if (($parts[2] ?? null) === 'images' && ($parts[1] ?? null)) {
                create_property_image(to_int($parts[1]), json_body());
                break;
            }
            create_property(json_body());
        } elseif ($method === 'PUT') {
            if (!($parts[1] ?? null)) fail('Property id required');
            update_property(to_int($parts[1]), json_body());
        } elseif ($method === 'DELETE') {
            if (!($parts[1] ?? null)) fail('Property id required');
            if (($parts[2] ?? null) === 'images' && ($parts[3] ?? null)) {
                delete_property_image(to_int($parts[1]), to_int($parts[3]));
                break;
            }
            delete_property(to_int($parts[1]));
        }
        break;

    case 'health':
        $info = [
            'php' => PHP_VERSION,
            'sapi' => php_sapi_name(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
            'db_host' => DB_HOST,
            'db_name' => DB_NAME,
            'db_user' => DB_USER,
            'db_port' => DB_PORT,
            'doc_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'unknown',
            'script_name' => $_SERVER['SCRIPT_NAME'] ?? 'unknown',
            'request_uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
        ];
        try {
            $pdo = db();
            $info['db_status'] = 'connected';
            $row = $pdo->query('SELECT COUNT(*) AS c FROM contacts')->fetch();
            $info['contact_count'] = (int)($row['c'] ?? 0);
            $row2 = $pdo->query('SELECT COUNT(*) AS c FROM staff_users')->fetch();
            $info['staff_count'] = (int)($row2['c'] ?? 0);
        } catch (Throwable $e) {
            $info['db_status'] = 'error';
            $info['db_error'] = $e->getMessage();
        }
        respond($info);
        break;

    default:
        fail('Unknown endpoint', 404);
}
